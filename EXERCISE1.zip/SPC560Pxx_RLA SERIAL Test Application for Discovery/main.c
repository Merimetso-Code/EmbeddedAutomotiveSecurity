/****************************************************************************
*
* Copyright © 2015-2019 STMicroelectronics - All Rights Reserved
*
* This software is licensed under SLA0098 terms that can be found in the
* DM00779817_1_0.pdf file in the licenses directory of this software product.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
*****************************************************************************/

/* Inclusion of the main header files of all the imported components in the
   order specified in the application wizard. The file is generated
   automatically.*/
#include "components.h"

/*
 * Application entry point.
 */
int main(void) {

  uint8_t message[]= "Hello World!\r\n";
  /* Initialization of all the imported components in the order specified in
     the application wizard. The function is generated automatically.*/
  componentsInit();

  /* Enable Interrupts */
  irqIsrEnable();

  /* Start Serial Driver */
  sd_lld_start(&SD1,NULL);

  /* Application main loop.*/
  for ( ; ; ) {
    if (sd_lld_write(&SD1,message,(uint16_t)(sizeof(message)/sizeof(message[0]))) == SERIAL_MSG_OK) {
      pal_lld_togglepad(PORT_A,Led_D11);
      osalThreadDelayMilliseconds(200);
      pal_lld_togglepad(PORT_A,Led_D12);
      osalThreadDelayMilliseconds(200);
      pal_lld_togglepad(PORT_G,Led_D13);
      osalThreadDelayMilliseconds(200);
    }
  }
}
