/****************************************************************************
*
* Copyright © 2015-2019 STMicroelectronics - All Rights Reserved
*
* This software is licensed under SLA0098 terms that can be found in the
* DM00779817_1_0.pdf file in the licenses directory of this software product.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
*****************************************************************************/

/**
 * @file    platform.h
 * @brief   platform file.
 */

#ifndef _PLATFORM_H_
#define _PLATFORM_H_

#include "core.h"
#include "toolchain.h"
#include "intc.h"
#if !defined(_FROM_ASM_)
#include "typedefs.h"
#include "spr.h"
#include "spc560p_registry.h"
#if defined(_SPC560PXX_MEDIUM_)
#include "spc560p50.h"
#elif defined(_SPC560PXX_SMALL_)
#include "spc560p40.h"
#elif defined(_SPC560PXX_LARGE_)
#include "spc560p60.h"
#else
#error "Platform not supported"
#endif
#endif

#if defined(_SPC560PXX_LARGE_)
/**
 * @name    SWT subsystems references
 * @{
 */
#define SWT                  SWT_0

/**
 * @name    Mode Entry subsystems references
 * @{
 */
#define S_OSC                S_XOSC
#define S_RC                 S_IRC

/**
 * @name    SIUL subsystems references
 * @{
 */
#define SIU                  SIUL
/** @} */
#endif /* _SPC560PXX_LARGE_ */

#endif /* _PLATFORM_H_ */
