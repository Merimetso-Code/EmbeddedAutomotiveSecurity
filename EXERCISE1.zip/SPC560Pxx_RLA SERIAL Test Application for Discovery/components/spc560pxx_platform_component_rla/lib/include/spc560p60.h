/***********************************************************************************************
* Copyright � 2017 Freescale & STMicroelectronics
* Copyright � 2018-2021 STMicroelectronics - All Rights Reserved
*
*
* This software is licensed under SLA0098 terms that can be found in the
* DM00779817_1_0.pdf file in the licenses directory of this software product.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* 
************************************************************************************************/
/* 
 * Module:     : SPC56xP60.h
 * VERSION     :  1.0 (Aligned with RM0083 Rev 5 July 2016)
 * DATE        : 05.09.2019 
 *
 * History:                                                                   
 * Rev. 1.00   : Complete rework of the header file to match the RM
 *               Reviewed against refernce manual and compatibitlity 
 *               with P50 and P60
 */ 
/***************************************************************** 
 * Example instantiation and use:            
 *                                           
 *  <MODULE>.<REGISTER>.B.<BIT> = 1;         
 *  <MODULE>.<REGISTER>.R       = 0x10000000;
 *
 *  Exception: see CTU_tag CLR[24]
 *                                           
 ******************************************************************/

#ifndef _JDP_H_
#define _JDP_H_

#include "typedefs.h"

#ifdef  __cplusplus
extern "C" {
#endif

#ifdef __MWERKS__
#pragma push
#pragma ANSI_strict off
#endif
/****************************************************************************/
/*                          MODULE : ADC                                   */
/****************************************************************************/
struct ADC_tag {

    union {
        vuint32_t R;
        struct {
            vuint32_t OWREN:1;
            vuint32_t WLSIDE:1;
            vuint32_t MODE:1;
            vuint32_t:4;
            vuint32_t NSTART:1;
            vuint32_t:1;
            vuint32_t JTRGEN:1;
            vuint32_t JEDGE:1;
            vuint32_t JSTART:1;
            vuint32_t:2;
            vuint32_t CTUEN:1;
            vuint32_t:8;
            vuint32_t ADCLKSEL:1;
            vuint32_t ABORTCHAIN:1;
            vuint32_t ABORT:1;
            vuint32_t ACK0:1;
            vuint32_t:4;
            vuint32_t PWDN:1;
        } B;
    } MCR;                 /* MAIN CONFIGURATION REGISTER */

    union {
        vuint32_t R;
        struct {
            vuint32_t:7;
            vuint32_t NSTART:1;
            vuint32_t JABORT:1;
            vuint32_t:2;
            vuint32_t JSTART:1;
            vuint32_t:3;
            vuint32_t CTUSTART:1;
            vuint32_t CHADDR:7;
            vuint32_t:3;
            vuint32_t ACK0:1;
            vuint32_t:2;
            vuint32_t ADCSTATUS:3;
        } B;
    } MSR;                 /* MAIN STATUS REGISTER */

    int32_t ADC_RESERVED_1[2];       /* 0x0008-0x000F */

    union {                /* Address base + 0x0010 */
        vuint32_t R;
        struct {
            vuint32_t:27;
            vuint32_t EOCTU:1;
            vuint32_t JEOC:1;
            vuint32_t JECH:1;
            vuint32_t EOC:1;
            vuint32_t ECH:1;
        } B;
    } ISR;                 /* INTERRUPT STATUS REGISTER */

    int32_t ADC_RESERVED_2[3];       /* 0x0014-0x001F */

    union {
        vuint32_t R;
        struct {
            vuint32_t:27;
            vuint32_t MSKEOCTU:1;
            vuint32_t MSKJEOC:1;
            vuint32_t MSKJECH:1;
            vuint32_t MSKEOC:1;
            vuint32_t MSKECH:1;
        } B;
    } IMR;                  /* INTERRUPT MASK REGISTER */

    int32_t ADC_RESERVED_3[3];       /* 0x0024-0x002F */

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t WDG3H:1;
            vuint32_t WDG2H:1;
            vuint32_t WDG1H:1;
            vuint32_t WDG0H:1;
            vuint32_t WDG3L:1;
            vuint32_t WDG2L:1;
            vuint32_t WDG1L:1;
            vuint32_t WDG0L:1;
        } B;
    } WTISR;               /* WATCHDOG INTERRUPT THRESHOLD REGISTER was WDGTHR */
    
    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t MSKWDG3H:1;
            vuint32_t MSKWDG2H:1;
            vuint32_t MSKWDG1H:1;
            vuint32_t MSKWDG0H:1;
            vuint32_t MSKWDG3L:1;
            vuint32_t MSKWDG2L:1;
            vuint32_t MSKWDG1L:1;
            vuint32_t MSKWDG0L:1;
        } B;
    } WTIMR;             /* WATCHDOG INTERRUPT MASK REGISTER was IMWDGTHR */
    
    int32_t ADC_RESERVED_4[2];       /* 0x0038-0x003F */

    union {
        vuint32_t R;
        struct {
            vuint32_t:30;
            vuint32_t DCLR:1;
            vuint32_t DMAEN:1;
        } B;
    } DMAE;                 /* DMAE REGISTER */

    union {
        vuint32_t R;
        struct {
            vuint32_t:5;
            vuint32_t DMA26:1;
            vuint32_t DMA25:1;
            vuint32_t DMA24:1;
            vuint32_t DMA23:1;
            vuint32_t DMA22:1;
            vuint32_t DMA21:1;
            vuint32_t DMA20:1;
            vuint32_t DMA19:1;
            vuint32_t DMA18:1;
            vuint32_t DMA17:1;
            vuint32_t DMA16:1;
            vuint32_t DMA15:1;
            vuint32_t DMA14:1;
            vuint32_t DMA13:1;
            vuint32_t DMA12:1;
            vuint32_t DMA11:1;
            vuint32_t DMA10:1;
            vuint32_t DMA9:1;
            vuint32_t DMA8:1;
            vuint32_t DMA7:1;
            vuint32_t DMA6:1;
            vuint32_t DMA5:1;
            vuint32_t DMA4:1;
            vuint32_t DMA3:1;
            vuint32_t DMA2:1;
            vuint32_t DMA1:1;
            vuint32_t DMA0:1;
        } B;
    } DMAR0;           

    int32_t ADC_RESERVED_5[2];       /* 0x0048-0x004F */
    
    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t THREN:1;
            vuint32_t THRINV:1;
            vuint32_t THROP:1;
            vuint32_t:6;
            vuint32_t THRCH:7;
        } B;
    } TRC[4];               /* ADC THRESHOLD REGISTER REGISTER */
    
    union {
        vuint32_t R;
        struct {        //were in TRA & TRB
            vuint32_t:6;
            vuint32_t THRH:10;
            vuint32_t:6;
            vuint32_t THRL:10;
        } B;
    } THRHLR[4];               /* THRESHOLD REGISTER */

    vuint32_t ADC_RESERVED_6[4]; /* 0x0070�0x007F */

    union {
        vuint32_t R;
        struct {
            vuint32_t:29;
            vuint32_t PREVAL0:2;
            vuint32_t PRECONV:1;
        }B;
    } PSCR;                /* Presampling Control Register */     

    union {
        vuint32_t R;
        struct {
            vuint32_t:5;
            vuint32_t PRES26:1;
            vuint32_t PRES25:1;
            vuint32_t PRES24:1;
            vuint32_t PRES23:1;
            vuint32_t PRES22:1;
            vuint32_t PRES21:1;
            vuint32_t PRES20:1;
            vuint32_t PRES19:1;
            vuint32_t PRES18:1;
            vuint32_t PRES17:1;
            vuint32_t PRES16:1;
            vuint32_t PRES15:1;
            vuint32_t PRES14:1;
            vuint32_t PRES13:1;
            vuint32_t PRES12:1;
            vuint32_t PRES11:1;
            vuint32_t PRES10:1;
            vuint32_t PRES9:1;
            vuint32_t PRES8:1;
            vuint32_t PRES7:1;
            vuint32_t PRES6:1;
            vuint32_t PRES5:1;
            vuint32_t PRES4:1;
            vuint32_t PRES3:1;
            vuint32_t PRES2:1;
            vuint32_t PRES1:1;
            vuint32_t PRES0:1;
        } B;
    } PSR0;                /* Presampling Register 0 */          

    vuint32_t ADC_RESERVED_7[3]; /* 0x0088�0x0093 */ 

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t INPLATCH:1;
            vuint32_t:1;
            vuint32_t OFFSHIFT:2;
            vuint32_t:1;
            vuint32_t INPCMP:2;
            vuint32_t:1;
            vuint32_t INPSAMP:8;
        } B;
    } CTR0;                /* CONVERSION TIMING REGISTER  */

    int32_t ADC_RESERVED_8[3];       /* 0x0098-0x00A3*/

    union {
        vuint32_t R;
        struct {
            vuint32_t:5;
            vuint32_t CH26:1;
            vuint32_t CH25:1;
            vuint32_t CH24:1;
            vuint32_t CH23:1;
            vuint32_t CH22:1;
            vuint32_t CH21:1;
            vuint32_t CH20:1;
            vuint32_t CH19:1;
            vuint32_t CH18:1;
            vuint32_t CH17:1;
            vuint32_t CH16:1;
            vuint32_t CH15:1;
            vuint32_t CH14:1;
            vuint32_t CH13:1;
            vuint32_t CH12:1;
            vuint32_t CH11:1;
            vuint32_t CH10:1;
            vuint32_t CH9:1;
            vuint32_t CH8:1;
            vuint32_t CH7:1;
            vuint32_t CH6:1;
            vuint32_t CH5:1;
            vuint32_t CH4:1;
            vuint32_t CH3:1;
            vuint32_t CH2:1;
            vuint32_t CH1:1;
            vuint32_t CH0:1;
        } B;
    } NCMR0;              /* NORMAL CONVERSION MASK REGISTER 0 */

    int32_t ADC_RESERVED_9[3];       /* 0x00A8-0x00B3*/

    union {
        vuint32_t R;
        struct {
            vuint32_t:5;
            vuint32_t CH26:1;
            vuint32_t CH25:1;
            vuint32_t CH24:1;
            vuint32_t CH23:1;
            vuint32_t CH22:1;
            vuint32_t CH21:1;
            vuint32_t CH20:1;
            vuint32_t CH19:1;
            vuint32_t CH18:1;
            vuint32_t CH17:1;
            vuint32_t CH16:1;
            vuint32_t CH15:1;
            vuint32_t CH14:1;
            vuint32_t CH13:1;
            vuint32_t CH12:1;
            vuint32_t CH11:1;
            vuint32_t CH10:1;
            vuint32_t CH9:1;
            vuint32_t CH8:1;
            vuint32_t CH7:1;
            vuint32_t CH6:1;
            vuint32_t CH5:1;
            vuint32_t CH4:1;
            vuint32_t CH3:1;
            vuint32_t CH2:1;
            vuint32_t CH1:1;
            vuint32_t CH0:1;
        } B;
    } JCMR0;              /* Injected CONVERSION MASK REGISTER 0 */

    int32_t ADC_RESERVED_10[4];       /* 0x00B8-0x00C7*/

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t PDED:8;    //was PDD
        } B;
    } PDEDR;                  /* POWER DOWN DELAY REGISTER was PDD */

    int32_t ADC_RESERVED_11[13];       /* 0x00CC-0x00FF*/

    union {
        vuint32_t R;
        struct {
            vuint32_t:12;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
            vuint32_t CDATA:16; /* Channel 0-15 converted data. Depending on the 
				   value of the MCR[WLSIDE] bit, the position of this
				   field can be changed */
        } B;
    } CDR[27];            /* Channel 0/26 Data Register */

};                          /* end of ADC_tag */
/****************************************************************************/
/*                          MODULE : ECSM                                   */
/****************************************************************************/
struct ECSM_tag {

    union {
        vuint16_t R;
    } PCT;                  /* MCM Processor Core Type Register */

    union {
        vuint16_t R;
    } REV;                  /* MCM  Revision Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t:8;
            vuint16_t AMC:8;
        } B;            
    } PLAMC;            /* Platform XBAR Master Configuration */

    union {
        vuint16_t R;
        struct {
            vuint16_t DP64:1;
            vuint16_t:7;
            vuint16_t ASC:8;
        } B;            
    } PLASC;            /* Platform XBAR Sleave Configuration */        

    union {
        vuint32_t R;
        struct {
            vuint32_t MC:32;
        } B;            
    } IMC;                /* IPS Module Configuration register */

    int8_t ECSM_RESERVED_1[3];       /* 0x000C-0x000E*/

    union {
        vuint8_t R;
        struct {
            vuint8_t POR:1;
            vuint8_t DIR:1;
            vuint8_t:6;
        } B;
    } MRSR;                 /* MCM Miscellaneous Reset Status Register */

    int8_t ECSM_RESERVED_2[15];      /* 0x0010-0x001E*/

    union {
        vuint8_t R;
        struct {
            vuint8_t FB0AI:1;
            vuint8_t FB0SI:1;
            vuint8_t FB1AI:1;
            vuint8_t FB1SI:1;
            vuint8_t:4;
        } B;
    } MIR;                  /* MCM Miscellaneous Interrupt Register */

    int32_t ECSM_RESERVED_3;       /* 0x0020-0x0023*/

    union {
        vuint32_t R;
        struct {
            vuint32_t MUDCR:1;
            vuint32_t:31;
		} B;	
    } MUDCR;            /* Miscellaneous User-Defined Control Register */

    int8_t ECSM_RESERVED_4[27];       /* 0x0028-0x0042*/

    union {
        vuint8_t R;
        struct {
            vuint8_t:2;
            vuint8_t ER1BR:1;
            vuint8_t EF1BR:1;
            vuint8_t:2;
            vuint8_t ERNCR:1;
            vuint8_t EFNCR:1;
        } B;
    } ECR;                /* ECC Configuration register */

    int8_t ECSM_RESERVED_5[3];       /* 0x0044-0x0046 */

    union {
        vuint8_t R;
        struct {
            vuint8_t:2;
            vuint8_t R1BC:1;
            vuint8_t F1BC:1;
            vuint8_t:2;
            vuint8_t RNCE:1;
            vuint8_t FNCE:1;
        } B;
    } ESR;                /* ECC Status register */

    int16_t ECSM_RESERVED_6;

    union {
        vuint16_t R;
        struct {
            vuint16_t:2;
            vuint16_t FRC1BI:1;
            vuint16_t FR11BI:1;
            vuint16_t:2;
            vuint16_t FRCNCI:1;
            vuint16_t FR1NCI:1;
            vuint16_t:1;
            vuint16_t ERRBIT:7;
        } B;
    } EEGR;                /* ECC Error Generation register */

    int32_t ECSM_RESERVED_7;       /* 0x004C-0x004F */

    union {
        vuint32_t R;
    } FEAR;                 /* MCM Flash ECC Address Register */

    int16_t ECSM_RESERVED_8;       /* 0x0054-0x0055 */

    union {
        vuint8_t R;
        struct {
            vuint8_t:4;
            vuint8_t FEMR:4;
        } B;
    } FEMR;                /* Flash ECC Master Number Register */

    union {
        vuint8_t R;
        struct {
            vuint8_t WRITE:1;
            vuint8_t SIZE:3;
            vuint8_t PROTECTION:4;
        } B;
    } FEAT;                /* Flash ECC Attributes Register */

    int32_t ECSM_RESERVED_9;       /* 0x0058-0x005B */

    union {
        vuint32_t R;
    } FEDR;                /* Flash ECC Data Register */

    union {
        vuint32_t R;
    } REAR;                 /* RAM ECC Address Register */

    int8_t ECSM_RESERVED_10;       /* 0x0064 */

    union {
        vuint8_t R;
    } RESR;                 /* RAM ECC Address Register */

    union {
        vuint8_t R;
        struct {
            vuint8_t:4;
            vuint8_t REMR:4;
        } B;
    } REMR;                 /* RAM ECC Master Number Register */

    union {
        vuint8_t R;
        struct {
            vuint8_t WRITE:1;
            vuint8_t SIZE:3;
            vuint8_t PROTECTION:4;
        } B;
    } REAT;                /* RAM ECC Attributes Register */

    int32_t ECSM_RESERVED_11;       /* 0x0068-0x006B */

    union {
        vuint32_t R;
    } REDR;                /* RAM ECC Data Register */
    
};                          /* end of ECSM_tag */

/****************************************************************************/
/*                          MODULE : SIUL                                  */
/****************************************************************************/
struct SIUL_tag {

    int32_t SIUL_RESERVED_0[1]; /* 0x0000-0x0003 */

    union {                 /* MCU ID Register 1 */
        vuint32_t R;
        struct {
            vuint32_t PARTNUM:16;
            vuint32_t CSP:1;
            vuint32_t PKG:5;
            vuint32_t:2;
            vuint32_t MAJORMASK:4;
            vuint32_t MINORMASK:4;
        } B;
    } MIDR1;

    union {                 /* MCU ID Register 2 */
        vuint32_t R;
        struct {
            vuint32_t SF:1;
            vuint32_t FLASH_SIZE_1:4;
            vuint32_t FLASH_SIZE_2:4;
            vuint32_t:7;
            vuint32_t PARTNUM:8;
            vuint32_t:3;
            vuint32_t EE:1;
            vuint32_t:4;
        } B;
    } MIDR2;

    int32_t SIUL_RESERVED_1[2]; /* 0x000C-0x0013 */

    union {                 /* Interrupt Status Flag Register */
        vuint32_t R;
        struct {
            vuint32_t EIF31:1;
            vuint32_t EIF30:1;
            vuint32_t EIF29:1;
            vuint32_t EIF28:1;
            vuint32_t EIF27:1;
            vuint32_t EIF26:1;
            vuint32_t EIF25:1;
            vuint32_t EIF24:1;
            vuint32_t EIF23:1;
            vuint32_t EIF22:1;
            vuint32_t EIF21:1;
            vuint32_t EIF20:1;
            vuint32_t EIF19:1;
            vuint32_t EIF18:1;
            vuint32_t EIF17:1;
            vuint32_t EIF16:1;
            vuint32_t EIF15:1;
            vuint32_t EIF14:1;
            vuint32_t EIF13:1;
            vuint32_t EIF12:1;
            vuint32_t EIF11:1;
            vuint32_t EIF10:1;
            vuint32_t EIF9:1;
            vuint32_t EIF8:1;
            vuint32_t EIF7:1;
            vuint32_t EIF6:1;
            vuint32_t EIF5:1;
            vuint32_t EIF4:1;
            vuint32_t EIF3:1;
            vuint32_t EIF2:1;
            vuint32_t EIF1:1;
            vuint32_t EIF0:1;
        } B;
    } ISR;

    union {                 /* Interrupt Request Enable Register */
        vuint32_t R;
        struct {
            vuint32_t IRE31:1;
            vuint32_t IRE30:1;
            vuint32_t IRE29:1;
            vuint32_t IRE28:1;
            vuint32_t IRE27:1;
            vuint32_t IRE26:1;
            vuint32_t IRE25:1;
            vuint32_t IRE24:1;
            vuint32_t IRE23:1;
            vuint32_t IRE22:1;
            vuint32_t IRE21:1;
            vuint32_t IRE20:1;
            vuint32_t IRE19:1;
            vuint32_t IRE18:1;
            vuint32_t IRE17:1;
            vuint32_t IRE16:1;
            vuint32_t IRE15:1;
            vuint32_t IRE14:1;
            vuint32_t IRE13:1;
            vuint32_t IRE12:1;
            vuint32_t IRE11:1;
            vuint32_t IRE10:1;
            vuint32_t IRE9:1;
            vuint32_t IRE8:1;
            vuint32_t IRE7:1;
            vuint32_t IRE6:1;
            vuint32_t IRE5:1;
            vuint32_t IRE4:1;
            vuint32_t IRE3:1;
            vuint32_t IRE2:1;
            vuint32_t IRE1:1;
            vuint32_t IRE0:1;
        } B;
    } IRER;

    int32_t SIUL_RESERVED_2[3]; /* 0x001C-0x0027 */

    union {                 /* Interrupt Rising-Edge Event Enable Register */
        vuint32_t R;
        struct {
            vuint32_t IREE31:1;
            vuint32_t IREE30:1;
            vuint32_t IREE29:1;
            vuint32_t IREE28:1;
            vuint32_t IREE27:1;
            vuint32_t IREE26:1;
            vuint32_t IREE25:1;
            vuint32_t IREE24:1;
            vuint32_t IREE23:1;
            vuint32_t IREE22:1;
            vuint32_t IREE21:1;
            vuint32_t IREE20:1;
            vuint32_t IREE19:1;
            vuint32_t IREE18:1;
            vuint32_t IREE17:1;
            vuint32_t IREE16:1;
            vuint32_t IREE15:1;
            vuint32_t IREE14:1;
            vuint32_t IREE13:1;
            vuint32_t IREE12:1;
            vuint32_t IREE11:1;
            vuint32_t IREE10:1;
            vuint32_t IREE9:1;
            vuint32_t IREE8:1;
            vuint32_t IREE7:1;
            vuint32_t IREE6:1;
            vuint32_t IREE5:1;
            vuint32_t IREE4:1;
            vuint32_t IREE3:1;
            vuint32_t IREE2:1;
            vuint32_t IREE1:1;
            vuint32_t IREE0:1;
        } B;
    } IREER;

    union {                 /* Interrupt Falling-Edge Event Enable Register */
        vuint32_t R;
        struct {
            vuint32_t IFEE31:1;
            vuint32_t IFEE30:1;
            vuint32_t IFEE29:1;
            vuint32_t IFEE28:1;
            vuint32_t IFEE27:1;
            vuint32_t IFEE26:1;
            vuint32_t IFEE25:1;
            vuint32_t IFEE24:1;
            vuint32_t IFEE23:1;
            vuint32_t IFEE22:1;
            vuint32_t IFEE21:1;
            vuint32_t IFEE20:1;
            vuint32_t IFEE19:1;
            vuint32_t IFEE18:1;
            vuint32_t IFEE17:1;
            vuint32_t IFEE16:1;
            vuint32_t IFEE15:1;
            vuint32_t IFEE14:1;
            vuint32_t IFEE13:1;
            vuint32_t IFEE12:1;
            vuint32_t IFEE11:1;
            vuint32_t IFEE10:1;
            vuint32_t IFEE9:1;
            vuint32_t IFEE8:1;
            vuint32_t IFEE7:1;
            vuint32_t IFEE6:1;
            vuint32_t IFEE5:1;
            vuint32_t IFEE4:1;
            vuint32_t IFEE3:1;
            vuint32_t IFEE2:1;
            vuint32_t IFEE1:1;
            vuint32_t IFEE0:1;
        } B;
    } IFEER;

    union {                 /* Interrupt Filter Enable Register */
        vuint32_t R;
        struct {
            vuint32_t IFE31:1;
            vuint32_t IFE30:1;
            vuint32_t IFE29:1;
            vuint32_t IFE28:1;
            vuint32_t IFE27:1;
            vuint32_t IFE26:1;
            vuint32_t IFE25:1;
            vuint32_t IFE24:1;
            vuint32_t IFE23:1;
            vuint32_t IFE22:1;
            vuint32_t IFE21:1;
            vuint32_t IFE20:1;
            vuint32_t IFE19:1;
            vuint32_t IFE18:1;
            vuint32_t IFE17:1;
            vuint32_t IFE16:1;
            vuint32_t IFE15:1;
            vuint32_t IFE14:1;
            vuint32_t IFE13:1;
            vuint32_t IFE12:1;
            vuint32_t IFE11:1;
            vuint32_t IFE10:1;
            vuint32_t IFE9:1;
            vuint32_t IFE8:1;
            vuint32_t IFE7:1;
            vuint32_t IFE6:1;
            vuint32_t IFE5:1;
            vuint32_t IFE4:1;
            vuint32_t IFE3:1;
            vuint32_t IFE2:1;
            vuint32_t IFE1:1;
            vuint32_t IFE0:1;
        } B;
    } IFER;

    int32_t SIUL_RESERVED_3[3]; /* 0x0034-0x003F */

    union {                 /* Pad Configuration Registers */
        vuint16_t R;
        struct {
            vuint16_t:1;
            vuint16_t SMC:1;
            vuint16_t APC:1;
            vuint16_t:1;
            vuint16_t PA:2;
            vuint16_t OBE:1;
            vuint16_t IBE:1;
            vuint16_t:2;
            vuint16_t ODE:1;
            vuint16_t:2;
            vuint16_t SRC:1;
            vuint16_t WPE:1;
            vuint16_t WPS:1;
        } B;
    } PCR[108];

    int32_t SIUL_RESERVED_4[250]; /* 0x0118-0x04FF */

    union {                 /* Pad Selection for Multiplexed Input Register */
        vuint8_t R;
        struct {
            vuint8_t:4;
            vuint8_t PADSEL:4;
        } B;
    } PSMI[40];            /* Pad Selection for Multiplexed Input Register */

    vuint32_t SIUL_RESERVED_5[54]; /* 0x0528-0x05FF */

    union {                 /* GPIO Pin Data Output Registers */
        vuint8_t R;
        struct {
            vuint8_t:7;
            vuint8_t PDO:1;
        } B;
    } GPDO[108];
    
    int32_t SIUL_RESERVED_6[101]; /* 0x066C-0x07FF */

    union {                 /* GPIO Pin Data Input Registers */
        vuint8_t R;
        struct {
            vuint8_t:7;
            vuint8_t PDI:1;
        } B;
    } GPDI[108];        /* GPIO Pad Data Input Registers 0/107 */

    int32_t SIUL_RESERVED_7[229]; /* 0x086C-0x0BFF */

    union {                 /* Parallel GPIO Pin Data Output Register */
        vuint32_t R;
        struct {
            vuint32_t PPD0:32;
        } B;
    } PGPDO[4];        /* Parallel GPIO Pad Data Out register 0/3 */

    int32_t SIUL_RESERVED_8[12]; /* 0x0C10-0x0C3F */

    union {                 /* Parallel GPIO Pin Data Input Register */
        vuint32_t R;
        struct {
            vuint32_t PPDI:32;
        } B;
    } PGPDI[4];

    int32_t SIUL_RESERVED_9[12]; /* 0x0C50-0x0C7F */

    union {                 /* Masked Parallel GPIO Pin Data Out Register */
        vuint32_t R;
        struct {
            vuint32_t MASK:16;
            vuint32_t MPPDO:16;
        } B;
    } MPGPDO[7];        /* Masked Parallel GPIO Pad Data Out register 0/6 */

    int32_t SIUL_RESERVED_10[217]; /* 0x0C9C-0x0FFF */
    
    union {                 /* Interrupt Filter Maximum Counter Register */
        vuint32_t R;
        struct {
            vuint32_t:28;
            vuint32_t MAXCNT:4;
        } B;
    } IFMC[32];

    union {                 /* Interrupt Filter Clock Prescaler Register */
        vuint32_t R;
        struct {
            vuint32_t:28;
            vuint32_t IFCP:4;
        } B;
    } IFCPR;
    
};                          /* end of SIUL_tag */


/****************************************************************************/
/*                          MODULE : SSCM                                   */
/****************************************************************************/
struct SSCM_tag {
    union {
        vuint16_t R;
        struct {
            vuint16_t:1;
            vuint16_t CER:1;
            vuint16_t:1;
            vuint16_t NXEN1:1;
            vuint16_t NXEN:1;
            vuint16_t PUB:1;
            vuint16_t SEC:1;
            vuint16_t:1;
            vuint16_t BMODE:3;
            vuint16_t VLE:1;
            vuint16_t ABD:1;
            vuint16_t:3;
        } B;
    } STATUS;               /* Status Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t JPIN:10;
            vuint16_t IVLD:1;
            vuint16_t MREV:4;
            vuint16_t DVLD:1;
        } B;
    } MEMCONFIG;        /* System Memory Configuration Register */

    int16_t SSCM_reserved;

    union {
        vuint16_t R;
        struct {
            vuint16_t:14;
            vuint16_t PAE:1;
            vuint16_t RAE:1;
        } B;
    } ERROR;            /* Error Configuration Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t:13;
            vuint16_t DEBUG_MODE:3;
        } B;
    } DEBUGPORT;        /* Debug Status Port Register */

    int16_t SSCM_RESERVED_1;    /* 0x000A */

    union {
        vuint32_t R;
        struct {
            vuint32_t PWD_HI:32;
        } B;
    } PWCMPH;               /* Password Comparison Register High Word */

    union {
        vuint32_t R;
        struct {
            vuint32_t PWD_LO:32;
        } B;
    } PWCMPL;            /* Password Comparison Register Low Word */

    vuint16_t SSCM_RESERVED_2[2]; /* 0x0014-0x0017 */ 

    union {
        vuint32_t R;
        struct {
            vuint32_t P2BOOT:30;
            vuint32_t:2;
        } B;
    } DPMBOOT;            /* DPM Boot Register */  

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t KEY:16;
        } B;
    } DPMKEY;            /* DPM Boot Key Register */ 

    union {
        vuint32_t R;
        struct {
            vuint32_t UOPT:32;
        } B;
    } UOPS;                /* User Option Status Register */  

    vuint16_t SSCM_RESERVED_3[2]; /* 0x0024-0x0027 */ 

    union {
        vuint32_t R;
        struct {
            vuint32_t SADR:32;
        } B;
    } PSA;                /* Processor Start Address Register */ 
        
    vuint16_t SSCM_RESERVED_4[4085]; /* 0x002C-0x3FFF */     

};                /* end of SSCM_tag */

/****************************************************************************/
/*                          MODULE : STM                                    */
/****************************************************************************/    
struct STM_tag {

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t CPS:8;
            vuint32_t:6;
            vuint32_t FRZ:1;
            vuint32_t TEN:1;
        } B;
    } CR0;                  /* STM Control Register */
    
    union {
        vuint32_t R;
    } CNT;                 /* STM Count Register */

    int32_t STM_RESERVED_0[2];    /* 0x0008-0x000F */

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t CEN:1;
        } B;
    } CCR0;                 /* STM Channel Control Register 0 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t CIF:1;
        } B;
    } CIR0;                 /* STM Channel Interrupt Register 0 */

    union {
        vuint32_t R;
    } CMP0;                 /* STM Channel Compare Register 0 */

    int32_t STM_RESERVED_1;    /* 0x001C-0x001F */

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t CEN:1;
        } B;
    } CCR1;                 /* STM Channel Control Register 1 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t CIF:1;
        } B;
    } CIR1;                 /* STM Channel Interrupt Register 1 */

    union {
        vuint32_t R;
    } CMP1;                 /* STM Channel Compare Register 1 */

    int32_t STM_RESERVED_2;    /* 0x002C-0x002F */

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t CEN:1;
        } B;
    } CCR2;                 /* STM Channel Control Register 2 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t CIF:1;
        } B;
    } CIR2;                 /* STM Channel Interrupt Register 2 */

    union {
        vuint32_t R;
    } CMP2;                 /* STM Channel Compare Register 2 */

    int32_t STM_RESERVED_3;    /* 0x003C-0x003F */

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t CEN:1;
        } B;
    } CCR3;                 /* STM Channel Control Register 3 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t CIF:1;
        } B;
    } CIR3;                 /* STM Channel Interrupt Register 3 */

    union {
        vuint32_t R;
    } CMP3;                 /* STM Channel Compare Register 3 */

};                        /* end of STM_tag */
/****************************************************************************/
/*                          MODULE : SWT                                    */
/****************************************************************************/
struct SWT_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t MAP0:1;
            vuint32_t MAP1:1;
            vuint32_t MAP2:1;
            vuint32_t MAP3:1;
            vuint32_t MAP4:1;
            vuint32_t MAP5:1;
            vuint32_t MAP6:1;
            vuint32_t MAP7:1;
            vuint32_t:14;
            vuint32_t KEY:1;
            vuint32_t RIA:1;
            vuint32_t WND:1;
            vuint32_t ITR:1;
            vuint32_t HLK:1;
            vuint32_t SLK:1;
            vuint32_t CSL:1;
            vuint32_t STP:1;
            vuint32_t FRZ:1;
            vuint32_t WEN:1;
        } B;
    } CR;                /* SWT Control Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t TIF:1;
        } B;
    } IR;                /* SWT Interrupt Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t WTO:32;
        } B;
    } TO;                   /* SWT Time-Out Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t WST:32;
        } B;
    } WN;                /* SWT Window Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t WSC:16;
        } B;
    } SR;                /* SWT Service Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t CNT:32;
        } B;
    } CO;                /* SWT Counter Output Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t SK:16;
        } B;
    } SK;                /* SWT Service Key Register */
};                        /* end of SWT_tag */


/****************************************************************************/
/*                          MODULE : WKUP                                   */
/****************************************************************************/
struct WKUP_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t NIF:1;
            vuint32_t NOVF:1;
            vuint32_t:30;
        } B;
    } NSR;                /* NMI Status Register */

    int32_t WKUP_RESERVED_0;

    union {
        vuint32_t R;
        struct {
            vuint32_t NLOCK:1;
            vuint32_t NDSS:2;
            vuint32_t:2;
            vuint32_t NREE:1;
            vuint32_t NFEE:1;
            vuint32_t NFE:1;
            vuint32_t:24;
        } B;
    } NCR;                /* NMI Configuration Register */
};                        /* end of WKUP_tag */
/****************************************************************************/
/*                         MODULE : LINFLEX                                */
/****************************************************************************/
struct LINFLEX_tag {

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t CCD:1;
            vuint32_t CFD:1;
            vuint32_t LASE:1;
            vuint32_t AWUM:1;
            vuint32_t MBL:4;
            vuint32_t BF:1;
            vuint32_t SFTM:1;
            vuint32_t LBKM:1;
            vuint32_t MME:1;
            vuint32_t SBDT:1;
            vuint32_t RBLM:1;
            vuint32_t SLEEP:1;
            vuint32_t INIT:1;
        } B;
    } LINCR1;            /* LIN Control Register 1 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t SZIE:1;
            vuint32_t OCIE:1;
            vuint32_t BEIE:1;
            vuint32_t CEIE:1;
            vuint32_t HEIE:1;
            vuint32_t:2;
            vuint32_t FEIE:1;
            vuint32_t BOIE:1;
            vuint32_t LSIE:1;
            vuint32_t WUIE:1;
            vuint32_t DBFIE:1;
            vuint32_t DBEIE:1;
            vuint32_t DRIE:1;
            vuint32_t DTIE:1;
            vuint32_t HRIE:1;
        } B;
    } LINIER;            /* LIN interrupt enable register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t LINS:4;
            vuint32_t:2;
            vuint32_t RMB:1;
            vuint32_t:1;
            vuint32_t RBSY:1;
            vuint32_t RPS:1;
            vuint32_t WUF:1;
            vuint32_t DBFF:1;
            vuint32_t DBEF:1;
            vuint32_t DRF:1;
            vuint32_t DTF:1;
            vuint32_t HRF:1;
        } B;
    } LINSR;            /* LINFLEX LIN Status Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t SZF:1;
            vuint32_t OCF:1;
            vuint32_t BEF:1;
            vuint32_t CEF:1;
            vuint32_t SFEF:1;
            vuint32_t BDEF:1;
            vuint32_t IDPEF:1;
            vuint32_t FEF:1;
            vuint32_t BOF:1;
            vuint32_t:6;
            vuint32_t NF:1;
        } B;
    } LINESR;            /* LIN Error Status Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:17;
            vuint32_t TDFL:2;
            vuint32_t:1;
            vuint32_t RDFL:2;
            vuint32_t:4;
            vuint32_t RXEN:1;
            vuint32_t TXEN:1;
            vuint32_t OP:1;
            vuint32_t PCE:1;
            vuint32_t WL:1;
            vuint32_t UART:1;
        } B;
    } UARTCR;            /* UART Mode Control Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t SZF:1;
            vuint32_t OCF:1;
            vuint32_t PE3:1;
            vuint32_t PE2:1;
            vuint32_t PE1:1;
            vuint32_t PE0:1;
            vuint32_t RMB:1;
            vuint32_t FEF:1;
            vuint32_t BOF:1;
            vuint32_t RPS:1;
            vuint32_t WUF:1;
            vuint32_t:2;
            vuint32_t DRF:1;
            vuint32_t DTF:1;
            vuint32_t NF:1;
        } B;
    } UARTSR;            /* UART Mode Status Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:21;
            vuint32_t LTOM:1;
            vuint32_t IOT:1;
            vuint32_t TOCE:1;
            vuint32_t CNT:8;
        } B;
    } LINTCSR;            /* LIN Time-Out Control Status Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t OC2:8;
            vuint32_t OC1:8;
        } B;
    } LINOCR;            /* LIN Output Compare Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:20;
            vuint32_t RTO:4;
            vuint32_t:1;
            vuint32_t HTO:7;
        } B;
    } LINTOCR;            /* LIN Time-Out Control Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:28;
            vuint32_t DIV_F:4;
        } B;
    } LINFBRR;            /* LIN Fractional Baud Rate Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:19;
            vuint32_t DIV_M:13;
        } B;
    } LINIBRR;            /* LIN Integer Baud Rate Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t CF:8;
        } B;
    } LINCFR;            /* LIN Checksum Field Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:17;
            vuint32_t IOBE:1;
            vuint32_t IOPE:1;
            vuint32_t WURQ:1;
            vuint32_t DDRQ:1;
            vuint32_t DTRQ:1;
            vuint32_t ABRQ:1;
            vuint32_t HTRQ:1;
            vuint32_t:8;
        } B;
    } LINCR2;            /* LIN Control Register 2 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t DFL:6;
            vuint32_t DIR:1;
            vuint32_t CCS:1;
            vuint32_t:2;
            vuint32_t ID:6;
        } B;
    } BIDR;                /* Buffer Identifier Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t DATA3:8;
            vuint32_t DATA2:8;
            vuint32_t DATA1:8;
            vuint32_t DATA0:8;
        } B;
    } BDRL;                /* Buffer Data Register LSB */

    union {
        vuint32_t R;
        struct {
            vuint32_t DATA7:8;
            vuint32_t DATA6:8;
            vuint32_t DATA5:8;
            vuint32_t DATA4:8;
        } B;
    } BDRM;                /* Buffer Data Register MSB */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t FACT:16;
        } B;
    } IFER;                /* Identifier Filter Enable Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:27;
            vuint32_t IFMI:5;
        } B;
    } IFMI;                /* Identifier Filter Match Index Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t IFM:8;
        } B;
    } IFMR;                /* Identifier Filter Mode Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:19;
            vuint32_t DFL:3;
            vuint32_t DIR:1;
            vuint32_t CCS:1;
            vuint32_t:2;
            vuint32_t ID:6;
        } B;
    } IFCR[16];            /* Identifier Filter Control Register 0/15 */

};                        /* end of LINFLEX_tag */

/****************************************************************************/
/*                          MODULE : ME                                   */
/****************************************************************************/
struct ME_tag {

    union {
        vuint32_t R;
        struct {
            vuint32_t S_CURRENTMODE:4;
            vuint32_t S_MTRANS:1;
            vuint32_t:3;
            vuint32_t S_PDO:1;
            vuint32_t:2;
            vuint32_t S_MVR:1;
            vuint32_t S_DFLA:2;
            vuint32_t S_CFLA:2;
            vuint32_t:9;
            vuint32_t S_FMPLL_0:1;
            vuint32_t S_XOSC:1;
            vuint32_t S_IRC:1;
            vuint32_t S_SYSCLK:4;
        } B;
    } GS;               /* Global Status Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t TARGET_MODE:4;
            vuint32_t:12;
            vuint32_t KEY:16;
        } B;
    } MCTL;             /* Mode Control Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:21;
            vuint32_t STOP0:1;
            vuint32_t:1;
            vuint32_t HALT0:1;
            vuint32_t RUN3:1;
            vuint32_t RUN2:1;
            vuint32_t RUN1:1;
            vuint32_t RUN0:1;
            vuint32_t DRUN:1;
            vuint32_t SAFE:1;
            vuint32_t TEST:1;
            vuint32_t RESET_FUNC:1;
        } B;
    } MER;              /* Mode Enable Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:27;
            vuint32_t I_CONF_CU:1;
            vuint32_t I_CONF:1;
            vuint32_t I_MODE:1;
            vuint32_t I_SAFE:1;
            vuint32_t I_MTC:1;
        } B;
    } IS;               /* Interrupt Status Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:27;
            vuint32_t M_ICONF_CU:1;
            vuint32_t M_ICONF:1;
            vuint32_t M_IMODE:1;
            vuint32_t M_SAFE:1;
            vuint32_t M_MTC:1;
        } B;
    } IM;               /* Interrupt Mask Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:27;
            vuint32_t S_MTI:1;
            vuint32_t S_MRI:1;
            vuint32_t S_DMA:1;
            vuint32_t S_NMA:1;
            vuint32_t S_SEA:1;
        } B;
    } IMTS;             /* Invalid Mode Transition Status Register */

    union {
        vuint32_t R;    /* Data buffer in words (32 bits) */
        struct {
            vuint32_t PREVIOUS_MODE:4;
            vuint32_t:4;
            vuint32_t MPH_BUSY:1;
            vuint32_t:2;
            vuint32_t PMC_PROG:1;
            vuint32_t CORE_DBG:1;
            vuint32_t:2;
            vuint32_t SMR:1;
            vuint32_t:1;
            vuint32_t VREG_CSRC_SC:1;
            vuint32_t CSRC_CSRC_SC:1;
            vuint32_t IRC_SC:1;
            vuint32_t SCSRC_SC:1;
            vuint32_t SYSCLK_SW:1;
            vuint32_t DFLASH_SC:1;
            vuint32_t CFLASH_SC:1;
            vuint32_t CDP_PRPH_0_143:1;
            vuint32_t:3;
            vuint32_t CDP_PRPH_96_127:1;
            vuint32_t CDP_PRPH_64_95:1;
            vuint32_t CDP_PRPH_32_63:1;
            vuint32_t CDP_PRPH_0_31:1;
        } B;
    } DMTS;             /* Debug Mode Transition Status */

    vuint32_t ME_RESERVED_0[1]; /* 0x001C-0x001F */

    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t PDO:1;
            vuint32_t:2;
            vuint32_t MVRON:1;
            vuint32_t DFLAON:2;
            vuint32_t CFLAON:2;
            vuint32_t:9;
            vuint32_t FMPLL_0ON:1;
            vuint32_t XOSC0ON:1;
            vuint32_t IRCON:1;
            vuint32_t SYSCLK:4;
        } B;
    } RESET;            /* Reset Mode Configuration Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t PDO:1;
            vuint32_t:2;
            vuint32_t MVRON:1;
            vuint32_t DFLAON:2;
            vuint32_t CFLAON:2;
            vuint32_t:9;
            vuint32_t FMPLL_0ON:1;
            vuint32_t XOSC0ON:1;
            vuint32_t IRCON:1;
            vuint32_t SYSCLK:4;
        } B;
    } TEST;             /* Test Mode Configuration Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t PDO:1;
            vuint32_t:2;
            vuint32_t MVRON:1;
            vuint32_t DFLAON:2;
            vuint32_t CFLAON:2;
            vuint32_t:9;
            vuint32_t FMPLL_0ON:1;
            vuint32_t XOSC0ON:1;
            vuint32_t IRCON:1;
            vuint32_t SYSCLK:4;
        } B;
    } SAFE;             /* Safe Mode Configuration Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t PDO:1;
            vuint32_t:2;
            vuint32_t MVRON:1;
            vuint32_t DFLAON:2;
            vuint32_t CFLAON:2;
            vuint32_t:9;
            vuint32_t FMPLL_0ON:1;
            vuint32_t XOSC0ON:1;
            vuint32_t IRCON:1;
            vuint32_t SYSCLK:4;
        } B;
    } DRUN;             /* DRUN Mode Configuration Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t PDO:1;
            vuint32_t:2;
            vuint32_t MVRON:1;
            vuint32_t DFLAON:2;
            vuint32_t CFLAON:2;
            vuint32_t:9;
            vuint32_t FMPLL_0ON:1;
            vuint32_t XOSC0ON:1;
            vuint32_t IRCON:1;
            vuint32_t SYSCLK:4;
        } B;
    } RUN[4];               /* RUN 0->4 Mode Configuration Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t PDO:1;
            vuint32_t:2;
            vuint32_t MVRON:1;
            vuint32_t DFLAON:2;
            vuint32_t CFLAON:2;
            vuint32_t:9;
            vuint32_t FMPLL_0ON:1;
            vuint32_t XOSC0ON:1;
            vuint32_t IRCON:1;
            vuint32_t SYSCLK:4;
        } B;
    } HALT0;            /* HALT0 Mode Configuration Register */

    vuint32_t ME_RESERVED_1[1]; /* 0x0044-0x0047 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t PDO:1;
            vuint32_t:2;
            vuint32_t MVRON:1;
            vuint32_t DFLAON:2;
            vuint32_t CFLAON:2;
            vuint32_t:9;
            vuint32_t FMPLL_0ON:1;
            vuint32_t XOSC0ON:1;
            vuint32_t IRCON:1;
            vuint32_t SYSCLK:4;
        } B;
    } STOP0;            /* STOP0 Mode Configuration Register */

    vuint32_t ME_RESERVED_2[5]; /* 0x004C-0x005F */

    union {
        vuint32_t R;
        struct {
            vuint32_t:5;
            vuint32_t S_SAFETYPORT:1;
            vuint32_t:1;
            vuint32_t S_FLEXRAY:1;                
            vuint32_t:6;                
            vuint32_t S_FLEXCAN1:1;
            vuint32_t S_FLEXCAN0:1;
            vuint32_t:7;
            vuint32_t S_DSPI4:1;
            vuint32_t S_DSPI3:1;
            vuint32_t S_DSPI2:1;
            vuint32_t S_DSPI1:1;
            vuint32_t S_DSPI0:1;
            vuint32_t:4;
        } B;
    } PS0;            /* Peripheral Status Register 0 */        
    
    union {
        vuint32_t R;
        struct {
            vuint32_t:3;
            vuint32_t S_CRC1:1;
            vuint32_t:1;
            vuint32_t S_CRC0:1;                
            vuint32_t:8;                
            vuint32_t S_LIN_FLEX1:1;
            vuint32_t S_LIN_FLEX0:1;
            vuint32_t:8;
            vuint32_t S_ETIMER1:1;
            vuint32_t S_ETIMER0:1;
            vuint32_t:2;
            vuint32_t S_CTU0:1;
            vuint32_t:2;
            vuint32_t S_ADC0:1;
        } B;
    } PS1;            /* Peripheral Status Register 1 */            

    union {
        vuint32_t R;
        struct {
            vuint32_t:3;
            vuint32_t S_PIT_RTI:1;
            vuint32_t:28;
        } B;
    } PS2;            /* Peripheral Status Register 2 */

    union {
        vuint32_t R;
        struct {
            vuint32_t S_CORE1:1;
            vuint32_t:31;
        } B;
    } PS3;            /* Peripheral Status Register 3 */            

    vuint32_t ME_RESERVED_3[4]; /* 0x0070-0x007F */

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t RUN3:1;
            vuint32_t RUN2:1;
            vuint32_t RUN1:1;
            vuint32_t RUN0:1;
            vuint32_t DRUN:1;
            vuint32_t SAFE:1;
            vuint32_t TEST:1;
            vuint32_t RESET:1;
        } B;
    } RUNPC[8];         /* RUN Peripheral Configuration Register 0/7 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:21;
            vuint32_t STOP0:1;
            vuint32_t:1;
            vuint32_t HALT0:1;
            vuint32_t:8;
        } B;
    } LPPC[8];              /* Low Power Peripheral Configuration 0->7 Register */

    union {
        vuint8_t R;
        struct {
            vuint8_t:1;
            vuint8_t DBG_F:1;
            vuint8_t LP_CFG:3;
            vuint8_t RUN_CFG:3;
        } B;
    } PCTL[144];            /* Peripheral Control 0->143 Register */

};                          /* end of ME_tag */
/****************************************************************************/
/*                          MODULE : CGM                                    */
/****************************************************************************/
struct CGM_tag {

    union {                /* MC_CGM base address + 0x0000 */
        vuint32_t R;
        struct {
            vuint32_t OSCBYP:1;
            vuint32_t:7;
            vuint32_t EOCV:8;
            vuint32_t M_OSC:1;
            vuint32_t:7;
            vuint32_t I_OSC:1;
            vuint32_t:7;
        } B;
    } OSC_CTL;              /* Main OSC Control Register */

    vuint32_t CGM_RESERVED_0[23]; /* 0x0004-0x005F */

    union {               /* MC_CGM base address + 0x0060 */
        vuint32_t R;
        struct {
            vuint32_t:10;
            vuint32_t RCTRIM:6;
            vuint32_t:16;
        } B;
    } RC_CTL;               /* RC OSC Control Register */

    vuint32_t CGM_RESERVED_1[15]; /* 0x0064-0x009F */

    struct {               /* MC_CGM base address + 0x00A0 */
        union {
            vuint32_t R;
            struct {
                vuint32_t:2;
                vuint32_t IDF:4;
                vuint32_t ODF:2;
                vuint32_t:1;
                vuint32_t NDIV:7;
                vuint32_t:7;
                vuint32_t EN_PLL_SW:1;
                vuint32_t:1;
                vuint32_t UNLOCK_ONCE:1;
                vuint32_t:1;
                vuint32_t I_LOCK:1;
                vuint32_t S_LOCK:1;
                vuint32_t PLL_FAIL_MASK:1;
                vuint32_t PLL_FAIL_FLAG:1;
                vuint32_t:1;
            } B;
        } CR;               /* FMPLL Control Register */

        union {
            vuint32_t R;
            struct {
                vuint32_t STRB_BYPASS:1;
                vuint32_t:1;
                vuint32_t SPRD_SEL:1;
                vuint32_t MOD_PERIOD:13;
                vuint32_t FM_EN:1;
                vuint32_t INC_STEP:15;
            } B;
        } MR;               /* FMPLL Modulation Register */

    } FMPLL[1];

    vuint32_t CGM_RESERVED_2[22]; /* 0x00A8-0x00FF */

    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t SFM:1;
            vuint32_t:20;
            vuint32_t RCDIV:2;
            vuint32_t CME_0:1;
        } B;
    } CMU_0_CSR;        /* Control Status Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:12;
            vuint32_t FD:20;
        } B;
    } CMU_0_FDR;        /* Frequency Display Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:20;
            vuint32_t HFREF:12;
        } B;
    } CMU_0_HFREFR_0;    /* High Frequency Reference Register FMPLL_0 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:20;
            vuint32_t LFREF:12;
        } B;
    } CMU_0_LFREFR_0;    /* Low Frequency Reference Register FMPLL_0 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:28;
            vuint32_t FLCI_0:1;
            vuint32_t FHHI_0:1;
            vuint32_t FLLI_0:1;
            vuint32_t OLRI:1;
        } B;
    } CMU_0_ISR;        /* Interrupt Status Register */

    vuint32_t CGM_RESERVED_3[1]; /* 0x0014-0x0017 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:12;
            vuint32_t MD:20;
        } B;
    } CMU_0_MDR;        /* Measurement Duration Register */

    vuint32_t CGM_RESERVED_4[1]; /* 0x001C-0x001F */

    union {                /* MC_CGM base address + 0x0120 */
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t CME_1:1;
        } B;
    } CMU_1_CSR;        /* Control Status Register */

    vuint32_t CGM_RESERVED_5[1]; /* 0x0024-0x0027 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:20;
            vuint32_t HFREF:12;
        } B;
    } CMU_1_HFREFR_0;    /* High Frequency Reference Register FMPLL_0 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:20;
            vuint32_t LFREF:12;
        } B;
    } CMU_1_LFREFR_0;    /* Low Frequency Reference Register FMPLL_0 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:28;
            vuint32_t FLCI_1:1;
            vuint32_t FHHI_1:1;
            vuint32_t FLLI_1:1;
            vuint32_t:1;
        } B;
    } CMU_1_ISR;        /* Interrupt Status Register */

    vuint32_t CGM_RESERVED_6[11]; /* 0x0134-0x015F */

    union {                /* MC_CGM base address + 0x0160 */
        vuint32_t R;
        struct {
            vuint32_t DIV:8;
            vuint32_t:24;
        } B;
    } CLK_DIV_256;        /* Output Clock Division 256 Select Register */        

    vuint32_t CGM_RESERVED_7[131]; /* 0x0164-0x036F */

    union {                /* MC_CGM base address + 0x0370 */
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t EN:1;
        } B;
    } OCEN;                 /* Output Clock Enable Register */

    union {                 /* 0x374 */
        vuint32_t R;
        struct {
            vuint32_t:2;
            vuint32_t SELDIV:2;
            vuint32_t SELCTL:4;
            vuint32_t:24;
        } B;
    } OCDSSC;               /* Output Clock Division Select Register */

    union {                 /* 0x378 */
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t SELSTAT:4;
            vuint32_t:24;
        } B;
    } SCSS;             /* System Clock Select Status */

    vuint32_t CGM_RESERVED_8[1]; /* 0x037C-0x037F */

    union {                 /* 0x380 */
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t SELCTL:4;
            vuint32_t:24;
        } B;
    } AC0SC;             /* Aux Clock 0 Select Control */

    union {                 /* 0x384 */
        vuint32_t R;
        struct {
            vuint32_t DE0:1;
            vuint32_t:3;
            vuint32_t DIV0:4;
            vuint32_t:24;
        } B;
    } AC0DC;                /* Aux Clock 0 Divider Configuration 0->3 */

    union {                 /* 0x388 */
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t SELCTL:4;
            vuint32_t:24;
        } B;
    } AC1SC;             /* Aux Clock 1 Select Control */

    union {                 /* 0x38C */
        vuint32_t R;
        struct {
            vuint32_t DE0:1;
            vuint32_t:3;
            vuint32_t DIV0:4;
            vuint32_t:24;
        } B;
    } AC1DC;                /* Aux Clock 1 Divider Configuration 0->3 */

    union {                 /* 0x390 */
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t SELCTL:4;
            vuint32_t:24;
        } B;
    } AC2SC;             /* Aux Clock 2 Select Control */

    union {                 /* 0x394 */
        vuint32_t R;
        struct {
            vuint32_t DE0:1;
            vuint32_t:3;
            vuint32_t DIV0:4;
            vuint32_t:24;
        } B;
    } AC2DC;                /* Aux Clock 2 Divider Configuration 0->3 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t SELCTL:4;
            vuint32_t:24;
        } B;
    } AC3SC;             /* Aux Clock 3 Select Control */

    union {
        vuint32_t R;
        struct {
            vuint32_t DE0:1;
            vuint32_t:3;
            vuint32_t DIV0:4;
            vuint32_t:24;
        } B;
    } AC3DC;                /* Aux Clock 3 Divider Configuration 0->3 */
};                          /* end of CGM_tag */
/****************************************************************************/
/*                          MODULE : RGM                                   */
/****************************************************************************/
struct RGM_tag {

    union {
        vuint16_t R;
        struct {
            vuint16_t F_EXR:1;
            vuint16_t:3;
            vuint16_t F_CMU1_FHL:1;
            vuint16_t:2;
            vuint16_t F_FLASH:1;
            vuint16_t F_LVD45:1;
            vuint16_t F_CMU0_FHL:1;
            vuint16_t F_CMU0_OLR:1;
            vuint16_t F_PLL0:1;
            vuint16_t F_CHKSTOP:1;
            vuint16_t F_SOFT:1;
            vuint16_t F_CORE:1;
            vuint16_t F_JTAG:1;
        } B;
    } FES;                /* Functional Event Status */

    union {
        vuint16_t R;
        struct {
            vuint16_t F_POR:1;
            vuint16_t:8;
            vuint16_t F_LVD27_IO:1;
            vuint16_t F_LVD27_FLASH:1;
            vuint16_t F_LVD27_VREG:1;
            vuint16_t F_SWT1:1;
            vuint16_t F_SWT0:1;
            vuint16_t:1;
            vuint16_t F_LVD12:1;
        } B;
    } DES;                /* Destructive Event Status */

    union {
        vuint16_t R;
        struct {
            vuint16_t D_EXR:1;
            vuint16_t:3;
            vuint16_t D_CMU1_FHL:1;
            vuint16_t:2;
            vuint16_t D_FLASH:1;
            vuint16_t D_LVD45:1;
            vuint16_t D_CMU0_FHL:1;
            vuint16_t D_CMU0_OLR:1;
            vuint16_t D_PLL0:1;
            vuint16_t D_CHKSTOP:1;
            vuint16_t D_SOFT:1;
            vuint16_t D_CORE:1;
            vuint16_t D_JTAG:1;
        } B;
    } FERD;                /* Functional Event Reset Disable */

    union {
        vuint16_t R;
        struct {
            vuint16_t:9;
            vuint16_t D_LVD27_IO:1;
            vuint16_t D_LVD27_FLASH:1;
            vuint16_t D_LVD27_VREG:1;
            vuint16_t D_SWT1:1;
            vuint16_t D_SWT0:1;
            vuint16_t:1;
            vuint16_t D_LVD12:1;
        } B;
    } DERD;                /* Destructive Event Reset Disable */

    vuint16_t RGM_RESERVED_0[4]; /* 0x0008-0x000F */

    union {
        vuint16_t R;
        struct {
            vuint16_t:4;
            vuint16_t AR_CMU1_FHL:1;
            vuint16_t:3;
            vuint16_t AR_LVD45:1;
            vuint16_t AR_CMU0_FHL:1;
            vuint16_t AR_CMU0_OLR:1;
            vuint16_t AR_PLL0:1;
            vuint16_t:2;
            vuint16_t AR_CORE:1;
            vuint16_t AR_JTAG:1;
        } B;
    } FEAR;                /* Functional Event Alternate Request */

    vuint16_t RGM_RESERVED_1[3]; /* 0x0012-0x0017 */

    union {
        vuint16_t R;
        struct {
            vuint16_t SS_EXR:1;
            vuint16_t:3;
            vuint16_t SS_CMU1_FHL:1;
            vuint16_t:2;
            vuint16_t SS_FLASH:1;
            vuint16_t SS_LVD45:1;
            vuint16_t SS_CMU0_FHL:1;
            vuint16_t SS_CMU0_OLR:1;
            vuint16_t SS_PLL0:1;
            vuint16_t SS_CHKSTOP:1;
            vuint16_t SS_SOFT:1;
            vuint16_t SS_CORE:1;
            vuint16_t SS_JTAG:1;
        } B;
    } FESS;               /* Functional Event Short Sequence */
    
    vuint16_t RGM_RESERVED_2;      /* 0x001A-0x001B */

    union {
        vuint16_t R;
        struct {
            vuint16_t BE_EXR:1;
            vuint16_t:3;
            vuint16_t BE_CMU1_FHL:1;
            vuint16_t:2;
            vuint16_t BE_FLASH:1;
            vuint16_t BE_LVD45:1;
            vuint16_t BE_CMU0_FHL:1;
            vuint16_t BE_CMU0_OLR:1;
            vuint16_t BE_PLL0:1;
            vuint16_t BE_CHKSTOP:1;
            vuint16_t BE_SOFT:1;
            vuint16_t BE_CORE:1;
            vuint16_t BE_JTAG:1;
        } B;
    } FBRE;               /* Functional Bidirectional Reset Enable */

};                          /* end of RGM_tag */
/****************************************************************************/
/*                          MODULE : PCU                                   */
/****************************************************************************/
struct PCU_tag {

    union {
       vuint32_t R;    /* Data buffer in words (32 bits) */
       struct {
           vuint32_t:18;
           vuint32_t STBY0:1;
           vuint32_t:2;
           vuint32_t STOP0:1;
           vuint32_t:1;
           vuint32_t HALT0:1;
           vuint32_t RUN3:1;
           vuint32_t RUN2:1;
           vuint32_t RUN1:1;
           vuint32_t RUN0:1;
           vuint32_t DRUN:1;
           vuint32_t SAFE:1;
           vuint32_t TEST:1;
           vuint32_t RST:1;
       } B;
    } PCONF0;        /* Power Domain #0 Configuration Register */

    vuint32_t PCU_RESERVED_0[15]; /* 0x0004-0x003F */

    union {
       vuint32_t R;    /* Data buffer in words (32 bits) */
       struct {
           vuint32_t:31;
           vuint32_t PD0:1;
       } B;
    } PCU_PSTAT;        /* Power Domain Status Register */

    vuint32_t PCU_RESERVED_1[15]; /* 0x0044-0x007F */
    
    union {
       vuint32_t R;    /* Data buffer in words (32 bits) */
       struct {
           vuint32_t :31;
           vuint32_t MASK_LVD_5V:1;
       } B;
    } VREG_CTL;            /* Voltage Regulator Control Register */

    union {
       vuint32_t R;    /* Data buffer in words (32 bits) */
       struct {
           vuint32_t :31;
           vuint32_t STATUS_LVD_5V:1;
       } B;
    } VREG_STATUS;        /* Voltage Regulator Status Register */

};                        /* end of PCU_tag */
/****************************************************************************/
/*                          MODULE : ETIMER                                 */
/****************************************************************************/
struct ETIMER_CHANNEL_tag {

    union {
        vuint16_t R;
        struct {
            vuint16_t COMP1:16;
        } B;
    } COMP1;            /* Compare Register 1 */

    union {
        vuint16_t R;
        struct {
            vuint16_t COMP2:16;
        } B;
    } COMP2;            /* Compare Register 2 */

    union {
        vuint16_t R;
        struct {
            vuint16_t CAPT1:16;
        } B;
    } CAPT1;            /* Capture Register 1 */

    union {
        vuint16_t R;
        struct {
            vuint16_t CAPT2:16;
        } B;
    } CAPT2;            /* Capture Register 2 */

    union {
        vuint16_t R;
        struct {
            vuint16_t LOAD:16;
        } B;
    } LOAD;                /* Load Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t HOLD:16;
        } B;
    } HOLD;                /* Hold Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t CNTR:16;
        } B;
    } CNTR;                /* Counter Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t CNTMODE:3;
            vuint16_t PRISRC:5;
            vuint16_t ONCE:1;
            vuint16_t LENGTH:1;
            vuint16_t DIR:1;
            vuint16_t SECSRC:5;
        } B;
    } CTRL;                 /* Control Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t OEN:1;
            vuint16_t RDNT:1;
            vuint16_t INPUT:1;
            vuint16_t VAL:1;
            vuint16_t FORCE:1;  /* Write only, read as 0 */
            vuint16_t COFRC:1;
            vuint16_t COINIT:2;
            vuint16_t SIPS:1;
            vuint16_t PIPS:1;
            vuint16_t OPS:1;
            vuint16_t MSTR:1;
            vuint16_t OUTMODE:4;
        } B;
    } CTRL2;            /* Control Register 2 */

    union {
        vuint16_t R;
        struct {
            vuint16_t STPEN:1;
            vuint16_t ROC:2;
            vuint16_t:5;
            vuint16_t C2FCNT:3;
            vuint16_t C1FCNT:3;
            vuint16_t DBGEN:2;
        } B;
    } CTRL3;            /* Control Register 3 */

    union {
        vuint16_t R;
        struct {
            vuint16_t:6;
            vuint16_t WDF:1;
            vuint16_t RCF:1;
            vuint16_t ICF2:1;
            vuint16_t ICF1:1;
            vuint16_t IEHF:1;
            vuint16_t IELF:1;
            vuint16_t TOF:1;
            vuint16_t TCF2:1;
            vuint16_t TCF1:1;
            vuint16_t TCF:1;
        } B;
    } STS;                /* Status Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t ICF2DE:1;
            vuint16_t ICF1DE:1;
            vuint16_t CMPLD2DE:1;
            vuint16_t CMPLD1DE:1;
            vuint16_t:2;
            vuint16_t WDFIE:1;
            vuint16_t RCFIE:1;
            vuint16_t ICF2IE:1;
            vuint16_t ICF1IE:1;
            vuint16_t IEHFIE:1;
            vuint16_t IELFIE:1;
            vuint16_t TOFIE:1;
            vuint16_t TCF2IE:1;
            vuint16_t TCF1IE:1;
            vuint16_t TCFIE:1;
        } B;
    } INTDMA;            /* Interrupt and DMA Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t CMPLD1:16;
        } B;
    } CMPLD1;            /* Compare Load Register 1 */

    union {
        vuint16_t R;
        struct {
            vuint16_t CMPLD2:16;
        } B;
    } CMPLD2;            /* Compare Load Register 2 */

    union {
        vuint16_t R;
        struct {
            vuint16_t CLC2:3;
            vuint16_t CLC1:3;
            vuint16_t CMPMODE:2;
            vuint16_t CPT2MODE:2;
            vuint16_t CPT1MODE:2;
            vuint16_t CFWM:2;
            vuint16_t ONESHOT:1;
            vuint16_t ARM:1;
        } B;
    } CCCTRL;            /* Compare and Capture Control Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t:5;
            vuint16_t FILT_CNT:3;
            vuint16_t FILT_PER:8;
        } B;
    } FILT;                /* Input Filter Register */

};                          /* end of ETIMER_CHANNEL_tag */

struct ETIMER_tag {

    struct ETIMER_CHANNEL_tag CHANNEL[6];

    vuint16_t ETIMER_RESERVED_0[32]; /* 0x00C0�0x00FF */

    union {
        vuint16_t R;
        struct {
            vuint16_t WDTOL:16;
        } B;
    } WDTOL;            /* Watchdog Time-out Low Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t WDTOH:16;
        } B;
    } WDTOH;            /* Watchdog Time-out High Register */

    vuint16_t ETIMER_RESERVED_1[4]; /* 0x0104�0x010B */ 
    
    union {
        vuint16_t R;
        struct {
            vuint16_t:10;
            vuint16_t ENBL:6;
        } B;
    } ENBL;                /* Channel Enable Register */

    int16_t ETIMER_RESERVED_2;

    union {
        vuint16_t R;
        struct {
            vuint16_t DREQEN:1;
            vuint16_t:10;
            vuint16_t DREQ:5;
        } B;
    } DREQ[2];              /* DMA Request 0->3 Select Register */

};                        /* end of ETIMER_tag */
/****************************************************************************/
/*                          MODULE : CTU                                    */
/****************************************************************************/
struct CTU_tag {

    union {
        vuint32_t R;
        struct {
            vuint32_t I15_FE:1;
            vuint32_t I15_RE:1;
            vuint32_t I14_FE:1;
            vuint32_t I14_RE:1;
            vuint32_t I13_FE:1;
            vuint32_t I13_RE:1;
            vuint32_t I12_FE:1;
            vuint32_t I12_RE:1;
            vuint32_t I11_FE:1;
            vuint32_t I11_RE:1;
            vuint32_t I10_FE:1;
            vuint32_t I10_RE:1;
            vuint32_t I9_FE:1;
            vuint32_t I9_RE:1;
            vuint32_t I8_FE:1;
            vuint32_t I8_RE:1;
            vuint32_t I7_FE:1;
            vuint32_t I7_RE:1;
            vuint32_t I6_FE:1;
            vuint32_t I6_RE:1;
            vuint32_t I5_FE:1;
            vuint32_t I5_RE:1;
            vuint32_t I4_FE:1;
            vuint32_t I4_RE:1;
            vuint32_t I3_FE:1;
            vuint32_t I3_RE:1;
            vuint32_t I2_FE:1;
            vuint32_t I2_RE:1;
            vuint32_t I1_FE:1;
            vuint32_t I1_RE:1;
            vuint32_t I0_FE:1;
            vuint32_t I0_RE:1;
        } B;
    } TGSISR;               /* -Trigger Generator Subunit Input Selection Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t:7;
            vuint16_t ET_TM:1;
            vuint16_t PRES:2;
            vuint16_t MRS_SM:5;
            vuint16_t TGS_M:1;
        } B;
    } TGSCR;                /* Trigger Generator Subunit Control Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t TCRV:16;
        } B;
    } TCR[8];               /* Trigger 0->7 Compare Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t TGSCCV:16;
        } B;
    } TGSCCR;            /* TGS Counter Compare Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t TGSCRV:16;
        } B;
    } TGSCRR;            /* TGS Counter Reload Register */

    uint16_t CTU_RESERVED_0;    /* 0x001A-0x001B */

    union {
        vuint32_t R;
        struct {
            vuint32_t:3;
            vuint32_t T3INDEX:5;
            vuint32_t:3;
            vuint32_t T2INDEX:5;
            vuint32_t:3;
            vuint32_t T1INDEX:5;
            vuint32_t:3;
            vuint32_t T0INDEX:5;
        } B;
    } CLCR1;            /* Command List Control Register 1 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:3;
            vuint32_t T7INDEX:5;
            vuint32_t:3;
            vuint32_t T6INDEX:5;
            vuint32_t:3;
            vuint32_t T5INDEX:5;
            vuint32_t:3;
            vuint32_t T4INDEX:5;
        } B;
    } CLCR2;            /* Command List Control Register 2 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:3;
            vuint32_t T3E:1;
            vuint32_t T3ETE:1;
            vuint32_t T3T1E:1;
            vuint32_t T3T0E:1;
            vuint32_t T3ADCE:1;
            vuint32_t:3;
            vuint32_t T2E:1;
            vuint32_t T2ETE:1;
            vuint32_t T2T1E:1;
            vuint32_t T2T0E:1;
            vuint32_t T2ADCE:1;
            vuint32_t:3;
            vuint32_t T1E:1;
            vuint32_t T1ETE:1;
            vuint32_t T1T1E:1;
            vuint32_t T1T0E:1;
            vuint32_t T1ADCE:1;
            vuint32_t:3;
            vuint32_t T0E:1;
            vuint32_t T0ETE:1;
            vuint32_t T0T1E:1;
            vuint32_t T0T0E:1;
            vuint32_t T0ADCE:1;
        } B;
    } THCR1;            /* Trigger Handler Control Register 1 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:3;
            vuint32_t T7E:1;
            vuint32_t T7ETE:1;
            vuint32_t T7T1E:1;
            vuint32_t T7T0E:1;
            vuint32_t T7ADCE:1;
            vuint32_t:3;
            vuint32_t T6E:1;
            vuint32_t T6ETE:1;
            vuint32_t T6T1E:1;
            vuint32_t T6T0E:1;
            vuint32_t T6ADCE:1;
            vuint32_t:3;
            vuint32_t T5E:1;
            vuint32_t T5ETE:1;
            vuint32_t T5T1E:1;
            vuint32_t T5T0E:1;
            vuint32_t T5ADCE:1;
            vuint32_t:3;
            vuint32_t T4E:1;
            vuint32_t T4ETE:1;
            vuint32_t T4T1E:1;
            vuint32_t T4T0E:1;
            vuint32_t T4ADCE:1;
        } B;
    } THCR2;            /* Trigger Handler Control Register 2 */

    /* Single-Dual  Conversion Mode  */
    /* Use CTU_0.CLR[i].SCM.SU to refer the BU field in Single Conversion */
    /* Use CTU_0.CLR[i].DCM.CH_B to refer the CH_B field in Dual Conversion */
    union {
        vuint16_t R;
        struct {
            vuint16_t CIR:1;
            vuint16_t FC:1;
            vuint16_t CMS:1;
            vuint16_t:1;
            vuint16_t FIFO:2;
            vuint16_t:4;
            vuint16_t SU:1;
            vuint16_t:1;
            vuint16_t CH:4;
        } SCM;        /* Single Conversion Mode */
        struct {                          
            vuint16_t CIR:1;                
            vuint16_t FC:1;                 
            vuint16_t CMS:1;                
            vuint16_t:1;
            vuint16_t FIFO:2;               
            vuint16_t:1;                   
            vuint16_t CH_B:4;                
            vuint16_t:1;                   
            vuint16_t CH_A:4;
        } DCM;        /* Dual Conversion Mode */
    } CLR[24];            /* Commands List Register 1/24 */

    vuint16_t CTU_RESERVED_1[8]; /* 0x005C�0x006B */

    union {
        vuint16_t R;
        struct {
            vuint16_t:12;
            vuint16_t DE3:1;
            vuint16_t DE2:1;
            vuint16_t DE1:1;
            vuint16_t DE0:1;
        } B;
    } FDCR;                /* FIFO DMA Control Register */

    uint16_t CTU_RESERVED_2;
    
    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t OR_EN3:1;
            vuint32_t OF_EN3:1;
            vuint32_t EMPTY_EN3:1;
            vuint32_t FULL_EN3:1;
            vuint32_t OR_EN2:1;
            vuint32_t OF_EN2:1;
            vuint32_t EMPTY_EN2:1;
            vuint32_t FULL_EN2:1;
            vuint32_t OR_EN1:1;
            vuint32_t OF_EN1:1;
            vuint32_t EMPTY_EN1:1;
            vuint32_t FULL_EN1:1;
            vuint32_t OR_EN0:1;
            vuint32_t OF_EN0:1;
            vuint32_t EMPTY_EN0:1;
            vuint32_t FULL_EN0:1;                
        } B;
    } FCR;                /* FIFO Control Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t TH3:8;
            vuint32_t TH2:8;
            vuint32_t TH1:8;
            vuint32_t TH0:8;
        } B;
    } FTH;                /* FIFO Threshold Register */

    vuint16_t CTU_RESERVED_3[2]; /* 0x0078�0x007B */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t OR3:1;
            vuint32_t OF3:1;
            vuint32_t EMP3:1;
            vuint32_t FULL3:1;
            vuint32_t OR2:1;
            vuint32_t OF2:1;
            vuint32_t EMP2:1;
            vuint32_t FULL2:1;
            vuint32_t OR1:1;
            vuint32_t OF1:1;
            vuint32_t EMP1:1;
            vuint32_t FULL1:1;
            vuint32_t OR0:1;
            vuint32_t OF0:1;
            vuint32_t EMP0:1;
            vuint32_t FULL0:1;
        } B;
    } FST;                /* FIFO Status Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:11;
            vuint32_t N_CH:5;
            vuint32_t:6;
            vuint32_t DATA:10;
        } B;
    } FR[4];            /* FIFO Right aligned data register */

    vuint16_t CTU_RESERVED_4[8]; /* 0x0090�0x009F */
    
    union {
        vuint32_t R;
        struct {
            vuint32_t:11;
            vuint32_t N_CH:5;
            vuint32_t:1;
            vuint32_t DATA:10;
            vuint32_t:5;
        } B;
    } FL[4];            /* FIFO Left aligned data register */

    vuint32_t CTU_RESERVED_5[8]; /* 0x00B0�0x00BF */
    
    union {
        vuint16_t R;
        struct {
            vuint16_t:7;
            vuint16_t ET_OE:1;
            vuint16_t T1_OE:1;
            vuint16_t T0_OE:1;
            vuint16_t ADC_OE:1;
            vuint16_t TGS_OSM:1;
            vuint16_t MRS_O:1;
            vuint16_t ICE:1;
            vuint16_t SM_TO:1;
            vuint16_t MRS_RE:1;
        } B;
    } CTUEFR;            /* CTU Error Flag Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t:6;
            vuint16_t ADC_I:1;
            vuint16_t T7_I:1;
            vuint16_t T6_I:1;
            vuint16_t T5_I:1;
            vuint16_t T4_I:1;
            vuint16_t T3_I:1;
            vuint16_t T2_I:1;
            vuint16_t T1_I:1;
            vuint16_t T0_I:1;
            vuint16_t MRS_I:1;
        } B;
    } CTUIFR;            /* CTU Interrupt Flag Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t T7_IE:1;
            vuint16_t T6_IE:1;
            vuint16_t T5_IE:1;
            vuint16_t T4_IE:1;
            vuint16_t T3_IE:1;
            vuint16_t T2_IE:1;
            vuint16_t T1_IE:1;
            vuint16_t T0_IE:1;
            vuint16_t:5;
            vuint16_t MRS_DMAE:1;
            vuint16_t MRS_IE:1;
            vuint16_t IEE:1;
        } B;
    } CTUIR;            /* CTU Interrupt Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t:8;
            vuint16_t COTR:8;
        } B;
    } COTR;                /* Control On-Time Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t T7_SG:1;
            vuint16_t T6_SG:1;
            vuint16_t T5_SG:1;
            vuint16_t T4_SG:1;
            vuint16_t T3_SG:1;
            vuint16_t T2_SG:1;
            vuint16_t T1_SG:1;
            vuint16_t T0_SG:1;
            vuint16_t CTU_ADC_R:1;
            vuint16_t CTU_ODIS:1;
            vuint16_t DFE:1;
            vuint16_t CGRE:1;
            vuint16_t FGRE:1;
            vuint16_t MRS_SG:1;
            vuint16_t GRE:1;
            vuint16_t TGSISR_RE:1;
        } B;
    } CTUCR;            /* CTU Control Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t:8;
            vuint16_t N:8;
        } B;
    } CTUDF;            /* CTU Digital Filter Register */

    union {
        vuint16_t R;
        struct {
            vuint16_t:15;
            vuint16_t MDIS:1;
        } B;
    } CTUPCR;            /* CTU Power Control Register */
    
};                        /* end of CTU_tag */
/****************************************************************************/
/*                          MODULE : PIT                                    */
/****************************************************************************/
struct PIT_tag {

    union {
        vuint32_t R;
        struct {
            vuint32_t:30;
            vuint32_t MDIS:1;
            vuint32_t FRZ:1;
        } B;
    } PITMCR;            /* PIT Module Control Register */

    vuint32_t PIT_RESERVED_0[63];    /* 0x0004-0x00FF */
    
    struct {
        union {
            vuint32_t R;
            struct {
                vuint32_t TSV:32;
            } B;
        } LDVAL;
    
        union {
            vuint32_t R;
            struct {
                vuint32_t TVL:32;
            } B;
        } CVAL;
    
        union {
            vuint32_t R;
            struct {
                vuint32_t:30;
                vuint32_t TIE:1;
                vuint32_t TEN:1;
            } B;
        } TCTRL;
    
        union {
            vuint32_t R;
            struct {
                vuint32_t:31;
                vuint32_t TIF:1;
            } B;
        } TFLG;
    } CH[4];

};                        /* end of PIT_tag */
/****************************************************************************/
/*                          MODULE : eDMA                                   */
/****************************************************************************/

/*for "standard" format TCD (when EDMA.TCD[x].CITER.E_LINK==BITER.E_LINK=0) */
struct EDMA_TCD_STD_tag {

    vuint32_t SADDR;        /* source address */

    vuint16_t SMOD:5;       /* source address modulo */
    vuint16_t SSIZE:3;      /* source transfer size */
    vuint16_t DMOD:5;       /* destination address modulo */
    vuint16_t DSIZE:3;      /* destination transfer size */
    vint16_t SOFF;          /* signed source address offset */

    vuint32_t NBYTES;       /* inner (�minor�) byte count */

    vint32_t SLAST;         /* last destination address adjustment, or
                                   scatter/gather address (if e_sg = 1) */

    vuint32_t DADDR;        /* destination address */

    vuint16_t CITERE_LINK:1;
    vuint16_t CITER:15;

    vint16_t DOFF;          /* signed destination address offset */

    vint32_t DLAST_SGA;

    vuint16_t BITERE_LINK:1;        /* beginning ("major") iteration count */
    vuint16_t BITER:15;

    vuint16_t BWC:2;        /* bandwidth control */
    vuint16_t MAJORLINKCH:6;        /* enable channel-to-channel link */
    vuint16_t DONE:1;       /* channel done */
    vuint16_t ACTIVE:1;     /* channel active */
    vuint16_t MAJORE_LINK:1;        /* enable channel-to-channel link */
    vuint16_t E_SG:1;       /* enable scatter/gather descriptor */
    vuint16_t D_REQ:1;      /* disable ipd_req when done */
    vuint16_t INT_HALF:1;   /* interrupt on citer = (biter >> 1) */
    vuint16_t INT_MAJ:1;    /* interrupt on major loop completion */
    vuint16_t START:1;      /* explicit channel start */

};                          /* end of EDMA_TCD_STD_tag */

/*for "channel link" format TCD (when EDMA.TCD[x].CITER.E_LINK==BITER.E_LINK=1)*/
struct EDMA_TCD_CHLINK_tag {

    vuint32_t SADDR;        /* source address */

    vuint16_t SMOD:5;       /* source address modulo */
    vuint16_t SSIZE:3;      /* source transfer size */
    vuint16_t DMOD:5;       /* destination address modulo */
    vuint16_t DSIZE:3;      /* destination transfer size */
    vint16_t SOFF;          /* signed source address offset */

    vuint32_t NBYTES;       /* inner (�minor�) byte count */

    vint32_t SLAST;         /* last destination address adjustment, or
                                   scatter/gather address (if e_sg = 1) */

    vuint32_t DADDR;        /* destination address */

    vuint16_t CITERE_LINK:1;
    vuint16_t CITERLINKCH:6;
    vuint16_t CITER:9;

    vint16_t DOFF;          /* signed destination address offset */

    vint32_t DLAST_SGA;

    vuint16_t BITERE_LINK:1;        /* beginning (�major�) iteration count */
    vuint16_t BITERLINKCH:6;
    vuint16_t BITER:9;

    vuint16_t BWC:2;        /* bandwidth control */
    vuint16_t MAJORLINKCH:6;        /* enable channel-to-channel link */
    vuint16_t DONE:1;       /* channel done */
    vuint16_t ACTIVE:1;     /* channel active */
    vuint16_t MAJORE_LINK:1;        /* enable channel-to-channel link */
    vuint16_t E_SG:1;       /* enable scatter/gather descriptor */
    vuint16_t D_REQ:1;      /* disable ipd_req when done */
    vuint16_t INT_HALF:1;   /* interrupt on citer = (biter >> 1) */
    vuint16_t INT_MAJ:1;    /* interrupt on major loop completion */
    vuint16_t START:1;      /* explicit channel start */

};                          /* end of EDMA_TCD_CHLINK_tag */

struct EDMA_tag {

    union {
        vuint32_t R;
        struct {
            vuint32_t:29;
            vuint32_t ERCA:1;
            vuint32_t EDBG:1;
            vuint32_t:1;
        } B;
    } CR;                   /* Control Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t VLD:1;
            vuint32_t:16;
            vuint32_t CPE:1;
            vuint32_t ERRCHN:6;
            vuint32_t SAE:1;
            vuint32_t SOE:1;
            vuint32_t DAE:1;
            vuint32_t DOE:1;
            vuint32_t NCE:1;
            vuint32_t SGE:1;
            vuint32_t SBE:1;
            vuint32_t DBE:1;
        } B;
    } ESR;                  /* Error Status Register */

    vuint32_t EDMA_RESERVED_0[1]; /* 0x0008�0x000B */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t ERQ15:1;
            vuint32_t ERQ14:1;
            vuint32_t ERQ13:1;
            vuint32_t ERQ12:1;
            vuint32_t ERQ11:1;
            vuint32_t ERQ10:1;
            vuint32_t ERQ09:1;
            vuint32_t ERQ08:1;
            vuint32_t ERQ07:1;
            vuint32_t ERQ06:1;
            vuint32_t ERQ05:1;
            vuint32_t ERQ04:1;
            vuint32_t ERQ03:1;
            vuint32_t ERQ02:1;
            vuint32_t ERQ01:1;
            vuint32_t ERQ00:1;
        } B;
    } ERQRL;        /* eDMA Enable Request Register */

    vuint32_t EDMA_RESERVED_1[1]; /* 0x0010�0x0013 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t EEI15:1;
            vuint32_t EEI14:1;
            vuint32_t EEI13:1;
            vuint32_t EEI12:1;
            vuint32_t EEI11:1;
            vuint32_t EEI10:1;
            vuint32_t EEI09:1;
            vuint32_t EEI08:1;
            vuint32_t EEI07:1;
            vuint32_t EEI06:1;
            vuint32_t EEI05:1;
            vuint32_t EEI04:1;
            vuint32_t EEI03:1;
            vuint32_t EEI02:1;
            vuint32_t EEI01:1;
            vuint32_t EEI00:1;
        } B;
    } EEIRL;                /* DMA Enable Error Interrupt Register Low */

    union {
        vuint8_t R;
        struct {
            vuint8_t:1;
            vuint8_t SERQ:7;
        } B;
    } SERQR;                /* DMA Set Enable Request Register */

    union {
        vuint8_t R;
        struct {
            vuint8_t:1;
            vuint8_t CERQ:7;
        } B;
    } CERQR;                /* DMA Clear Enable Request Register */

    union {
        vuint8_t R;
        struct {
            vuint8_t:1;
            vuint8_t SEEI:7;
        } B;
    } SEEIR;                /* DMA Set Enable Error Interrupt Register */

    union {
        vuint8_t R;
        struct {
            vuint8_t:1;
            vuint8_t CEEI:7;
        } B;
    } CEEIR;                /* DMA Clear Enable Error Interrupt Register */

    union {
        vuint8_t R;
        struct {
            vuint8_t:1;
            vuint8_t CINT:7;
        } B;
    } CIRQR;                /* DMA Clear Interrupt Request Register */

    union {
        vuint8_t R;
        struct {
            vuint8_t:1;
            vuint8_t CER:7;
        } B;
    } CERR;                 /* DMA Clear error Register */

    union {
        vuint8_t R;
        struct {
            vuint8_t:1;
            vuint8_t SSB:7;
        } B;
    } SSBR;                 /* Set Start Bit Register */

    union {
        vuint8_t R;
        struct {
            vuint8_t:1;
            vuint8_t CDSB:7;
        } B;
    } CDSBR;                /* Clear Done Status Bit Register */

    vuint32_t EDMA_RESERVED_2[1]; /* 0x0020�0x0023 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t INT15:1;
            vuint32_t INT14:1;
            vuint32_t INT13:1;
            vuint32_t INT12:1;
            vuint32_t INT11:1;
            vuint32_t INT10:1;
            vuint32_t INT09:1;
            vuint32_t INT08:1;
            vuint32_t INT07:1;
            vuint32_t INT06:1;
            vuint32_t INT05:1;
            vuint32_t INT04:1;
            vuint32_t INT03:1;
            vuint32_t INT02:1;
            vuint32_t INT01:1;
            vuint32_t INT00:1;
        } B;
    } IRQRL;        /* eDMA Interrupt Request Register */

    vuint32_t EDMA_RESERVED_3[1]; /* 0x0028�0x002B */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t ERR15:1;
            vuint32_t ERR14:1;
            vuint32_t ERR13:1;
            vuint32_t ERR12:1;
            vuint32_t ERR11:1;
            vuint32_t ERR10:1;
            vuint32_t ERR09:1;
            vuint32_t ERR08:1;
            vuint32_t ERR07:1;
            vuint32_t ERR06:1;
            vuint32_t ERR05:1;
            vuint32_t ERR04:1;
            vuint32_t ERR03:1;
            vuint32_t ERR02:1;
            vuint32_t ERR01:1;
            vuint32_t ERR00:1;
        } B;
    } ERL;            /* eDMA Error Register */

    vuint32_t EDMA_RESERVED_4[1]; /* 0x0030�0x0033 */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t HRS15:1;
            vuint32_t HRS14:1;
            vuint32_t HRS13:1;
            vuint32_t HRS12:1;
            vuint32_t HRS11:1;
            vuint32_t HRS10:1;
            vuint32_t HRS09:1;
            vuint32_t HRS08:1;
            vuint32_t HRS07:1;
            vuint32_t HRS06:1;
            vuint32_t HRS05:1;
            vuint32_t HRS04:1;
            vuint32_t HRS03:1;
            vuint32_t HRS02:1;
            vuint32_t HRS01:1;
            vuint32_t HRS00:1;
        } B;
    } HRSL;                 /* DMA Hardware Request Status Low */

    vuint32_t EDMA_RESERVED_5[50]; /* 0x0038�0x00FF */

    union {
        vuint8_t R;
        struct {
            vuint8_t ECP:1;
            vuint8_t:3;
            vuint8_t CHPRI:4;
        } B;
    } CPR[16];              /* Channel n Priority */

    vuint32_t EDMA_RESERVED_6[956]; /* 0x0110�0x0FFF */

    struct EDMA_TCD_STD_tag TCD[16];
    /* struct EDMA_TCD_CHLINK_tag TCD[16]; */

};                          /* end of EDMA_tag */
/****************************************************************************/
/*                          MODULE : INTC                                   */
/****************************************************************************/
struct INTC_tag {
    
    union {
        vuint32_t R;
        struct {
            vuint32_t:26;
            vuint32_t VTES:1;
            vuint32_t:4;
            vuint32_t HVEN:1;
        } B;
    } MCR;            /* INTC Module Configuration Register */

    vuint32_t INTC_RESERVED_0[1]; /* 0x0004-0x0007 */     
    
    union {
        vuint32_t R;
        struct {
            vuint32_t:28;
            vuint32_t PRI:4;
        } B;
    } CPR;                  /* Current Priority Register */

    vuint32_t INTC_RESERVED_1[1]; /* 0x000C-0x000F */

    union {
        vuint32_t R;
        struct {
            vuint32_t VTBA:21;
            vuint32_t INTVEC:9;
            vuint32_t:2;
        } B;
    } IACKR;                /* Interrupt Acknowledge Register */

    vuint32_t INTC_RESERVED_2[1]; /* 0x0014-0x0017 */

    union {
        vuint32_t R;
        struct {
            vuint32_t EOIR:32;
        } B;
    } EOIR;                 /* End of Interrupt Register */

    vuint32_t INTC_RESERVED_3[1]; /* 0x001C-0x001F */

    union {
        vuint8_t R;
        struct {
            vuint8_t:6;
            vuint8_t SET:1;
            vuint8_t CLR:1;
        } B;
    } SSCIR[8];             /* Software Set/Clear Interruput Register */

    vuint32_t INTC_RESERVED_4[6]; /* 0x0028-0x003F */

    union {
        vuint8_t R;
        struct {
            vuint8_t:4;
            vuint8_t PRI:4;
        } B;
    } INTC_PSR[261];    /* INTC Priority Select Registers 0/260 */

};                          /* end of INTC_tag */
/****************************************************************************/
/*                          MODULE : DSPI                                   */
/****************************************************************************/
struct DSPI_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t MSTR:1;
            vuint32_t CONT_SCKE:1;
            vuint32_t DCONF:2;
            vuint32_t FRZ:1;
            vuint32_t MTFE:1;
            vuint32_t PCSSE:1;
            vuint32_t ROOE:1;
            vuint32_t PCSIS7:1;
            vuint32_t PCSIS6:1;
            vuint32_t PCSIS5:1;
            vuint32_t PCSIS4:1;
            vuint32_t PCSIS3:1;
            vuint32_t PCSIS2:1;
            vuint32_t PCSIS1:1;
            vuint32_t PCSIS0:1;
            vuint32_t:1;
            vuint32_t MDIS:1;
            vuint32_t DIS_TXF:1;
            vuint32_t DIS_RXF:1;
            vuint32_t CLR_TXF:1;
            vuint32_t CLR_RXF:1;
            vuint32_t SMPL_PT:2;
            vuint32_t:7;
            vuint32_t HALT:1;
        } B;
    } MCR;                  /* Module Configuration Register */

    vuint32_t DSPI_RESERVED_0[1]; /* 0x0004�0x0007 */

    union {
        vuint32_t R;
        struct {
            vuint32_t SPI_TCNT:16;
            vuint32_t:16;
        } B;
    } TCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t DBR:1;
            vuint32_t FMSZ:4;
            vuint32_t CPOL:1;
            vuint32_t CPHA:1;
            vuint32_t LSBFE:1;
            vuint32_t PCSSCK:2;
            vuint32_t PASC:2;
            vuint32_t PDT:2;
            vuint32_t PBR:2;
            vuint32_t CSSCK:4;
            vuint32_t ASC:4;
            vuint32_t DT:4;
            vuint32_t BR:4;
        } B;
    } CTAR[8];              /* Clock and Transfer Attributes Registers */

    union {
        vuint32_t R;
        struct {
            vuint32_t TCF:1;
            vuint32_t TXRXS:1;
            vuint32_t:1;
            vuint32_t EOQF:1;
            vuint32_t TFUF:1;
            vuint32_t:1;
            vuint32_t TFFF:1;
            vuint32_t:5;
            vuint32_t RFOF:1;
            vuint32_t:1;
            vuint32_t RFDF:1;
            vuint32_t:1;
            vuint32_t TXCTR:4;
            vuint32_t TXNXTPTR:4;
            vuint32_t RXCTR:4;
            vuint32_t POPNXTPTR:4;
        } B;
    } SR;                   /* Status Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t TCF_RE:1;
            vuint32_t:2;
            vuint32_t EOQF_RE:1;
            vuint32_t TFUF_RE:1;
            vuint32_t:1;
            vuint32_t TFFF_RE:1;
            vuint32_t TFFF_DIRS:1;
            vuint32_t:4;
            vuint32_t RFOF_RE:1;
            vuint32_t:1;
            vuint32_t RFDF_RE:1;
            vuint32_t RFDF_DIRS:1;
            vuint32_t:16;
        } B;
    } RSER;        /* DSPI DMA/Interrupt Request Select and Enable Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t CONT:1;
            vuint32_t CTAS:3;
            vuint32_t EOQ:1;
            vuint32_t CTCNT:1;
            vuint32_t:2;
            vuint32_t PCS7:1;
            vuint32_t PCS6:1;
            vuint32_t PCS5:1;
            vuint32_t PCS4:1;
            vuint32_t PCS3:1;
            vuint32_t PCS2:1;
            vuint32_t PCS1:1;
            vuint32_t PCS0:1;
            vuint32_t TXDATA:16;
        } B;
    } PUSHR;        /* DSPI Push TX FIFO Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t RXDATA:16;
        } B;
    } POPR;        /* DSPI Pop RX FIFO Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t TXCMD:16;
            vuint32_t TXDATA:16;
        } B;
    } TXFR[5];              /* Transmit FIFO Registers */

    vuint32_t DSPI_RESERVED_1[11]; /* 0x0050�0x007B */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t RXDATA:16;
        } B;
    } RXFR[5];              /* Receive FIFO Registers */

  

};                        /* end of DSPI_tag */
/****************************************************************************/
/*                          MODULE : FLEXCAN                                */
/****************************************************************************/
struct FLEXCAN_MBUFFER_tag {          /* 0x0080-0x027F  (128 32 bits words)*/

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t CODE:4;
            vuint32_t:1;
            vuint32_t SRR:1;
            vuint32_t IDE:1;
            vuint32_t RTR:1;
            vuint32_t LENGTH:4;
            vuint32_t TIMESTAMP:16;
        } B;
    } CS;                /* Control and Status (C/S) */

    union {
        vuint32_t R;
        struct {
            vuint32_t PRIO:3;
            vuint32_t STD_ID:11;
            vuint32_t EXT_ID:18;
        } B;
    } ID;                /* Identifier Field */

    union {
        vuint32_t W[2];    /* Data buffer in words (32 bits) */
    } DATA;                /* Data Field */

    vuint32_t FLEXCAN_MBUFFER_RESERVED_0[124]; /* 0x0090�0x027F */

};                        /* end of FLEXCAN_MBUFFER_tag */

struct FLEXCAN_RXFIFO_tag {            /* 0x0080-0x027F  (128 32 bits words)*/

    union {
        vuint32_t R;
        struct {
            vuint32_t:9;
            vuint32_t SRR:1;
            vuint32_t IDE:1;
            vuint32_t RTR:1;
            vuint32_t LENGTH:4;
            vuint32_t TIMESTAMP:16;
        } B;
    } CS;                /* Control and Status (C/S) */

    union {
        vuint32_t R;
        struct {
            vuint32_t:3;
            vuint32_t STD_ID:11;
            vuint32_t EXT_ID:18;
        } B;
    } ID;                /* Identifier Field */

    union {
        vuint32_t W[2];    /* Data buffer in words (32 bits) */
    } DATA;                /* Data Field */

    vuint32_t FLEXCAN_RXFIFO_RESERVED_0[20]; /* 0x0090�0x00DF */

    union {
        vuint32_t R;
    } IDTABLE[8];        /* ID Table 0/7 */
    
    vuint32_t FLEXCAN_RXFIFO_RESERVED_1[96]; /* 0x0100�0x0280 */

};                          /* end of FLEXCAN_RXFIFO_t */

struct FLEXCAN_tag {

    union {
        vuint32_t R;
        struct {
            vuint32_t MDIS:1;
            vuint32_t FRZ:1;
            vuint32_t FEN:1;
            vuint32_t HALT:1;
            vuint32_t NOT_RDY:1;
            vuint32_t:1;
            vuint32_t SOFT_RST:1;
            vuint32_t FRZ_ACK:1;
            vuint32_t SUPV:1;
            vuint32_t:1;
            vuint32_t WRN_EN:1;
            vuint32_t LPM_ACK:1;
            vuint32_t:2;
            vuint32_t SRX_DIS:1;
            vuint32_t BCC:1;
            vuint32_t:2;
            vuint32_t LPRIO_EN:1;
            vuint32_t AEN:1;
            vuint32_t:2;
            vuint32_t IDAM:2;
            vuint32_t:2;
            vuint32_t MAXMB:6;
        } B;
    } MCR;                /* Module Configuration Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t PRESDIV:8;
            vuint32_t RJW:2;
            vuint32_t PSEG1:3;
            vuint32_t PSEG2:3;
            vuint32_t BOFF_MSK:1;
            vuint32_t ERR_MSK:1;
            vuint32_t CLK_SRC:1;
            vuint32_t LPB:1;
            vuint32_t TWRN_MSK:1;
            vuint32_t RWRN_MSK:1;
            vuint32_t:2;
            vuint32_t SMP:1;
            vuint32_t BOFF_REC:1;
            vuint32_t TSYN:1;
            vuint32_t LBUF:1;
            vuint32_t LOM:1;
            vuint32_t PROPSEG:3;
        } B;
    } CTRL;                /* Control Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t TIMER:16;
        } B;
    } TIMER;            /* Free Running Timer */

    vuint32_t FLEXCAN_RESERVED_0[1]; /* 0x000C�0x000F */

    union {
        vuint32_t R;
        struct {
            vuint32_t MI31:1;
            vuint32_t MI30:1;
            vuint32_t MI29:1;
            vuint32_t MI28:1;
            vuint32_t MI27:1;
            vuint32_t MI26:1;
            vuint32_t MI25:1;
            vuint32_t MI24:1;
            vuint32_t MI23:1;
            vuint32_t MI22:1;
            vuint32_t MI21:1;
            vuint32_t MI20:1;
            vuint32_t MI19:1;
            vuint32_t MI18:1;
            vuint32_t MI17:1;
            vuint32_t MI16:1;
            vuint32_t MI15:1;
            vuint32_t MI14:1;
            vuint32_t MI13:1;
            vuint32_t MI12:1;
            vuint32_t MI11:1;
            vuint32_t MI10:1;
            vuint32_t MI9:1;
            vuint32_t MI8:1;
            vuint32_t MI7:1;
            vuint32_t MI6:1;
            vuint32_t MI5:1;
            vuint32_t MI4:1;
            vuint32_t MI3:1;
            vuint32_t MI2:1;
            vuint32_t MI1:1;
            vuint32_t MI0:1;
        } B;
    } RXGMASK;            /* RX Global Mask */

    union {
        vuint32_t R;
        struct {
            vuint32_t MI31:1;
            vuint32_t MI30:1;
            vuint32_t MI29:1;
            vuint32_t MI28:1;
            vuint32_t MI27:1;
            vuint32_t MI26:1;
            vuint32_t MI25:1;
            vuint32_t MI24:1;
            vuint32_t MI23:1;
            vuint32_t MI22:1;
            vuint32_t MI21:1;
            vuint32_t MI20:1;
            vuint32_t MI19:1;
            vuint32_t MI18:1;
            vuint32_t MI17:1;
            vuint32_t MI16:1;
            vuint32_t MI15:1;
            vuint32_t MI14:1;
            vuint32_t MI13:1;
            vuint32_t MI12:1;
            vuint32_t MI11:1;
            vuint32_t MI10:1;
            vuint32_t MI9:1;
            vuint32_t MI8:1;
            vuint32_t MI7:1;
            vuint32_t MI6:1;
            vuint32_t MI5:1;
            vuint32_t MI4:1;
            vuint32_t MI3:1;
            vuint32_t MI2:1;
            vuint32_t MI1:1;
            vuint32_t MI0:1;
        } B;
    } RX14MASK;            /* RX Buffer 14 Mask */

    union {
        vuint32_t R;
        struct {
            vuint32_t MI31:1;
            vuint32_t MI30:1;
            vuint32_t MI29:1;
            vuint32_t MI28:1;
            vuint32_t MI27:1;
            vuint32_t MI26:1;
            vuint32_t MI25:1;
            vuint32_t MI24:1;
            vuint32_t MI23:1;
            vuint32_t MI22:1;
            vuint32_t MI21:1;
            vuint32_t MI20:1;
            vuint32_t MI19:1;
            vuint32_t MI18:1;
            vuint32_t MI17:1;
            vuint32_t MI16:1;
            vuint32_t MI15:1;
            vuint32_t MI14:1;
            vuint32_t MI13:1;
            vuint32_t MI12:1;
            vuint32_t MI11:1;
            vuint32_t MI10:1;
            vuint32_t MI9:1;
            vuint32_t MI8:1;
            vuint32_t MI7:1;
            vuint32_t MI6:1;
            vuint32_t MI5:1;
            vuint32_t MI4:1;
            vuint32_t MI3:1;
            vuint32_t MI2:1;
            vuint32_t MI1:1;
            vuint32_t MI0:1;
        } B;
    } RX15MASK;            /* RX Buffer 15 Mask */

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t RX_ERR_COUNTER:8;
            vuint32_t TX_ERR_COUNTER:8;
        } B;
    } ECR;                /* Error Counter Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:14;
            vuint32_t TWRN_INT:1;
            vuint32_t RWRN_INT:1;
            vuint32_t BIT1_ERR:1;
            vuint32_t BIT0_ERR:1;
            vuint32_t ACK_ERR:1;
            vuint32_t CRC_ERR:1;
            vuint32_t FRM_ERR:1;
            vuint32_t STF_ERR:1;
            vuint32_t TX_WRN:1;
            vuint32_t RX_WRN:1;
            vuint32_t IDLE:1;
            vuint32_t TXRX:1;
            vuint32_t FLT_CONF:2;
            vuint32_t:1;
            vuint32_t BOFF_INT:1;
            vuint32_t ERR_INT:1;
            vuint32_t:1;
        } B;
    } ESR;                /* Error and Status Register */

    vuint32_t FLEXCAN_RESERVED_1[1]; /* 0x0024�0x0027 */
    
    union {
        vuint32_t R;
        struct {
            vuint32_t BUF31M:1;
            vuint32_t BUF30M:1;
            vuint32_t BUF29M:1;
            vuint32_t BUF28M:1;
            vuint32_t BUF27M:1;
            vuint32_t BUF26M:1;
            vuint32_t BUF25M:1;
            vuint32_t BUF24M:1;
            vuint32_t BUF23M:1;
            vuint32_t BUF22M:1;
            vuint32_t BUF21M:1;
            vuint32_t BUF20M:1;
            vuint32_t BUF19M:1;
            vuint32_t BUF18M:1;
            vuint32_t BUF17M:1;
            vuint32_t BUF16M:1;
            vuint32_t BUF15M:1;
            vuint32_t BUF14M:1;
            vuint32_t BUF13M:1;
            vuint32_t BUF12M:1;
            vuint32_t BUF11M:1;
            vuint32_t BUF10M:1;
            vuint32_t BUF09M:1;
            vuint32_t BUF08M:1;
            vuint32_t BUF07M:1;
            vuint32_t BUF06M:1;
            vuint32_t BUF05M:1;
            vuint32_t BUF04M:1;
            vuint32_t BUF03M:1;
            vuint32_t BUF02M:1;
            vuint32_t BUF01M:1;
            vuint32_t BUF00M:1;
        } B;
    } IMASK1;            /* Interrupt Masks 1 */

    vuint32_t FLEXCAN_RESERVED_2[1]; /* 0x002C�0x002F */

    union {
        vuint32_t R;
        struct {
            vuint32_t BUF31I:1;
            vuint32_t BUF30I:1;
            vuint32_t BUF29I:1;
            vuint32_t BUF28I:1;
            vuint32_t BUF27I:1;
            vuint32_t BUF26I:1;
            vuint32_t BUF25I:1;
            vuint32_t BUF24I:1;
            vuint32_t BUF23I:1;
            vuint32_t BUF22I:1;
            vuint32_t BUF21I:1;
            vuint32_t BUF20I:1;
            vuint32_t BUF19I:1;
            vuint32_t BUF18I:1;
            vuint32_t BUF17I:1;
            vuint32_t BUF16I:1;
            vuint32_t BUF15I:1;
            vuint32_t BUF14I:1;
            vuint32_t BUF13I:1;
            vuint32_t BUF12I:1;
            vuint32_t BUF11I:1;
            vuint32_t BUF10I:1;
            vuint32_t BUF09I:1;
            vuint32_t BUF08I:1;
            vuint32_t BUF07I:1;
            vuint32_t BUF06I:1;
            vuint32_t BUF05I:1;
            vuint32_t BUF04I:1;
            vuint32_t BUF03I:1;
            vuint32_t BUF02I:1;
            vuint32_t BUF01I:1;
            vuint32_t BUF00I:1;
        } B;
    } IFLAG1;            /* Interrupt Flags 1 */

    vuint32_t FLEXCAN_RESERVED_3[19]; /* 0x0034�0x007F */

    union {              /* 0x0080-0x027F  (128 32 bits words)*/
        struct FLEXCAN_MBUFFER_tag MBUFFER[32];
        struct FLEXCAN_RXFIFO_tag RXFIFO;
    } MEM_AREA; 

    vuint32_t FLEXCAN_RESERVED_4[384]; /* 0x0280�0x087F */

    union {
        vuint32_t R;
        struct {
            vuint32_t MI31:1;
            vuint32_t MI30:1;
            vuint32_t MI29:1;
            vuint32_t MI28:1;
            vuint32_t MI27:1;
            vuint32_t MI26:1;
            vuint32_t MI25:1;
            vuint32_t MI24:1;
            vuint32_t MI23:1;
            vuint32_t MI22:1;
            vuint32_t MI21:1;
            vuint32_t MI20:1;
            vuint32_t MI19:1;
            vuint32_t MI18:1;
            vuint32_t MI17:1;
            vuint32_t MI16:1;
            vuint32_t MI15:1;
            vuint32_t MI14:1;
            vuint32_t MI13:1;
            vuint32_t MI12:1;
            vuint32_t MI11:1;
            vuint32_t MI10:1;
            vuint32_t MI9:1;
            vuint32_t MI8:1;
            vuint32_t MI7:1;
            vuint32_t MI6:1;
            vuint32_t MI5:1;
            vuint32_t MI4:1;
            vuint32_t MI3:1;
            vuint32_t MI2:1;
            vuint32_t MI1:1;
            vuint32_t MI0:1;
        } B;
    } RXIMR[32];        /* RX Individual Mask Registers 0/31 */

    vuint32_t FLEXCAN_RESERVED_5[3520]; /* 0x0900�0x3FFF */

};                        /* End of FLEXCAN_tag */
/****************************************************************************/
/*                          MODULE : DMAMUX                                 */
/****************************************************************************/
struct DMA_MUX_tag {
    
    union {
        vuint8_t R;
        struct {
            vuint8_t ENBL:1;
            vuint8_t TRIG:1;
            vuint8_t SOURCE:6;
        } B;
    } CHCONFIG[16];        /* DMA Channel Configuration Registers 0/15 */
};                        /* end of DMA_MUX_tag */
/****************************************************************************/
/*                          MODULE : FLEXRAY                                */
/****************************************************************************/
struct FLEXRAY_MBUFFER_tag {

    union { /* 0x0100 - 0x02F8 */
        vuint16_t R;
        struct {
            vuint16_t:1;
            vuint16_t MCM:1;
            vuint16_t MBT:1;
            vuint16_t MTD:1;
            vuint16_t CMT:1;
            vuint16_t EDT:1;
            vuint16_t LCKT:1;
            vuint16_t MBIE:1;
            vuint16_t:3;
            vuint16_t DUP:1;
            vuint16_t DVAL:1;
            vuint16_t EDS:1;
            vuint16_t LCKS:1;
            vuint16_t MBIF:1;
        } B;
    } MBCCSR; /* Message Buffer Configuration, Control, Status Register n */    

    union { /* 0x0102 - 0x02FA */
        vuint16_t R;
        struct {
            vuint16_t MTM:1;
            vuint16_t CHA:1;
            vuint16_t CHB:1;
            vuint16_t CCFE:1;
            vuint16_t CCFMSK:6;
            vuint16_t CCFVAL:6;
        } B;
    } MBCCFR;            /* Message Buffer Cycle Counter Filter Register n */    

    union { /* 0x0104 - 0x02FC */
        vuint16_t R;
        struct {
            vuint16_t:5;
            vuint16_t FID:11;
        } B;
    } MBFIDR;            /* Message Buffer Frame ID Register n */    

    union { /* 0x0106 - 0x02FE */
        vuint16_t R;
        struct {
            vuint16_t:9;
            vuint16_t MBIDX:7;
        } B;
    } MBIDXR;            /* Message Buffer Index Register n */    

};  /* end of FLEXRAY_MBUFFER_tag */

struct FLEXRAY_tag {

    /* Module Configuration and Control */

    union { /* 0x0000 */
        vuint16_t R;
        struct {
            vuint16_t CHIVER:8;
            vuint16_t PEVER:8;
        } B;
    } MVR;                /* Module Version Register */

    union { /* 0x0002 */
        vuint16_t R;
        struct {
            vuint16_t MEN:1;
            vuint16_t SBFF:1;
            vuint16_t SCM:1;
            vuint16_t CHB:1;
            vuint16_t CHA:1;
            vuint16_t SFFE:1;
            vuint16_t:5;
            vuint16_t CLKSEL:1;
            vuint16_t BITRATE:3;
            vuint16_t:1;
        } B;
    } MCR;                /* Module Configuration Register */        

    union { /* 0x0004 */
        vuint16_t R;
        struct {
            vuint16_t SYS_MEM_BASE_ADDR:16;
        } B;
    } SYMBADHR;            /* System Memory Base Address High Register */            

    union { /* 0x0006 */
        vuint16_t R;
        struct {
            vuint16_t SYS_MEM_BASE_ADDR:12;
            vuint16_t:4;
        } B;
    } SYMBADLR;            /* System Memory Base Address Low Register */    

    union { /* 0x0008 */
        vuint16_t R;
        struct {
            vuint16_t WMD:1;
            vuint16_t SEL:7;
            vuint16_t:3;
            vuint16_t ENB:1;
            vuint16_t:2;
            vuint16_t STBPSEL:2;
        } B;
    } STBSCR;            /* Strobe Signal Control Register */

    vuint16_t FLEXRAY_RESERVED_0[1]; /* 0x000A-0x000B */
    
    union { /* 0x000C */
        vuint16_t R;
        struct {
            vuint16_t:1;
            vuint16_t MBSEG2DS:7;
            vuint16_t:1;
            vuint16_t MBSEG1DS:7;
        } B;
    } MBDSR;            /* Message Buffer Data Size Register */

    union { /* 0x000E */
        vuint16_t R;
        struct {
            vuint16_t:2;
            vuint16_t LAST_MB_SEG1:6;
            vuint16_t:2;
            vuint16_t LAST_MB_UTIL:6;
        } B;
    } MBSSUTR;  /* Message Buffer Segment Size and Utilization Register */

    /* Test Registers */

    vuint16_t FLEXRAY_RESERVED_1[2]; /* 0x0010-0x0013 */

    /* Interrupt and Error Handling */

    union { /* 0x0014 */
        vuint16_t R;
        struct {
            vuint16_t WME:1;
            vuint16_t:3;
            vuint16_t EOC_AP:2;
            vuint16_t ERC_AP:2;
            vuint16_t BSY_WMC:1;                
            vuint16_t:3;
            vuint16_t POCCMD:4;
        } B;
    } POCR;                /* Protocol Operation Control Register */

    union { /* 0x0016 */
        vuint16_t R;
        struct {
            vuint16_t MIF:1;
            vuint16_t PRIF:1;
            vuint16_t CHIF:1;
            vuint16_t WUPIF:1;
            vuint16_t FNEBIF:1;
            vuint16_t FNEAIF:1;
            vuint16_t RBIF:1;
            vuint16_t TBIF:1;
            vuint16_t MIE:1;
            vuint16_t PRIE:1;
            vuint16_t CHIE:1;
            vuint16_t WUPIE:1;
            vuint16_t FNEBIE:1;
            vuint16_t FNEAIE:1;
            vuint16_t RBIE:1;
            vuint16_t TBIE:1;
        } B;
    } GIFER;            /* Global Interrupt Flag and Enable Register */        

    union { /* 0x0018 */
        vuint16_t R;
        struct {
            vuint16_t FATL_IF:1;
            vuint16_t INTL_IF:1;
            vuint16_t ILCF_IF:1;
            vuint16_t CSA_IF:1;
            vuint16_t MRC_IF:1;
            vuint16_t MOC_IF:1;
            vuint16_t CCL_IF:1;
            vuint16_t MXS_IF:1;
            vuint16_t MTX_IF:1;
            vuint16_t LTXB_IF:1;
            vuint16_t LTXA_IF:1;
            vuint16_t TBVB_IF:1;
            vuint16_t TBVA_IF:1;
            vuint16_t TI2_IF:1;
            vuint16_t TI1_IF:1;
            vuint16_t CYS_IF:1;
        } B;
    } PIFR0;            /* Protocol Interrupt Flag Register 0 */        

    union { /* 0x001A */
        vuint16_t R;
        struct {
            vuint16_t EMC_IF:1;
            vuint16_t IPC_IF:1;
            vuint16_t PECF_IF:1;
            vuint16_t PSC_IF:1;
            vuint16_t SSI3_IF:1;
            vuint16_t SSI2_IF:1;
            vuint16_t SSI1_IF:1;
            vuint16_t SSI0_IF:1;
            vuint16_t:2;
            vuint16_t EVT_IF:1;
            vuint16_t ODT_IF:1;
            vuint16_t:4;
        } B;
    } PIFR1;            /* Protocol Interrupt Flag Register 1 */        

    union { /* 0x001C */
        vuint16_t R;
        struct {
            vuint16_t FATL_IE:1;
            vuint16_t INTL_IE:1;
            vuint16_t ILCF_IE:1;
            vuint16_t CSA_IE:1;
            vuint16_t MRC_IE:1;
            vuint16_t MOC_IE:1;
            vuint16_t CCL_IE:1;
            vuint16_t MXS_IE:1;
            vuint16_t MTX_IE:1;
            vuint16_t LTXB_IE:1;
            vuint16_t LTXA_IE:1;
            vuint16_t TBVB_IE:1;
            vuint16_t TBVA_IE:1;
            vuint16_t TI2_IE:1;
            vuint16_t TI1_IE:1;
            vuint16_t CYS_IE:1;
        } B;
    } PIER0;            /* Protocol Interrupt Enable Register 0 */        
    
    union { /* 0x001E */
        vuint16_t R;
        struct {
            vuint16_t EMC_IE:1;
            vuint16_t IPC_IE:1;
            vuint16_t PECF_IE:1;
            vuint16_t PSC_IE:1;
            vuint16_t SSI3_IE:1;
            vuint16_t SSI2_IE:1;
            vuint16_t SSI1_IE:1;
            vuint16_t SSI0_IE:1;
            vuint16_t:2;
            vuint16_t EVT_IE:1;
            vuint16_t ODT_IE:1;
            vuint16_t:4;
        } B;
    } PIER1;            /* Protocol Interrupt Enable Register 1 */        

    union { /* 0x0020 */
        vuint16_t R;
        struct {
            vuint16_t FRLB_EF:1;
            vuint16_t FRLA_EF:1;
            vuint16_t PCMI_EF:1;
            vuint16_t FOVB_EF:1;
            vuint16_t FOVA_EF:1;
            vuint16_t MBS_EF:1;
            vuint16_t MBU_EF:1;
            vuint16_t LCK_EF:1;
            vuint16_t DBL_EF:1;
            vuint16_t SBCF_EF:1;
            vuint16_t FID_EF:1;
            vuint16_t DPL_EF:1;
            vuint16_t SPL_EF:1;
            vuint16_t NML_EF:1;
            vuint16_t NMF_EF:1;
            vuint16_t ILSA_EF:1;
        } B;
    } CHIERFR;            /* CHI Error Flag Register */        

    union { /* 0x0022 */
        vuint16_t R;
        struct {
            vuint16_t:2;
            vuint16_t TBIVEC:6;
            vuint16_t:2;
            vuint16_t RBIVEC:6;
        } B;
    } MBIVEC;            /* Message Buffer Interrupt Vector Register */        

    union { /* 0x0024 */
        vuint16_t R;
        struct {
            vuint16_t STATUS_ERR_CNT:16;
        } B;
    } CASERCR;            /* Channel A Status Error Counter Register */        

    union { /* 0x0026 */
        vuint16_t R;
        struct {
            vuint16_t STATUS_ERR_CNT:16;
        } B;
    } CBSERCR;            /* Channel B Status Error Counter Register */        

    /* Protocol Status */

    union { /* 0x0028 */
        vuint16_t R;
        struct {
            vuint16_t ERRMODE:2;
            vuint16_t SLOTMODE:2;
            vuint16_t:1;
            vuint16_t PROTSTATE:3;
            vuint16_t STARTUPSTATE:4;
            vuint16_t:1;
            vuint16_t WAKEUPSTATUS:3;
        } B;
    } PSR0;                /* Protocol Status Register 0 */        

    union { /* 0x002A */
        vuint16_t R;
        struct {
            vuint16_t CSAA:1;
            vuint16_t CSP:1;
            vuint16_t:1;
            vuint16_t REMCSAT:5;
            vuint16_t CPN:1;
            vuint16_t HHR:1;
            vuint16_t FRZ:1;
            vuint16_t APTAC:5;
        } B;
    } PSR1;                /* Protocol Status Register 1 */        

    union { /* 0x002C */
        vuint16_t R;
        struct {
            vuint16_t NBVB:1;
            vuint16_t NSEB:1;
            vuint16_t STCB:1;
            vuint16_t SBVB:1;
            vuint16_t SSEB:1;
            vuint16_t MTB:1;
            vuint16_t NBVA:1;
            vuint16_t NSEA:1;
            vuint16_t STCA:1;
            vuint16_t SBVA:1;
            vuint16_t SSEA:1;
            vuint16_t MTA:1;
            vuint16_t CLKCORRFAILCNT:4;
        } B;
    } PSR2;                /* Protocol Status Register 2 */        

    union { /* 0x002E */
        vuint16_t R;
        struct {
            vuint16_t:2;
            vuint16_t WUB:1;
            vuint16_t ABVB:1;
            vuint16_t AACB:1;
            vuint16_t ACEB:1;
            vuint16_t ASEB:1;
            vuint16_t AVFB:1;
            vuint16_t:2;
            vuint16_t WUA:1;
            vuint16_t ABVA:1;
            vuint16_t AACA:1;
            vuint16_t ACEA:1;
            vuint16_t ASEA:1;
            vuint16_t AVFA:1;
        } B;
    } PSR3;                /* PProtocol Status Register 3 */        

    union { /* 0x0030 */
        vuint16_t R;
        struct {
            vuint16_t:2;
            vuint16_t MTCT:14;
        } B;
    } MTCTR;            /* Macrotick Counter Register */        

    union { /* 0x0032 */
        vuint16_t R;
        struct {
            vuint16_t:10;
            vuint16_t CYCCNT:6;
        } B;
    } CYCTR;            /* Cycle Counter Register */        

    union { /* 0x0034 */
        vuint16_t R;
        struct {
            vuint16_t:5;
            vuint16_t SLOTCNTA:11;
        } B;
    } SLTCTAR;            /* Slot Counter Channel A Register */        

    union { /* 0x0036 */
        vuint16_t R;
        struct {
            vuint16_t:5;
            vuint16_t SLOTCNTB:11;
        } B;
    } SLTCTBR;            /* Slot Counter Channel B Register */        

    union { /* 0x0038 */
        vuint16_t R;
        struct {
            vuint16_t RATECORR:16;
        } B;
    } RTCORVR;            /* Rate Correction Value Register */        

    union { /* 0x003A */
        vuint16_t R;
        struct {
            vuint16_t OFFSETCORR:16;
        } B;
    } OFCORVR;            /* Offset Correction Value Register */        

    union { /* 0x003C */
        vuint16_t R;
        struct {
            vuint16_t:8;
            vuint16_t MIF:1;
            vuint16_t PRIF:1;
            vuint16_t CHIF:1;
            vuint16_t WUPIF:1;
            vuint16_t FNEBIF:1;
            vuint16_t FNEAIF:1;
            vuint16_t RBIF:1;
            vuint16_t TBIF:1;
        } B;
    } CIFRR;            /* Combined Interrupt Flag Register */        

    union { /* 0x003E */
        vuint16_t R;
        struct {
            vuint16_t:11;
            vuint16_t TIMEOUT:5;
        } B;
    } SYMATOR;            /* System Memory Access Time-Out Register */        

    /* Sync Frame Counter and Tables */

    union { /* 0x0040 */
        vuint16_t R;
        struct {
            vuint16_t SFEVB:4;
            vuint16_t SFEVA:4;
            vuint16_t SFODB:4;
            vuint16_t SFODA:4;
        } B;
    } SFCNTR;            /* Sync Frame Counter Register */

    union { /* 0x0042 */
        vuint16_t R;
        struct {
            vuint16_t SFT_OFFSET:15;
            vuint16_t:1;
        } B;
    } SFTOR;            /* Sync Frame Table Offset Register */
    
    union { /* 0x0044 */
        vuint16_t R;
        struct {
            vuint16_t ELKT:1;
            vuint16_t OLKT:1;
            vuint16_t CYCNUM:6;
            vuint16_t ELKS:1;
            vuint16_t OLKS:1;
            vuint16_t EVAL:1;
            vuint16_t OVAL:1;
            vuint16_t:1;
            vuint16_t OPT:1;
            vuint16_t SDVEN:1;
            vuint16_t SIDEN:1;
        } B;
    } SFTCCSR;            /* Sync Frame Table Configuration, Control, Status Register */

    /* Sync Frame Filter */

    union { /* 0x0046 */
        vuint16_t R;
        struct {
            vuint16_t:6;
            vuint16_t SYNFRID:10;
        } B;
    } SFIDRFR;            /* Sync Frame ID Rejection Filter Register */
    
    union { /* 0x0048 */
        vuint16_t R;
        struct {
            vuint16_t:6;
            vuint16_t FVAL:10;
        } B;
    } SFIDAFVR;            /* Sync Frame ID Acceptance Filter Value Register */

    union { /* 0x004A */
        vuint16_t R;
        struct {
            vuint16_t:6;
            vuint16_t FMSK:10;
        } B;
    } SFIDAFMR;            /* Sync Frame ID Acceptance Filter Mask Register */

    /* Network Management Vector */

    union { /* 0x004C */
        vuint16_t R;
        struct {
            vuint16_t NMVP0:8;
            vuint16_t NMVP1:8;
        } B;
    } NMVR0;            /* Network Management Vector Register 0 */

    union { /* 0x004E */
        vuint16_t R;
        struct {
            vuint16_t NMVP2:8;
            vuint16_t NMVP3:8;
        } B;
    } NMVR1;            /* Network Management Vector Register 1 */

    union { /* 0x0050 */
        vuint16_t R;
        struct {
            vuint16_t NMVP4:8;
            vuint16_t NMVP5:8;
        } B;
    } NMVR2;            /* Network Management Vector Register 2 */

    union { /* 0x0052 */
        vuint16_t R;
        struct {
            vuint16_t NMVP6:8;
            vuint16_t NMVP7:8;
        } B;
    } NMVR3;            /* Network Management Vector Register 3 */

    union { /* 0x0054 */
        vuint16_t R;
        struct {
            vuint16_t NMVP8:8;
            vuint16_t NMVP9:8;
        } B;
    } NMVR4;            /* Network Management Vector Register 4 */

    union { /* 0x0056 */
        vuint16_t R;
        struct {
            vuint16_t NMVP10:8;
            vuint16_t NMVP11:8;
        } B;
    } NMVR5;            /* Network Management Vector Register 5 */

    union { /* 0x0058 */
        vuint16_t R;
        struct {
            vuint16_t:12;
            vuint16_t NMVL:4;
        } B;
    } NMVLR;            /* Network Management Vector Length Register */        

    /* Timer Configuration */

    union { /* 0x005A */
        vuint16_t R;
        struct {
            vuint16_t:2;
            vuint16_t T2_CFG:1;
            vuint16_t T2_REP:1;
            vuint16_t:1;
            vuint16_t T2SP:1;
            vuint16_t T2TR:1;
            vuint16_t T2ST:1;
            vuint16_t:3;
            vuint16_t T1_REP:1;
            vuint16_t:1;
            vuint16_t T1SP:1;
            vuint16_t T1TR:1;
            vuint16_t T1ST:1;
        } B;
    } TICCR;            /* Timer Configuration and Control Register */        

    union { /* 0x005C */
        vuint16_t R;
        struct {
            vuint16_t:2;
            vuint16_t T1_CYC_VAL:6;
            vuint16_t:2;
            vuint16_t T1_CYC_MSK:6;
        } B;
    } TI1CYSR;            /* Timer 1 Cycle Set Register */        

    union { /* 0x005E */
        vuint16_t R;
        struct {
            vuint16_t:2;
            vuint16_t T1_MTOFFSET:14;
        } B;
    } TI1MTOR;            /* Timer 1 Macrotick Offset Register */        

    union { /* 0x0060 */
        vuint16_t R;
        struct {
            vuint16_t:2;
            vuint16_t T2_CYC_VAL:6;
            vuint16_t:2;
            vuint16_t T2_CYC_MSK:6;
        } B;
        struct {
            vuint16_t T2_MTCNT:16;
        } BIT_T2_CFG;            
    } TI2CR0;            /* Timer 2 Configuration Register 0 */        

    union { /* 0x0062 */
        vuint16_t R;
        struct {
            vuint16_t:2;
            vuint16_t T1_MTOFFSET:14;
        } B;
        struct {
            vuint16_t T2_MTCNT:16;
        } BIT_T2_CFG;            
    } TI2CR1;            /* Timer 2 Configuration Register 1 */        

    /* Slot Status Configuration */

    union { /* 0x0064 */
        vuint16_t R;
        struct {
            vuint16_t WMD:1;
            vuint16_t:1;
            vuint16_t SEL:2;
            vuint16_t:1;
            vuint16_t SLOTNUMBER:11;
        } B;
    } SSSR;            /* Slot Status Selection Register */        

    union { /* 0x0066 */
        vuint16_t R;
        struct {
            vuint16_t WMD:1;
            vuint16_t:1;
            vuint16_t SEL:2;
            vuint16_t:1;
            vuint16_t CNTCFG:2;
            vuint16_t MCY:1;
            vuint16_t VFR:1;
            vuint16_t SYF:1;
            vuint16_t NUF:1;
            vuint16_t SUF:1;
            vuint16_t STATUSMASK:4;
        } B;
    } SSCCR;            /* Slot Status Counter Condition Register */        

    /* Slot Status */

    union { /* 0x0068 - 0x0076 */
        vuint16_t R;
        struct {
            vuint16_t VFB:1;
            vuint16_t SYB:1;
            vuint16_t NFB:1;
            vuint16_t SUB:1;
            vuint16_t SEB:1;
            vuint16_t CEB:1;
            vuint16_t BVB:1;
            vuint16_t TCB:1;
            vuint16_t VFA:1;
            vuint16_t SYA:1;
            vuint16_t NFA:1;
            vuint16_t SUA:1;
            vuint16_t SEA:1;
            vuint16_t CEA:1;
            vuint16_t BVA:1;
            vuint16_t TCA:1;
        } B;
    } SSR[8];            /* Slot Status Register 0/7 */        

    union { /* 0x0078 - 0x007E */
        vuint16_t R;
        struct {
            vuint16_t SLOTSTATUSCNT:16;
        } B;
    } SSCR[4];            /* Slot Status Counter Register 0/3 */

    /* MTS Generation */

    union { /* 0x0080 */
        vuint16_t R;
        struct {
            vuint16_t MTE:1;
            vuint16_t:1;
            vuint16_t CYCCNTMSK:6;
            vuint16_t:2;
            vuint16_t CYCCNTVAL:6;
        } B;
    } MTSACFR;            /* MTS A Configuration Register */

    union { /* 0x0082 */
        vuint16_t R;
        struct {
            vuint16_t MTE:1;
            vuint16_t:1;
            vuint16_t CYCCNTMSK:6;
            vuint16_t:2;
            vuint16_t CYCCNTVAL:6;
        } B;
    } MTSBCFR;            /* MTS B Configuration Register */

    /* Shadow Buffer Configuration */

    union { /* 0x0084 */
        vuint16_t R;
        struct {
            vuint16_t WMD:1;
            vuint16_t:1;
            vuint16_t SEL:2;
            vuint16_t:5;
            vuint16_t RSBIDX:7;
        } B;
    } RSBIR;            /* Receive Shadow Buffer Index Register */

    /* Receive FIFO � Configuration */

    union { /* 0x0086 */
        vuint16_t R;
        struct {
            vuint16_t:15;
            vuint16_t SEL:1;
        } B;
    } RFSR;                /* Receive FIFO Selection Register */

    union { /* 0x0088 */
        vuint16_t R;
        struct {
            vuint16_t:6;
            vuint16_t SIDX:10;
        } B;
    } RFSIR;            /* Receive FIFO Start Index Register */

    union { /* 0x008A */
        vuint16_t R;
        struct {
            vuint16_t FIFO_DEPTH:8;
            vuint16_t:1;
            vuint16_t ENTRY_SIZE:7;
        } B;
    } RFDSR;            /* Receive FIFO Depth and Size Register */

    /* Receive FIFO - Status */

    union { /* 0x008C */
        vuint16_t R;
        struct {
            vuint16_t:6;
            vuint16_t RDIDX:10;
        } B;
    } RFARIR;            /* Receive FIFO A Read Index Register */

    union { /* 0x008E */
        vuint16_t R;
        struct {
            vuint16_t:6;
            vuint16_t RDIDX:10;
        } B;
    } RFBRIR;            /* Receive FIFO B Read Index Register */

    /* Receive FIFO - Filter */

    union { /* 0x0090 */
        vuint16_t R;
        struct {
            vuint16_t MIDAFVAL:16;
        } B;
    } RFMIDAFVR;        /* Receive FIFO Message ID Acceptance Filter Value Register */
    
    union { /* 0x0092 */
        vuint16_t R;
        struct {
            vuint16_t MIDAFMSK:16;
        } B;
    } RFMIAFMR;            /* Receive FIFO Message ID Acceptance Filter Mask Register */

    union { /* 0x0094 */
        vuint16_t R;
        struct {
            vuint16_t:5;
            vuint16_t FIDRFVAL:11;
        } B;
    } RFFIDRFVR;        /* Receive FIFO Frame ID Rejection Filter Value Register */

    union { /* 0x0096 */
        vuint16_t R;
        struct {
            vuint16_t:5;
            vuint16_t FIDRFMSK:11;
        } B;
    } RFFIDRFMR;        /* Receive FIFO Frame ID Rejection Filter Mask Register */

    union { /* 0x0098 */
        vuint16_t R;
        struct {
            vuint16_t WMD:1;
            vuint16_t IBD:1;
            vuint16_t SEL:2;
            vuint16_t:1;
            vuint16_t SID:11;
        } B;
    } RFRFCFR;            /* Receive FIFO Range Filter Configuration Register */

    union { /* 0x009A */
        vuint16_t R;
        struct {
            vuint16_t:4;
            vuint16_t F3MD:1;
            vuint16_t F2MD:1;
            vuint16_t F1MD:1;
            vuint16_t F0MD:1;
            vuint16_t:4;
            vuint16_t F3EN:1;
            vuint16_t F2EN:1;
            vuint16_t F1EN:1;
            vuint16_t F0EN:1;
        } B;
    } RFRFCTR;            /* Receive FIFO Range Filter Control Register */

    /* Dynamic Segment Status */

    union { /* 0x009C */
        vuint16_t R;
        struct {
            vuint16_t:5;
            vuint16_t LASTDYNTXSLOTA:11;
        } B;
    } LDTXSLAR;            /* Last Dynamic Transmit Slot Channel A Register */

    union { /* 0x009E */
        vuint16_t R;
        struct {
            vuint16_t:5;
            vuint16_t LASTDYNTXSLOTB:11;
        } B;
    } LDTXSLBR;            /* Last Dynamic Transmit Slot Channel B Register */

    /* Protocol Configuration */
    
    union { /* 0x00A0 */
        vuint16_t R;
        struct {
            vuint16_t ACTION_POINT_OFFSET:6;
            vuint16_t STATIC_SLOT_LENGTH:10;
        } B;
    } PCR0;                /* Protocol Configuration Register 0 */

    union { /* 0x00A2 */
        vuint16_t R;
        struct {
            vuint16_t:2;
            vuint16_t MACRO_AFTER_FIRST_STATIC_SLOT:14;
        } B;
    } PCR1;                /* Protocol Configuration Register 1 */

    union { /* 0x00A4 */
        vuint16_t R;
        struct {
            vuint16_t MINISLOT_AFTER_ACTION_POINT:6;
            vuint16_t NUMBER_OF_STATIC_SLOTS:10;
        } B;
    } PCR2;                /* Protocol Configuration Register 2 */

    union { /* 0x00A6 */
        vuint16_t R;
        struct {
            vuint16_t WAKEUP_SYMBOL_RX_LOW:6;
            vuint16_t MINISLOT_ACTION_POINT_OFFSET:5;
            vuint16_t COLDSTART_ATTEMPTS:5;
        } B;
    } PCR3;                /* Protocol Configuration Register 3 */

    union { /* 0x00A8 */
        vuint16_t R;
        struct {
            vuint16_t CAS_RX_LOW_MAX:7;
            vuint16_t WAKEUP_SYMBOL_RX_WINDOW:11;
        } B;
    } PCR4;                /* Protocol Configuration Register 4 */

    union { /* 0x00AA */
        vuint16_t R;
        struct {
            vuint16_t TSS_TRANSMITTER:4;
            vuint16_t WAKEUP_SYMBOL_TX_LOW:6;
            vuint16_t WAKEUP_SYMBOL_RX_IDLE:6;
        } B;
    } PCR5;                /* Protocol Configuration Register 5 */
            
    union { /* 0x00AC */
        vuint16_t R;
        struct {
            vuint16_t:1;
            vuint16_t SYMBOL_WINDOW_AFTER_ACTION_POINT:8;
            vuint16_t MACRO_INITIAL_OFFSET_A:7;
        } B;
    } PCR6;                /* Protocol Configuration Register 6 */
            
    union { /* 0x00AE */
        vuint16_t R;
        struct {
            vuint16_t DECODING_CORRECTION_B:8;
            vuint16_t MICRO_PER_MACRO_NOM_HALF:7;
        } B;
    } PCR7;                /* Protocol Configuration Register 7 */

    union { /* 0x00B0 */
        vuint16_t R;
        struct {
            vuint16_t MAX_WITHOUT_CLOCK_CORRECTION_FATAL:4;
            vuint16_t MAX_WITHOUT_CLOCK_CORRECTION_PASSIVE:4;
            vuint16_t WAKEUP_SYMBOL_TX_IDLE:8;
        } B;
    } PCR8;                /* Protocol Configuration Register 8 */

    union { /* 0x00B2 */
        vuint16_t R;
        struct {
            vuint16_t MINISLOT_EXISTS:1;
            vuint16_t SYMBOL_WINDOW_EXISTS:1;
            vuint16_t OFFSET_CORRECTION_OUT:14;
        } B;
    } PCR9;                /* Protocol Configuration Register 9 */

    union { /* 0x00B4 */
        vuint16_t R;
        struct {
            vuint16_t SINGLE_SLOT_ENABLED:1;
            vuint16_t WAKEUP_CHANNEL:1;
            vuint16_t MACRO_PER_CYCLE:14;
        } B;
    } PCR10;            /* Protocol Configuration Register 10 */

    union { /* 0x00B6 */
        vuint16_t R;
        struct {
            vuint16_t KEY_SLOT_USED_FOR_STARTUP:1;
            vuint16_t KEY_SLOT_USED_FOR_SYNC:1;
            vuint16_t OFFSET_CORRECTION_START:14;
        } B;
    } PCR11;            /* Protocol Configuration Register 11 */

    union { /* 0x00B8 */
        vuint16_t R;
        struct {
            vuint16_t ALLOW_PASSIVE_TO_ACTIVE:5;
            vuint16_t KEY_SLOT_HEADER_CRC:11;
        } B;
    } PCR12;            /* Protocol Configuration Register 12 */
 
    union { /* 0x00BA */
        vuint16_t R;
        struct {
            vuint16_t FIRST_MINISLOT_ACTION_POINT_OFFSET:5;
            vuint16_t STATIC_SLOT_AFTER_ACTION_POINT:11;
        } B;
    } PCR13;            /* Protocol Configuration Register 13 */
 
    union { /* 0x00BC */
        vuint16_t R;
        struct {
            vuint16_t RATE_CORRECTION_OUT:11;
            vuint16_t LISTEN_TIMEOUT:5;
        } B;
    } PCR14;            /* Protocol Configuration Register 14 */

    union { /* 0x00BE */
        vuint16_t R;
        struct {
            vuint16_t LISTEN_TIMEOUT:16;
        } B;
    } PCR15;            /* Protocol Configuration Register 15 */

    union { /* 0x00C0 */
        vuint16_t R;
        struct {
            vuint16_t MACRO_INITIAL_OFFSET_B:7;
            vuint16_t NOISE_LISTEN_TIMEOUT:9;
        } B;
    } PCR16;            /* Protocol Configuration Register 16 */

    union { /* 0x00C2 */
        vuint16_t R;
        struct {
            vuint16_t NOISE_LISTEN_TIMEOUT:16;
        } B;
    } PCR17;            /* Protocol Configuration Register 17 */

    union { /* 0x00C4 */
        vuint16_t R;
        struct {
            vuint16_t WAKEUP_PATTERN:6;
            vuint16_t KEY_SLOT_ID:10;
        } B;
    } PCR18;            /* Protocol Configuration Register 18 */

    union { /* 0x00C6 */
        vuint16_t R;
        struct {
            vuint16_t DECODING_CORRECTION_A:9;
            vuint16_t PAYLOAD_LENGTH_STATIC:7;
        } B;
    } PCR19;            /* Protocol Configuration Register 19 */

    union { /* 0x00C8 */
        vuint16_t R;
        struct {
            vuint16_t MICRO_INITIAL_OFFSET_B:8;
            vuint16_t MICRO_INITIAL_OFFSET_A:8;
        } B;
    } PCR20;            /* Protocol Configuration Register 20 */

    union { /* 0x00CA */
        vuint16_t R;
        struct {
            vuint16_t EXTERN_RATE_CORRECTION:3;
            vuint16_t LATEST_TX:13;
        } B;
    } PCR21;            /* Protocol Configuration Register 21 */

    union { /* 0x00CC */
        vuint16_t R;
        struct {
            vuint16_t:1;
            vuint16_t COMP_ACCEPTED_STARTUP_RANGE_A:11;
            vuint16_t MICRO_PER_CYCLE:4;
        } B;
    } PCR22;            /* Protocol Configuration Register 22 */

    union { /* 0x00CE */
        vuint16_t R;
        struct {
            vuint16_t MICRO_PER_CYCLE:16;
        } B;
    } PCR23;            /* Protocol Configuration Register 23 */

    union { /* 0x00D0 */
        vuint16_t R;
        struct {
            vuint16_t CLUSTER_DRIFT_DAMPING:5;
            vuint16_t MAX_PAYLOAD_LENGTH_DYNAMIC:7;
            vuint16_t MICRO_PER_CYCLE_MIN:4;
        } B;
    } PCR24;            /* Protocol Configuration Register 24 */

    union { /* 0x00D2 */
        vuint16_t R;
        struct {
            vuint16_t MICRO_PER_CYCLE_MIN:16;
        } B;
    } PCR25;            /* Protocol Configuration Register 25 */

    union { /* 0x00D4 */
        vuint16_t R;
        struct {
            vuint16_t ALLOW_HALT_DUE_TO_CLOCK:1;
            vuint16_t COMP_ACCEPTED_STARTUP_RANGE_B:11;
            vuint16_t MICRO_PER_CYCLE_MAX:4;
        } B;
    } PCR26;            /* Protocol Configuration Register 26 */

    union { /* 0x00D6 */
        vuint16_t R;
        struct {
            vuint16_t MICRO_PER_CYCLE_MAX:16;
        } B;
    } PCR27;            /* Protocol Configuration Register 27 */

    union { /* 0x00D8 */
        vuint16_t R;
        struct {
            vuint16_t DYNAMIC_SLOT_IDLE_PHASE:2;
            vuint16_t MACRO_AFTER_OFFSET_CORRECTION:14;
        } B;
    } PCR28;            /* Protocol Configuration Register 28 */

    union { /* 0x00DA */
        vuint16_t R;
        struct {
            vuint16_t EXTERN_OFFSET_CORRECTION:3;
            vuint16_t MINISLOTS_MAX:13;
        } B;
    } PCR29;            /* Protocol Configuration Register 29 */

    union { /* 0x00DC */
        vuint16_t R;
        struct {
            vuint16_t:12;
            vuint16_t SYNC_NODE_MAX:4;
        } B;
    } PCR30;            /* Protocol Configuration Register 30 */

    vuint16_t FLEXRAY_RESERVED_2[17]; /* 0x00DE-0x00FF */

    /* Message Buffers Configuration, Control, Status */

    struct FLEXRAY_MBUFFER_tag MBUFFER[64];

  

};                        /* end of FLEXRAY_tag */
/****************************************************************************/
/*                     MODULE : DFLASH                                       */
/****************************************************************************/
struct DFLASH_tag {
    union {                 /* Module Configuration Register */
        vuint32_t R;
        struct {
            vuint32_t EDC:1;
            vuint32_t:4;
            vuint32_t SIZE:3;
            vuint32_t:1;
            vuint32_t LAS:3;
            vuint32_t:3;
            vuint32_t MAS:1;
            vuint32_t EER:1;
            vuint32_t RWE:1;
            vuint32_t:2;
            vuint32_t PEAS:1;
            vuint32_t DONE:1;
            vuint32_t PEG:1;
            vuint32_t:4;
            vuint32_t PGM:1;
            vuint32_t PSUS:1;
            vuint32_t ERS:1;
            vuint32_t ESUS:1;
            vuint32_t EHV:1;
        } B;
    } MCR;                /* Module Configuration Register */

    union {                 /* LML Register */
        vuint32_t R;
        struct {
            vuint32_t LME:1;
            vuint32_t:10;
            vuint32_t TSLK:1;
            vuint32_t:2;
            vuint32_t MLK:2;
            vuint32_t:8;
            vuint32_t LLK:8;
        } B;
    } LML;                /* Low/mid Address Space Block Locking Register */

    union {                 /* HBL Register */
        vuint32_t R;
        struct {
            vuint32_t HBE:1;
            vuint32_t:27;
            vuint32_t HLK:4;
        } B;
    } HBL;                /* High Address Space Block Locking Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t SLE:1;
            vuint32_t:10;
            vuint32_t STSLK:1;
            vuint32_t:2;
            vuint32_t SMK:2;
            vuint32_t SLK:16;
        } B;
    } SLL;                /* Secondary Low/mid Address Space Block Lock Register */

    union {                 /* LMS Register */
        vuint32_t R;
        struct {
            vuint32_t:14;
            vuint32_t MSL:2;
            vuint32_t LSL:16;
        } B;
    } LMS;                /* Low/mid Address Space Block Select Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:28;
            vuint32_t HSL:4;
        } B;
    } HBS;                /* High Address Space Block Select Register */


    union {                 /* Address Register */
        vuint32_t R;
        struct {
            vuint32_t:9;
            vuint32_t AD:20;
            vuint32_t:3;
        } B;
    } ADR;                /* Address Register */

    vuint32_t DFLASH_RESERVED_0[8]; /* 0x001C�0x003B */
    
    union {
        vuint32_t R;
        struct {
            vuint32_t UTE:1;
            vuint32_t SBCE:1;
            vuint32_t:6;
            vuint32_t DSI:8;
            vuint32_t:10;
            vuint32_t MRE:1;
            vuint32_t MRV:1;
            vuint32_t EIE:1;
            vuint32_t AIS:1;
            vuint32_t AIE:1;
            vuint32_t AID:1;
        } B;
    } UT0;                /* User Test Register 0 */

    union {                 /* User Test Register 1 0x0040 - 0x0043 */
        vuint32_t R;
        struct {
            vuint32_t DAI:32;
        } B;
    } UT1;

    union {                 /* User Test Register 2  0x0044 -0x0047 */
        vuint32_t R;
        struct {
            vuint32_t DAI:32;
        } B;
    } UT2;

    union {                 /* User Multiple Input Signature Register 0-4 */
        vuint32_t R;
        struct {
            vuint32_t MS:32;
        } B;
    } UMISR[5];

};                        /* end of DFLASH_tag */
/****************************************************************************/
/*                     MODULE : CFLASH                                       */
/****************************************************************************/
struct CFLASH_tag {
    union {                 /* Module Configuration Register */
        vuint32_t R;
        struct {
            vuint32_t EDC:1;
            vuint32_t:4;
            vuint32_t SIZE:3;
            vuint32_t:1;
            vuint32_t LAS:3;
            vuint32_t:3;
            vuint32_t MAS:1;
            vuint32_t EER:1;
            vuint32_t RWE:1;
            vuint32_t:2;
            vuint32_t PEAS:1;
            vuint32_t DONE:1;
            vuint32_t PEG:1;
            vuint32_t:4;
            vuint32_t PGM:1;
            vuint32_t PSUS:1;
            vuint32_t ERS:1;
            vuint32_t ESUS:1;
            vuint32_t EHV:1;
        } B;
    } MCR;                /* Module Configuration Register */

    union {                 /* LML Register */
        vuint32_t R;
        struct {
            vuint32_t LME:1;
            vuint32_t:10;
            vuint32_t TSLK:1;
            vuint32_t:2;
            vuint32_t MLK:2;
            vuint32_t:8;
            vuint32_t LLK:8;
        } B;
    } LML;                /* Low/mid Address Space Block Locking Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t HBE:1;
            vuint32_t:27;
            vuint32_t HLK:4;
        } B;
    } HBL;                /* High Address Space Block Locking Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t SLE:1;
            vuint32_t:10;
            vuint32_t STSLK:1;
            vuint32_t:2;
            vuint32_t SMK:2;
            vuint32_t SLK:16;
        } B;
    } SLL;                /* Secondary Low/mid Address Space Block Lock Register */

    union {                 /* LMS Register */
        vuint32_t R;
        struct {
            vuint32_t:14;
            vuint32_t MSL:2;
            vuint32_t LSL:16;
        } B;
    } LMS;                /* Low/mid Address Space Block Select Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:28;
            vuint32_t HSL:4;
        } B;
    } HBS;                /* High Address Space Block Select Register */

    union {                 /* Address Register */
        vuint32_t R;
        struct {
            vuint32_t:9;
            vuint32_t AD:20;
            vuint32_t:3;
        } B;
    } ADR;                /* Address Register */

    union {                 /* CFLASH Configuration Register 0 */
        vuint32_t R;
        struct {
            vuint32_t BK0_APC:5;
            vuint32_t BK0_WWSC:5;
            vuint32_t BK0_RWSC:5;
            vuint32_t BK0_RWWC2:1;
            vuint32_t BK0_RWWC1:1;
            vuint32_t B0_P1_BCFG:2;  
            vuint32_t B0_P1_DPFE:1;  
            vuint32_t B0_P1_IPFE:1;  
            vuint32_t B0_P1_PFLM:2;
            vuint32_t B0_P1_BFE:1;
            vuint32_t BK0_RWWC0:1;
            vuint32_t B0_P0_BCFG:2;
            vuint32_t B0_P0_DPFE:1;
            vuint32_t B0_P0_IPFE:1;
            vuint32_t B0_P0_PFLM:2;
            vuint32_t B0_P0_BFE:1;
        } B;
    } PFCR0;            /* Platform Flash Configuration Register 0 */

    union {                 /* CFLASH Configuration Register 1 */
        vuint32_t R;
        struct {
            vuint32_t BK1_APC:5;
            vuint32_t BK1_WWSC:5;
            vuint32_t BK1_RWSC:5;
            vuint32_t BK1_RWWC2:1;
            vuint32_t BK1_RWWC1:1;
            vuint32_t:6;
            vuint32_t B1_P1_BFE:1;
            vuint32_t BK1_RWWC0:1;
            vuint32_t:6;
            vuint32_t B1_P0_BFE:1;
        } B;
    } PFCR1;            /* Platform Flash Configuration Register 1 */

    union {                 /* cflash Access Protection Register */
        vuint32_t R;
        struct {
            vuint32_t:6;
            vuint32_t ARBM:2;
            vuint32_t M7PFD:1;
            vuint32_t M6PFD:1;
            vuint32_t M5PFD:1;
            vuint32_t M4PFD:1;
            vuint32_t M3PFD:1;
            vuint32_t M2PFD:1;
            vuint32_t M1PFD:1;
            vuint32_t M0PFD:1;
            vuint32_t M7AP:2;
            vuint32_t M6AP:2;
            vuint32_t M5AP:2;
            vuint32_t M4AP:2;
            vuint32_t M3AP:2;
            vuint32_t M2AP:2;
            vuint32_t M1AP:2;
            vuint32_t M0AP:2;
        } B;
    } PFAPR;                /* Platform Flash Access Protection Register */

    vuint32_t CFLASH_RESERVED_0[5]; /* 0x0028�0x003B */

    union {                 /* User Test Register 0 */
        vuint32_t R;
        struct {
            vuint32_t UTE:1;
            vuint32_t SBCE:1;
            vuint32_t:6;
            vuint32_t DSI:8;
            vuint32_t:10;
            vuint32_t MRE:1;
            vuint32_t MRV:1;
            vuint32_t EIE:1;
            vuint32_t AIS:1;
            vuint32_t AIE:1;
            vuint32_t AID:1;
        } B;
    } UT0;                /* User Test Register 0 */

    union {                 /* User Test Register 1 */
        vuint32_t R;
        struct {
            vuint32_t DAI:32;
        } B;
    } UT1;

    union {                 /* User Test Register 2 */
        vuint32_t R;
        struct {
            vuint32_t DAI:32;
        } B;
    } UT2;

    union {                 /* User Multiple Input Signature Register 0-4 */
        vuint32_t R;
        struct {
            vuint32_t MS:32;
        } B;
    } UMISR[5];

};                          /* end of CFLASH_tag */
/****************************************************************************/
/*                          MODULE : CRC                                    */
/****************************************************************************/
struct CRC_tag {

    union {
        vuint32_t R;
        struct {
            vuint32_t LEN:8;
            vuint32_t:20;
            vuint32_t POLYG:2;
            vuint32_t SWAP:1;                 
            vuint32_t INV:1;
        } B;
    } CRC_CFG1;            /* CRC Configuration Register Context 1 */

    union {
        vuint32_t R;
    } CRC_INP1;            /* CRC Input Register Context 1 */

    union {
        vuint32_t R;
    } CRC_CSTAT1;        /* CRC Current Status Register Context 1 */

    union {
        vuint32_t R;
    } CRC_OUTP1;        /* CRC Output Register Context 1 */

    union {
        vuint32_t R;
        struct {
            vuint32_t LEN:8;
            vuint32_t:20;
            vuint32_t POLYG:2;
            vuint32_t SWAP:1;                 
            vuint32_t INV:1;
        } B;
    } CRC_CFG2;            /* CRC Configuration Register Context 2 */

    union {
        vuint32_t R;
    } CRC_INP2;            /* CRC Input Register Context 2 */

    union {
        vuint32_t R;
    } CRC_CSTAT2;        /* CRC Current Status Register Context 2 */

    union {
        vuint32_t R;
    } CRC_OUTP2;        /* CRC Output Register Context 2 */

    union {
        vuint32_t R;
        struct {
            vuint32_t LEN:8;
            vuint32_t:20;
            vuint32_t POLYG:2;
            vuint32_t SWAP:1;                 
            vuint32_t INV:1;
        } B;
    } CRC_CFG3;            /* CRC Configuration Register Context 3 */

    union {
        vuint32_t R;
    } CRC_INP3;            /* CRC Input Register Context 3 */

    union {
        vuint32_t R;
    } CRC_CSTAT3;        /* CRC Current Status Register Context 3 */

    union {
        vuint32_t R;
    } CRC_OUTP3;        /* CRC Output Register Context 3 */

    vuint32_t CRC_RESERVED_0[52];    /* 0x0030-0x00FF */

    union {
        vuint32_t R;
    } CRC_OUTP_CHK1;    /* CRC Output Check Register Context 1 */

    vuint32_t CRC_RESERVED_1[3];    /* 0x0104-0x010F */

    union {
        vuint32_t R;
    } CRC_OUTP_CHK2;    /* CRC Output Check Register Context 2 */

    vuint32_t CRC_RESERVED_2[3];    /* 0x0114-0x011F */

    union {
        vuint32_t R;
    } CRC_OUTP_CHK3;    /* CRC Output Check Register Context 3 */

    vuint32_t CRC_RESERVED_3[4023];    /* 0x0124-0x3FFF */

};                        /* end of CRC_tag */

/****************************************************************************/
/*                SPC56xP60x specific devices                               */
/****************************************************************************/

/****************************************************************************/
/*                          MODULE : PBRIDGE                                */
/****************************************************************************/
struct PBRIDGE_tag {
    
    union {
        vuint32_t R;
        struct {
            vuint32_t  :1;
            vuint32_t  MPROT0_MTR:1;
            vuint32_t  MPROT0_MTW:1;
            vuint32_t  MPROT0_MPL:1;
            vuint32_t  :1;
            vuint32_t  MPROT1_MTR:1;
            vuint32_t  MPROT1_MTW:1;
            vuint32_t  MPROT1_MPL:1;
            vuint32_t  :1;
            vuint32_t  MPROT2_MTR:1;
            vuint32_t  MPROT2_MTW:1;
            vuint32_t  MPROT2_MPL:1;
            vuint32_t  :1;
            vuint32_t  MPROT3_MTR:1;
            vuint32_t  MPROT3_MTW:1;
            vuint32_t  MPROT3_MPL:1;
            vuint32_t  :16;
        } B;
    } MPROT_0_3;        /* Master Protection Registers 0/3 */

    vuint32_t PBRIDGE_RESERVED_0[7]; /* 0x0004-0x001F */

    union {
        vuint32_t R;
        struct {
            vuint32_t  :1;
            vuint32_t  PACR0_SP:1;
            vuint32_t  PACR0_WP:1;
            vuint32_t  PACR0_TP:1;
            vuint32_t  :1;
            vuint32_t  PACR1_SP:1;    /* Not present in PBRIDGE_1 */
            vuint32_t  PACR1_WP:1;    /* Not present in PBRIDGE_1 */
            vuint32_t  PACR1_TP:1;    /* Not present in PBRIDGE_1 */
            vuint32_t  :9;
            vuint32_t  PACR4_SP:1;
            vuint32_t  PACR4_WP:1;
            vuint32_t  PACR4_TP:1;
            vuint32_t  :12;
        } B;
    } PACR_0_7;            /* Peripheral Access Control Registers 0/7 */

    union {
        vuint32_t R;
        struct {
            vuint32_t  :5;
            vuint32_t  PACR9_SP:1;
            vuint32_t  PACR9_WP:1;
            vuint32_t  PACR9_TP:1;
            vuint32_t  :17;                
            vuint32_t  PACR14_SP:1;
            vuint32_t  PACR14_WP:1;
            vuint32_t  PACR14_TP:1;
            vuint32_t  :1;
            vuint32_t  PACR15_SP:1;
            vuint32_t  PACR15_WP:1;
            vuint32_t  PACR15_TP:1;
        } B;
    } PACR_8_15;        /* Peripheral Access Control Registers 8/15 */

    union {
        vuint32_t R;
        struct {
            vuint32_t  :1;
            vuint32_t  PACR16_SP:1;
            vuint32_t  PACR16_WP:1;
            vuint32_t  PACR16_TP:1;
            vuint32_t  :1;
            vuint32_t  PACR17_SP:1;    /* Not present in PBRIDGE_1 */
            vuint32_t  PACR17_WP:1;    /* Not present in PBRIDGE_1 */
            vuint32_t  PACR17_TP:1;    /* Not present in PBRIDGE_1 */
            vuint32_t  :1;
            vuint32_t  PACR18_SP:1;
            vuint32_t  PACR18_WP:1;
            vuint32_t  PACR18_TP:1;
            vuint32_t  :20;
        } B;
    } PACR_16_23;        /* Peripheral Access Control Registers 16/23 */

    vuint32_t PBRIDGE_RESERVED_1[5]; /* 0x002C-0x003F */

    union {
        vuint32_t R;
        struct {
            vuint32_t  :17;
            vuint32_t  OPACR4_SP:1;       
            vuint32_t  OPACR4_WP:1;       
            vuint32_t  OPACR4_TP:1;       
            vuint32_t  :1;
            vuint32_t  OPACR5_SP:1;       
            vuint32_t  OPACR5_WP:1;       
            vuint32_t  OPACR5_TP:1;       
            vuint32_t  :1;
            vuint32_t  OPACR6_SP:1;       
            vuint32_t  OPACR6_WP:1;       
            vuint32_t  OPACR6_TP:1;       
            vuint32_t  :1;
            vuint32_t  OPACR7_SP:1;       
            vuint32_t  OPACR7_WP:1;       
            vuint32_t  OPACR7_TP:1;       
        } B;
    } OPACR_0_7;        /* Off-Platform Peripheral Access Control Registers 0/7 */

    union {
        vuint32_t R;
        struct {
            vuint32_t  :1;
            vuint32_t  OPACR8_SP:1;    /* Not present in PBRIDGE_0 */       
            vuint32_t  OPACR8_WP:1;    /* Not present in PBRIDGE_0 */       
            vuint32_t  OPACR8_TP:1;    /* Not present in PBRIDGE_0 */
            vuint32_t  :28;
        } B;
    } OPACR_8_15;        /* Off-Platform Peripheral Access Control Registers 8/15 */

    union {
        vuint32_t R;
        struct {
            vuint32_t  :1;      
            vuint32_t  OPACR16_SP:1;      
            vuint32_t  OPACR16_WP:1;      
            vuint32_t  OPACR16_TP:1;      
            vuint32_t  :1;      
            vuint32_t  OPACR17_SP:1;    /* Not present in PBRIDGE_0 */      
            vuint32_t  OPACR17_WP:1;    /* Not present in PBRIDGE_0 */      
            vuint32_t  OPACR17_TP:1;    /* Not present in PBRIDGE_0 */
            vuint32_t  :21;
            vuint32_t  OPACR23_SP:1;      
            vuint32_t  OPACR23_WP:1;      
            vuint32_t  OPACR23_TP:1;      
        } B;
    } OPACR_16_23;        /* Off-Platform Peripheral Access Control Registers 16/23 */

    union {
        vuint32_t R;
        struct {
            vuint32_t  :1;      
            vuint32_t  OPACR24_SP:1;      
            vuint32_t  OPACR24_WP:1;      
            vuint32_t  OPACR24_TP:1;      
            vuint32_t  :5;      
            vuint32_t  OPACR26_SP:1;      
            vuint32_t  OPACR26_WP:1;      
            vuint32_t  OPACR26_TP:1;      
            vuint32_t  :17;      
            vuint32_t  OPACR31_SP:1;      
            vuint32_t  OPACR31_WP:1;      
            vuint32_t  OPACR31_TP:1;      
        } B;
    } OPACR_24_31;        /* Off-Platform Peripheral Access Control Registers 24/31 */

    union {
        vuint32_t R;
        struct {
            vuint32_t  :1;      
            vuint32_t  OPACR32_SP:1;      
            vuint32_t  OPACR32_WP:1;      
            vuint32_t  OPACR32_TP:1;      
            vuint32_t  :9;      
            vuint32_t  OPACR35_SP:1;      
            vuint32_t  OPACR35_WP:1;      
            vuint32_t  OPACR35_TP:1;      
            vuint32_t  :9;      
            vuint32_t  OPACR38_SP:1;      
            vuint32_t  OPACR38_WP:1;      
            vuint32_t  OPACR38_TP:1;      
            vuint32_t  :1;      
            vuint32_t  OPACR39_SP:1;      
            vuint32_t  OPACR39_WP:1;      
            vuint32_t  OPACR39_TP:1;      
        } B;
    } OPACR_32_39;        /* Off-Platform Peripheral Access Control Registers 32/39 */

    vuint32_t PBRIDGE_RESERVED_2[1]; /* 0x0054-0x0057 */

    union {
        vuint32_t R;
        struct {
            vuint32_t  :1;      
            vuint32_t  OPACR48_SP:1;      
            vuint32_t  OPACR48_WP:1;      
            vuint32_t  OPACR48_TP:1;      
            vuint32_t  :1;      
            vuint32_t  OPACR49_SP:1;      
            vuint32_t  OPACR49_WP:1;      
            vuint32_t  OPACR49_TP:1;      
            vuint32_t  :24;
        } B;
    } OPACR_48_55;        /* Off-Platform Peripheral Access Control Registers 48/55 */

    union {
        vuint32_t R;
        struct {
            vuint32_t  :9;      
            vuint32_t  OPACR58_SP:1;      
            vuint32_t  OPACR58_WP:1;      
            vuint32_t  OPACR58_TP:1;      
            vuint32_t  :1;      
            vuint32_t  OPACR59_SP:1;    /* Not present in PBRIDGE_0 */      
            vuint32_t  OPACR59_WP:1;    /* Not present in PBRIDGE_0 */      
            vuint32_t  OPACR59_TP:1;    /* Not present in PBRIDGE_0 */      
            vuint32_t  :1;      
            vuint32_t  OPACR60_SP:1;    /* Not present in PBRIDGE_0 */      
            vuint32_t  OPACR60_WP:1;    /* Not present in PBRIDGE_0 */      
            vuint32_t  OPACR60_TP:1;    /* Not present in PBRIDGE_0 */      
            vuint32_t  :5;      
            vuint32_t  OPACR62_SP:1;      
            vuint32_t  OPACR62_WP:1;      
            vuint32_t  OPACR62_TP:1;      
            vuint32_t  :4;      
        } B;
    } OPACR_56_63;        /* Off-Platform Peripheral Access Control Registers 56/63 */

    union {
        vuint32_t R;
        struct {
            vuint32_t  :9;      
            vuint32_t  OPACR66_SP:1;      
            vuint32_t  OPACR66_WP:1;      
            vuint32_t  OPACR66_TP:1;      
            vuint32_t  :1;      
            vuint32_t  OPACR67_SP:1;      
            vuint32_t  OPACR67_WP:1;      
            vuint32_t  OPACR67_TP:1;      
            vuint32_t  :1;      
            vuint32_t  OPACR68_SP:1;      
            vuint32_t  OPACR68_WP:1;      
            vuint32_t  OPACR68_TP:1;      
            vuint32_t  :1;      
            vuint32_t  OPACR69_SP:1;      
            vuint32_t  OPACR69_WP:1;      
            vuint32_t  OPACR69_TP:1;      
            vuint32_t  :8;      
        } B;
    } OPACR_64_71;        /* Off-Platform Peripheral Access Control Registers 64/71 */

    vuint32_t PBRIDGE_RESERVED_3[1]; /* 0x0064-0x0077 */

    union {
        vuint32_t R;
        struct {
            vuint32_t  :25;      
            vuint32_t  OPACR86_SP:1;      
            vuint32_t  OPACR86_WP:1;      
            vuint32_t  OPACR86_TP:1;      
            vuint32_t  :1;      
            vuint32_t  OPACR87_SP:1;      
            vuint32_t  OPACR87_WP:1;      
            vuint32_t  OPACR87_TP:1;      
        } B;
    } OPACR_80_87;        /* Off-Platform Peripheral Access Control Registers 80/87 */

    union {
        vuint32_t R;
        struct {
            vuint32_t  :1;      
            vuint32_t  OPACR88_SP:1;      
            vuint32_t  OPACR88_WP:1;      
            vuint32_t  OPACR88_TP:1;      
            vuint32_t  :1;      
            vuint32_t  OPACR89_SP:1;      
            vuint32_t  OPACR89_WP:1;      
            vuint32_t  OPACR89_TP:1;      
            vuint32_t  :1;      
            vuint32_t  OPACR90_SP:1;      
            vuint32_t  OPACR90_WP:1;      
            vuint32_t  OPACR90_TP:1;      
            vuint32_t  :5;      
            vuint32_t  OPACR92_SP:1;      
            vuint32_t  OPACR92_WP:1;      
            vuint32_t  OPACR92_TP:1;      
            vuint32_t  :12;           
        } B;
    } OPACR_88_95;        /* Off-Platform Peripheral Access Control Registers 88/95 */

    vuint32_t PBRIDGE_RESERVED_4[4068]; /* 0x0070-0x3FFF */

};                        /* end of PBRIDGE_tag */
/****************************************************************************/
/*                          MODULE : XBAR                                   */
/****************************************************************************/
struct XBAR_tag {
    struct {
        union {
            vuint32_t R;
            struct {
                vuint32_t:1;
                vuint32_t MSTR_7:3;
                vuint32_t:1;
                vuint32_t MSTR_6:3;
                vuint32_t:1;
                vuint32_t MSTR_5:3;
                vuint32_t:1;
                vuint32_t MSTR_4:3;
                vuint32_t:1;
                vuint32_t MSTR_3:3;
                vuint32_t:1;
                vuint32_t MSTR_2:3;
                vuint32_t:1;
                vuint32_t MSTR_1:3;
                vuint32_t:1;
                vuint32_t MSTR_0:3;
            }BIT;
        } MPR;                /* Master Priority Register for Slave Port n */

        vuint32_t XBAR_RESERVED_0[3];  /* 0x0n04-0x0n0F */

        union {
            vuint32_t R;
            struct {
                vuint32_t RO:1;
                vuint32_t HLP:1;
                vuint32_t:6;
                vuint32_t HPE_7:1;
                vuint32_t HPE_6:1;
                vuint32_t HPE_5:1;
                vuint32_t HPE_4:1;
                vuint32_t HPE_3:1;
                vuint32_t HPE_2:1;
                vuint32_t HPE_1:1;
                vuint32_t HPE_0:1;
                vuint32_t:6;
                vuint32_t ARB:2;
                vuint32_t:2;
                vuint32_t PCTL:2;
                vuint32_t:1;
                vuint32_t PARK:3;
            } B;
        } SGPCR;            /* Slave General Purpose Control Register */

        vuint32_t XBAR_RESERVED_1[59];  /* 0x0n14-0x0nFF */

    } SLAVEPORT[8];

    struct {
        union {
            vuint32_t R;
            struct {
                vuint32_t:29;
                vuint32_t AULB:3;
            }BIT;
        } MGPCR;            /* Master General Purpose Control Register */

        vuint32_t XBAR_RESERVED_2[63];  /* 0x0n04-0x0nFF */

    } MASTERPORT[8];

    vuint32_t XBAR_RESERVED_3[3135];  /* 0x0F04-0x3FFF */

};                            /* end of XBAR_tag */
/****************************************************************************/
/*                          MODULE : SEMA4                                  */
/****************************************************************************/
struct SEMA4_tag {

    union { 
        struct {
            vuint8_t:6;
            vuint8_t GTFSM:2;
        } B;
    } SEMA4_GATE[16];    /* Semaphores Gate 0/15 */

    vuint16_t SEMA4_RESERVED_0[24]; /* 0x0010�0x003F */

    union { 
        vuint16_t R;
        struct {
            vuint16_t INE0:1;
            vuint16_t INE1:1;
            vuint16_t INE2:1;
            vuint16_t INE3:1;
            vuint16_t INE4:1;
            vuint16_t INE5:1;
            vuint16_t INE6:1;
            vuint16_t INE7:1;
            vuint16_t INE8:1;
            vuint16_t INE9:1;
            vuint16_t INE10:1;
            vuint16_t INE11:1;
            vuint16_t INE12:1;
            vuint16_t INE13:1;
            vuint16_t INE14:1;
            vuint16_t INE15:1;
        } B;
    } SEMA4_CP0INE;        /* Semaphores CP0 IRQ Notification Enable */

    vuint16_t SEMA4_RESERVED_1[3]; /* 0x0042�0x0047 */

    union { 
        vuint16_t R;
        struct {
            vuint16_t INE0:1;
            vuint16_t INE1:1;
            vuint16_t INE2:1;
            vuint16_t INE3:1;
            vuint16_t INE4:1;
            vuint16_t INE5:1;
            vuint16_t INE6:1;
            vuint16_t INE7:1;
            vuint16_t INE8:1;
            vuint16_t INE9:1;
            vuint16_t INE10:1;
            vuint16_t INE11:1;
            vuint16_t INE12:1;
            vuint16_t INE13:1;
            vuint16_t INE14:1;
            vuint16_t INE15:1;
        } B;
    } SEMA4_CP1INE;        /* Semaphores CP1 IRQ Notification Enable */

    vuint16_t SEMA4_RESERVED_2[27]; /* 0x004A�0x07F */

    union {
        vuint16_t R;
        struct {
            vuint16_t GN0:1;
            vuint16_t GN1:1;
            vuint16_t GN2:1;
            vuint16_t GN3:1;
            vuint16_t GN4:1;
            vuint16_t GN5:1;
            vuint16_t GN6:1;
            vuint16_t GN7:1;
            vuint16_t GN8:1;
            vuint16_t GN9:1;
            vuint16_t GN10:1;
            vuint16_t GN11:1;
            vuint16_t GN12:1;
            vuint16_t GN13:1;
            vuint16_t GN14:1;
            vuint16_t GN15:1;
        } B;
    } SEMA4_CP0NTF;        /* Semaphores CP0 IRQ Notification */

    vuint16_t SEMA4_RESERVED_3[3]; /* 0x0082�00x087 */

    union {
        vuint16_t R;
        struct {
            vuint16_t GN0:1;
            vuint16_t GN1:1;
            vuint16_t GN2:1;
            vuint16_t GN3:1;
            vuint16_t GN4:1;
            vuint16_t GN5:1;
            vuint16_t GN6:1;
            vuint16_t GN7:1;
            vuint16_t GN8:1;
            vuint16_t GN9:1;
            vuint16_t GN10:1;
            vuint16_t GN11:1;
            vuint16_t GN12:1;
            vuint16_t GN13:1;
            vuint16_t GN14:1;
            vuint16_t GN15:1;
        } B;
    } SEMA4_CP1NTF;        /* Semaphores CP1 IRQ Notification */

    vuint16_t SEMA4_RESERVED_4[59]; /* 0x008A�0x00FF */

    union {
        vuint16_t R;
        struct {
            vuint16_t:2;
            vuint16_t RSTGSM:2;
            vuint16_t:1;
            vuint16_t RSTGMS:3;
            vuint16_t RSTGTN:8;
        } B;
    } SEMA4_RSTGT;        /* Semaphores Reset Gate */

    vuint16_t SEMA4_RESERVED_5[1]; /* 0x0102�0x0103 */

    union {
        vuint16_t R;
        struct {
            vuint16_t:2;
            vuint16_t RSTNSM:2;
            vuint16_t:1;
            vuint16_t RSTNMS:3;
            vuint16_t RSTNTN:8;
        } B;
    } SEMA4_RSTNTF;        /* Semaphores Reset IRQ Notification */

    vuint16_t SEMA4_RESERVED_6[8061]; /* 0x0106�0x3FFF */

};                        /* end of SEMA4_tag */
/****************************************************************************/
/*                          MODULE : FCCU                                   */
/****************************************************************************/    
struct FCCU_tag {

    union {
        vuint32_t R;
          struct {
            vuint32_t:23;
            vuint32_t NVML:1;
            vuint32_t OPS:2; 
            vuint32_t:1;
            vuint32_t OPR:5;
          } B;
    } FCCU_CTRL;        /* FCCU Control Register */

    union {
        vuint32_t R;
    } FCCU_CTRLK;        /* FCCU CTRL Key Register */

       union {             
        vuint32_t R;
          struct {
            vuint32_t:10;
            vuint32_t RCCE1:1;
            vuint32_t RCCE0:1;
            vuint32_t SMRT:4; 
            vuint32_t:4;
            vuint32_t CM:1;
            vuint32_t SM:1;
            vuint32_t PS:1;
            vuint32_t FOM:3;
            vuint32_t FOP:6;
        } B;
    } FCCU_CFG;            /* FCCU Config Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t CFC31:1;
            vuint32_t CFC30:1;
            vuint32_t CFC29:1;
            vuint32_t CFC28:1;
            vuint32_t CFC27:1;
            vuint32_t CFC26:1;
            vuint32_t CFC25:1;
            vuint32_t CFC24:1;
            vuint32_t CFC23:1;
            vuint32_t CFC22:1;
            vuint32_t CFC21:1;
            vuint32_t CFC20:1;
            vuint32_t CFC19:1;
            vuint32_t CFC18:1;
            vuint32_t CFC17:1;
            vuint32_t CFC16:1;
            vuint32_t CFC15:1;
            vuint32_t CFC14:1;
            vuint32_t CFC13:1;
            vuint32_t CFC12:1;
            vuint32_t CFC11:1;
            vuint32_t CFC10:1;
            vuint32_t CFC9:1;
            vuint32_t CFC8:1;
            vuint32_t CFC7:1;
            vuint32_t CFC6:1;
            vuint32_t CFC5:1;
            vuint32_t CFC4:1;
            vuint32_t CFC3:1;
            vuint32_t CFC2:1;
            vuint32_t CFC1:1;
            vuint32_t CFC0:1;
        } B;    
    } FCCU_CF_CFG[4];    /* FCCU CF Configuration Registers */

    union {
        vuint32_t R;
        struct {
            vuint32_t NCFC31:1;
            vuint32_t NCFC30:1;
            vuint32_t NCFC29:1;
            vuint32_t NCFC28:1;
            vuint32_t NCFC27:1;
            vuint32_t NCFC26:1;
            vuint32_t NCFC25:1;
            vuint32_t NCFC24:1;
            vuint32_t NCFC23:1;
            vuint32_t NCFC22:1;
            vuint32_t NCFC21:1;
            vuint32_t NCFC20:1;
            vuint32_t NCFC19:1;
            vuint32_t NCFC18:1;
            vuint32_t NCFC17:1;
            vuint32_t NCFC16:1;
            vuint32_t NCFC15:1;
            vuint32_t NCFC14:1;
            vuint32_t NCFC13:1;
            vuint32_t NCFC12:1;
            vuint32_t NCFC11:1;
            vuint32_t NCFC10:1;
            vuint32_t NCFC9:1;
            vuint32_t NCFC8:1;
            vuint32_t NCFC7:1;
            vuint32_t NCFC6:1;
            vuint32_t NCFC5:1;
            vuint32_t NCFC4:1;
            vuint32_t NCFC3:1;
            vuint32_t NCFC2:1;
            vuint32_t NCFC1:1;
            vuint32_t NCFC0:1;
        } B;    
    } FCCU_NCF_CFG[4];    /* FCCU NCF Configuration Registers */

    union {
        vuint32_t R;
        struct {
            vuint32_t CFSC15:2;
            vuint32_t CFSC14:2;
            vuint32_t CFSC13:2;
            vuint32_t CFSC12:2;
            vuint32_t CFSC11:2;
            vuint32_t CFSC10:2;
            vuint32_t CFSC9:2;
            vuint32_t CFSC8:2;
            vuint32_t CFSC7:2;
            vuint32_t CFSC6:2;
            vuint32_t CFSC5:2;
            vuint32_t CFSC4:2;
            vuint32_t CFSC3:2;
            vuint32_t CFSC2:2;
            vuint32_t CFSC1:2;
            vuint32_t CFSC0:2;
        } B;
    } FCCU_CFS_CFG[8];    /* FCCU CFS Configuration Registers */

    union {
        vuint32_t R;
        struct {
            vuint32_t NCFSC15:2;
            vuint32_t NCFSC14:2;
            vuint32_t NCFSC13:2;
            vuint32_t NCFSC12:2;
            vuint32_t NCFSC11:2;
            vuint32_t NCFSC10:2;
            vuint32_t NCFSC9:2;
            vuint32_t NCFSC8:2;
            vuint32_t NCFSC7:2;
            vuint32_t NCFSC6:2;
            vuint32_t NCFSC5:2;
            vuint32_t NCFSC4:2;
            vuint32_t NCFSC3:2;
            vuint32_t NCFSC2:2;
            vuint32_t NCFSC1:2;
            vuint32_t NCFSC0:2;
        } B;
    } FCCU_NCFS_CFG[8];    /* FCCU NCFS Configuration Registers */

    union {
        vuint32_t R;
        struct {
            vuint32_t CFS31:1;
            vuint32_t CFS30:1;
            vuint32_t CFS29:1;
            vuint32_t CFS28:1;
            vuint32_t CFS27:1;
            vuint32_t CFS26:1;
            vuint32_t CFS25:1;
            vuint32_t CFS24:1;
            vuint32_t CFS23:1;
            vuint32_t CFS22:1;
            vuint32_t CFS21:1;
            vuint32_t CFS20:1;
            vuint32_t CFS19:1;
            vuint32_t CFS18:1;
            vuint32_t CFS17:1;
            vuint32_t CFS16:1;
            vuint32_t CFS15:1;
            vuint32_t CFS14:1;
            vuint32_t CFS13:1;
            vuint32_t CFS12:1;
            vuint32_t CFS11:1;
            vuint32_t CFS10:1;
            vuint32_t CFS9:1;
            vuint32_t CFS8:1;
            vuint32_t CFS7:1;
            vuint32_t CFS6:1;
            vuint32_t CFS5:1;
            vuint32_t CFS4:1;
            vuint32_t CFS3:1;
            vuint32_t CFS2:1;
            vuint32_t CFS1:1;
            vuint32_t CFS0:1;
        } B;    
    } FCCU_CFS[4];        /* FCCU CF Status Registers */

    union {
        vuint32_t R;
    } FCCU_CFK;            /* FCCU CF Key Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t NCFS31:1;
            vuint32_t NCFS30:1;
            vuint32_t NCFS29:1;
            vuint32_t NCFS28:1;
            vuint32_t NCFS27:1;
            vuint32_t NCFS26:1;
            vuint32_t NCFS25:1;
            vuint32_t NCFS24:1;
            vuint32_t NCFS23:1;
            vuint32_t NCFS22:1;
            vuint32_t NCFS21:1;
            vuint32_t NCFS20:1;
            vuint32_t NCFS19:1;
            vuint32_t NCFS18:1;
            vuint32_t NCFS17:1;
            vuint32_t NCFS16:1;
            vuint32_t NCFS15:1;
            vuint32_t NCFS14:1;
            vuint32_t NCFS13:1;
            vuint32_t NCFS12:1;
            vuint32_t NCFS11:1;
            vuint32_t NCFS10:1;
            vuint32_t NCFS9:1;
            vuint32_t NCFS8:1;
            vuint32_t NCFS7:1;
            vuint32_t NCFS6:1;
            vuint32_t NCFS5:1;
            vuint32_t NCFS4:1;
            vuint32_t NCFS3:1;
            vuint32_t NCFS2:1;
            vuint32_t NCFS1:1;
            vuint32_t NCFS0:1;
        } B;    
    } FCCU_NCFS[4];        /* FCCU NCF Status Registers */

    union {
        vuint32_t R;
    } FCCU_NCFK;        /* FCCU NCF Key Register */

    union {    
        vuint32_t R;
        struct {
            vuint32_t NCFE31:1;
            vuint32_t NCFE30:1;
            vuint32_t NCFE29:1;
            vuint32_t NCFE28:1;
            vuint32_t NCFE27:1;
            vuint32_t NCFE26:1;
            vuint32_t NCFE25:1;
            vuint32_t NCFE24:1;
            vuint32_t NCFE23:1;
            vuint32_t NCFE22:1;
            vuint32_t NCFE21:1;
            vuint32_t NCFE20:1;
            vuint32_t NCFE19:1;
            vuint32_t NCFE18:1;
            vuint32_t NCFE17:1;
            vuint32_t NCFE16:1;
            vuint32_t NCFE15:1;
            vuint32_t NCFE14:1;
            vuint32_t NCFE13:1;
            vuint32_t NCFE12:1;
            vuint32_t NCFE11:1;
            vuint32_t NCFE10:1;
            vuint32_t NCFE9:1;
            vuint32_t NCFE8:1;
            vuint32_t NCFE7:1;
            vuint32_t NCFE6:1;
            vuint32_t NCFE5:1;
            vuint32_t NCFE4:1;
            vuint32_t NCFE3:1;
            vuint32_t NCFE2:1;
            vuint32_t NCFE1:1;
            vuint32_t NCFE0:1;
        } B;    
    } FCCU_NCFE[4];        /* FCCU NCF Enable Registers */

    union {
        vuint32_t R;
        struct {
            vuint32_t NCFTOE31:1;
            vuint32_t NCFTOE30:1;
            vuint32_t NCFTOE29:1;
            vuint32_t NCFTOE28:1;
            vuint32_t NCFTOE27:1;
            vuint32_t NCFTOE26:1;
            vuint32_t NCFTOE25:1;
            vuint32_t NCFTOE24:1;
            vuint32_t NCFTOE23:1;
            vuint32_t NCFTOE22:1;
            vuint32_t NCFTOE21:1;
            vuint32_t NCFTOE20:1;
            vuint32_t NCFTOE19:1;
            vuint32_t NCFTOE18:1;
            vuint32_t NCFTOE17:1;
            vuint32_t NCFTOE16:1;
            vuint32_t NCFTOE15:1;
            vuint32_t NCFTOE14:1;
            vuint32_t NCFTOE13:1;
            vuint32_t NCFTOE12:1;
            vuint32_t NCFTOE11:1;
            vuint32_t NCFTOE10:1;
            vuint32_t NCFTOE9:1;
            vuint32_t NCFTOE8:1;
            vuint32_t NCFTOE7:1;
            vuint32_t NCFTOE6:1;
            vuint32_t NCFTOE5:1;
            vuint32_t NCFTOE4:1;
            vuint32_t NCFTOE3:1;
            vuint32_t NCFTOE2:1;
            vuint32_t NCFTOE1:1;
            vuint32_t NCFTOE0:1;
        } B;    
    } FCCU_NCF_TOE[4];    /* FCCU NCF Time-out Enable Registers */

    union {
        vuint32_t R;
    } FCCU_NCF_TO;        /* FCCU NCF Time-out Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:29;
            vuint32_t TO:3;
        } B;
    } FCCU_CFG_TO;        /* FCCU CFG Time-out Register */

    vuint32_t FCCU_RESERVED_0[1]; /* 0x00BC-0x00BF */

    union {
        vuint32_t R;
        struct {
            vuint32_t:29;
            vuint32_t STATUS:3;
        } B;
    } FCCU_STAT;        /* FCCU Status Register */

    vuint32_t FCCU_RESERVED_1[5]; /* 0x00C4-0x00D7 */    

    union {
        vuint32_t R;
        struct {
            vuint32_t:25;
            vuint32_t FCFC:7;
        } B;
    } FCCU_CFF;            /* FCCU CF Fake Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:25;
            vuint32_t FNCFC:7;
        } B;
    } FCCU_NCFF;        /* FCCU NCF Fake Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t:30;
            vuint32_t ALARM_STAT:1;
            vuint32_t CFG_TO_STAT:1;
        } B;
    } FCCU_IRQ_STAT;    /* FCCU IRQ Status Register */        

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t CFG_TO_IEN:1;
        } B;
    } FCCU_IRQ_EN;        /* FCCU IRQ Enable Register */

    union {
        vuint32_t R;
    } FCCU_XTMR;        /* FCCU XTMR Register */

    union {
        vuint32_t R;
        struct {
            vuint32_t VL3:1;
            vuint32_t FS3:1;
            vuint32_t:2;
            vuint32_t MCS3:4;
            vuint32_t VL2:1;
            vuint32_t FS2:1;
            vuint32_t:2;
            vuint32_t MCS2:4;
            vuint32_t VL1:1;
            vuint32_t FS1:1;
            vuint32_t:2;
            vuint32_t MCS1:4;
            vuint32_t VL0:1;
            vuint32_t FS0:1;
            vuint32_t:2;
            vuint32_t MCS0:4;
        } B;
    } FCCU_MCS;            /* FCCU MCS Register */

    vuint32_t FCCU_RESERVED_2[4036]; /* 0x00F0-0x3FFF */

};                        /* end of FCCU_tag */
/****************************************************************************/
/*                          MODULE : MPU                                    */
/****************************************************************************/
struct MPU_tag {

    union {
        vuint32_t R;
        struct {
            vuint32_t SPERR:3;
            vuint32_t:9;
            vuint32_t HRL:4;
            vuint32_t NSP:4;
            vuint32_t NRGD:4;
            vuint32_t:7;
            vuint32_t VLD:1;
        } B;
    } MPU_CESR;            /* MPU Control/Error Status Register */

    vuint32_t MPU_RESERVED_0[3]; /* 0x0004�0x000F */

    union {
        vuint32_t R;
        struct {
            vuint32_t EADDR:32;
        } B;
    } MPU_EAR0;            /* MPU Error Address Register, Slave Port 0 */

    union {
        vuint32_t R;
        struct {
            vuint32_t EACD:16;
            vuint32_t EPID:8;
            vuint32_t EMN:4;
            vuint32_t EATTR:3;
            vuint32_t ERW:1;
        } B;
    } MPU_EDR0;            /* MPU Error Detail Register, Slave Port 0 */

    union {
        vuint32_t R;
        struct {
            vuint32_t EADDR:32;
        } B;
    } MPU_EAR1;            /* MPU Error Address Register, Slave Port 1 */

    union {
        vuint32_t R;
        struct {
            vuint32_t EACD:16;
            vuint32_t EPID:8;
            vuint32_t EMN:4;
            vuint32_t EATTR:3;
            vuint32_t ERW:1;
        } B;
    } MPU_EDR1;            /* MPU Error Detail Register, Slave Port 1 */
    
    union {
        vuint32_t R;
        struct {
            vuint32_t EADDR:32;
        } B;
    } MPU_EAR2;            /* MPU Error Address Register, Slave Port 2 */

    union {
        vuint32_t R;
        struct {
            vuint32_t EACD:16;
            vuint32_t EPID:8;
            vuint32_t EMN:4;
            vuint32_t EATTR:3;
            vuint32_t ERW:1;
        } B;
    } MPU_EDR2;            /* MPU Error Detail Register, Slave Port 2 */        

    vuint32_t MPU_RESERVED_1[246]; /* 0x0028�0x03FF */

    struct {
        union {
            vuint32_t R;
            struct {
                vuint32_t SRTADDR:27;
                vuint32_t:5;
            } B;
        } WORD0;            /* Region Descriptor n Word 0 */

        union {
            vuint32_t R;
            struct {
                vuint32_t ENDADDR:27;
                vuint32_t:5;
            } B;
        } WORD1;            /* Region Descriptor n Word 1 */

        union {
            vuint32_t R;
            struct {
                vuint32_t:8;
                vuint32_t M3PE:1;
                vuint32_t M3SM:2;
                vuint32_t M3UM:3;
                vuint32_t M2PE:1;
                vuint32_t M2SM:2;
                vuint32_t M2UM:3;
                vuint32_t M1PE:1;
                vuint32_t M1SM:2;
                vuint32_t M1UM:3;
                vuint32_t M0PE:1;
                vuint32_t M0SM:2;
                vuint32_t M0UM:3;
            } B;
        } WORD2;            /* Region Descriptor n Word 2 */

        union {
            vuint32_t R;
            struct {
                vuint32_t PID:8;
                vuint32_t PIDMASK:8;
                vuint32_t:15;
                vuint32_t VLD:1;
            } B;
        } WORD3;            /* Region Descriptor n Word 3 */

    } MPU_RGD[16];        /* MPU Region Descriptor 0/15 */

    vuint32_t MPU_RESERVED_2[192]; /* 0x0500�0x07FF */

    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t M3PE:1;
            vuint32_t M3SM:2;
            vuint32_t M3UM:3;
            vuint32_t M2PE:1;
            vuint32_t M2SM:2;
            vuint32_t M2UM:3;
            vuint32_t M1PE:1;
            vuint32_t M1SM:2;
            vuint32_t M1UM:3;
            vuint32_t M0PE:1;
            vuint32_t M0SM:2;
            vuint32_t M0UM:3;
        } B;
    } MPU_RGDAAC[16];    /* MPU RGD Alternate Access Control 0/15 */
    
};                        /* end of MPU_tag */


/****************************************************************************/    
/* Defines and macros (scope: module-local)                                 */ 
/****************************************************************************/    
/* Define instances of modules                                              */
/****************************************************************************/    
#define PBRIDGE_1  (*(volatile struct PBRIDGE_tag *)   0x8FF00000UL)
#define MPU_1      (*(volatile struct MPU_tag *)       0x8FF10000UL)
#define SEMA4_1    (*(volatile struct SEMA4_tag *)     0x8FF24000UL)
#define SWT_1      (*(volatile struct SWT_tag *)       0x8FF38000UL)
#define STM_1      (*(volatile struct STM_tag *)       0x8FF3C000UL)
#define ECSM_1     (*(volatile struct ECSM_tag *)      0x8FF40000UL)
#define INTC_1     (*(volatile struct INTC_tag*)       0x8FF48000UL)
#define DSPI_4     (*(volatile struct DSPI_tag *)      0x8FFA0000UL) 
#define CAN_1      (*(volatile struct FLEXCAN_tag *)   0x8FFC4000UL)
#define FCCU       (*(volatile struct FCCU_tag *)      0x9FE6C000UL)
#define CRC_1      (*(volatile struct CRC_tag *)       0x9FE70000UL)
#define CFLASH     (*(volatile struct CFLASH_tag *)    0xC3F88000UL)
#define DFLASH     (*(volatile struct DFLASH_tag *)    0xC3F8C000UL)
#define SIUL       (*(volatile struct SIUL_tag *)      0xC3F90000UL)
#define WKUP       (*(volatile struct WKUP_tag *)      0xC3F94000UL)
#define SSCM       (*(volatile struct SSCM_tag *)      0xC3FD8000UL)
#define ME         (*(volatile struct ME_tag *)        0xC3FDC000UL)
#define CGM        (*(volatile struct CGM_tag *)       0xC3FE0000UL)
#define RGM        (*(volatile struct RGM_tag *)       0xC3FE4000UL)
#define PCU        (*(volatile struct PCU_tag *)       0xC3FE8000UL)
#define PIT        (*(volatile struct PIT_tag *)       0xC3FF0000UL)    
#define ADC_0      (*(volatile struct ADC_tag *)       0xFFE00000UL)
#define CTU_0      (*(volatile struct CTU_tag *)       0xFFE0C000UL)
#define ETIMER_0   (*(volatile struct ETIMER_tag *)    0xFFE18000UL)
#define ETIMER_1   (*(volatile struct ETIMER_tag *)    0xFFE1C000UL)
#define LINFLEX_0  (*(volatile struct LINFLEX_tag *)   0xFFE40000UL)
#define LINFLEX_1  (*(volatile struct LINFLEX_tag *)   0xFFE44000UL)
#define CRC_0      (*(volatile struct CRC_tag *)       0xFFE68000UL)
#define PBRIDGE_0  (*(volatile struct PBRIDGE_tag *)   0xFFF00000UL)
#define XBAR_0     (*(volatile struct XBAR_tag *)      0xFFF04000UL)
#define MPU_0      (*(volatile struct MPU_tag *)       0xFFF10000UL)
#define SEMA4_0    (*(volatile struct SEMA4_tag *)     0xFFF24000UL)
#define SWT_0      (*(volatile struct SWT_tag *)       0xFFF38000UL)
#define STM_0      (*(volatile struct STM_tag *)       0xFFF3C000UL)
#define ECSM       (*(volatile struct ECSM_tag *)      0xFFF40000UL)
#define EDMA       (*(volatile struct EDMA_tag *)      0xFFF44000UL)
#define INTC_0     (*(volatile struct INTC_tag *)      0xFFF48000UL)
#define DSPI_0     (*(volatile struct DSPI_tag *)      0xFFF90000UL)
#define DSPI_1     (*(volatile struct DSPI_tag *)      0xFFF94000UL)
#define DSPI_2     (*(volatile struct DSPI_tag *)      0xFFF98000UL)
#define DSPI_3     (*(volatile struct DSPI_tag *)      0xFFF9C000UL)
#define CAN_0      (*(volatile struct FLEXCAN_tag *)   0xFFFC0000UL)
#define DMA_MUX    (*(volatile struct DMA_MUX_tag *)   0xFFFDC000UL)
#define FLEXRAY    (*(volatile struct FLEXRAY_tag *)   0xFFFE0000UL)
#define SAFETYPORT (*(volatile struct FLEXCAN_tag *)   0xFFFE8000UL)

#ifdef __MWERKS__
#pragma pop
#endif

#ifdef  __cplusplus
}
#endif
#endif                          /* ifdef _JDP_H */
/* End of file */
