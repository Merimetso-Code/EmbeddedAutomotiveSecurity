/****************************************************************************
*
* Copyright © 2015-2019 STMicroelectronics - All Rights Reserved
*
* This software is licensed under SLA0098 terms that can be found in the
* DM00779817_1_0.pdf file in the licenses directory of this software product.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
*****************************************************************************/

#include "board.h"
#include "clock.h"

/* Initial setup of all defined pads, the list is terminated by a {-1, 0, 0}.*/
static const spc_siu_init_t spc_siu_init[] = {
  {(int32_t)PCR_INDEX(PORT_A, Led_D11), PAL_LOW,    (iomode_t)(PAL_MODE_OUTPUT_PUSHPULL)},
  {(int32_t)PCR_INDEX(PORT_A, Led_D12), PAL_LOW,    (iomode_t)(PAL_MODE_OUTPUT_PUSHPULL)},
  {(int32_t)PCR_INDEX(PORT_G, Led_D13), PAL_LOW,    (iomode_t)(PAL_MODE_OUTPUT_PUSHPULL)},
  {(int32_t)PCR_INDEX(PORT_B, PIN_LIN0TXD), PAL_LOW,    (iomode_t)(PAL_MODE_OUTPUT_ALTERNATE(1))},
  {(int32_t)PCR_INDEX(PORT_B, PIN_LIN0RXD), PAL_LOW,    (iomode_t)(PAL_MODE_INPUT)},
  {-1, 0, 0}
};

/* Initialization array for the PSMI registers.*/
static const uint8_t spc_padsels_init[SPC5_SIUL_NUM_PADSELS] = {
  0,   0,   0,   0,   0,   0,   0,   0,   
  0,   0,   0,   0,   0,   0,   0,   0,   
  0,   0,   0,   0,   0,   0,   0,   0,   
  0,   0,   0,   0,   0,   0,   0,   0,   
  0,   0,   0,   0,   
};

/**
 * @brief   PAL setup.
 */
static const PALConfig pal_default_config = {
  (iomode_t)(PAL_MODE_UNCONNECTED),
  spc_siu_init,
  spc_padsels_init
};

/*
 * Board-specific initialization code.
 */
void boardInit(void) {

  pal_init(&pal_default_config);
}
