For this test application the file debug.wsx points to the target configuration
file for SPC560P-DISP Discovery Board (spc560p_discovery_debug_jtag.cfg).