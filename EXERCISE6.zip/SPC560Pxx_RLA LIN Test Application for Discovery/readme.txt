This application shows how to the use the LIN driver.
It configures a master and a slave LIN clients.

*) LIN_FLEX_0 --> Slave
*) LIN_FLEX_1 --> Master


Hence, in order to use this demo, LIN_FLEX_0 must be connected to LIN_FLEX_1 using two wires
with the following scheme:

*)  LIN_FLEX_0_TX  <--> LIN_FLEX_1_RX
*)  LIN_FLEX_0_RX  <--> LIN_FLEX_1_TX


TX and RX pins for either LIN_FLEX_0 and LIN_FLEX_1 are on connector X4 (on SPC560P Discovery board)

  LIN_FLEX_0_TX   B2   C[11]
  LIN_FLEX_0_RX   B3   D[11]

  LIN_FLEX_1_TX   F14  B[21]
  LIN_FLEX_1_RX   F15  A[21]

So, the connections should be:

   C[11]   <-->   A[21]
   D[11]   <-->   B[21]


The application will also use the three LEDs available on SPC560P Discovery board as following:

  LED11
  LED12
  LED13


=>  TX   toggles LED11
=>  RX   toggles LED12
=>  ERR  toggles LED13


The demo configures 4 messages (IDs: 37, 38, 45, 46)

ID 37: Used by master to read 4 bytes from slave.  
ID 38: Used by master to send 4 bytes to slave.
ID 45: Used by master to read 8 bytes from slave.
ID 46: Used by master to send 8 bytes to slave.

Slave LIN device work on interrupts receiving and sending data via callbacks.

The application toggle LED11 on data transmit and LED12 on data receive, so
if the received data are the expected ones, the two leds blinking alternatively.
In case of mismatch between the data transmitted and data received, LED13 is toggled.

Enjoy.