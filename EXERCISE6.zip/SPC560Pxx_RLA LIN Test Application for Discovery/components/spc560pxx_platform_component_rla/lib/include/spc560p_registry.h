/****************************************************************************
*
* Copyright © 2015-2019 STMicroelectronics - All Rights Reserved
*
* This software is licensed under SLA0098 terms that can be found in the
* DM00779817_1_0.pdf file in the licenses directory of this software product.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
*****************************************************************************/

/**
 * @file    spc560p_registry.h
 * @brief   SPC560Pxx capabilities registry.
 *
 * @addtogroup PLATFORM
 * @{
 */

#ifndef _SPC560P_REGISTRY_H_
#define _SPC560P_REGISTRY_H_

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

#if defined(_SPC560P34L1_) || defined(_SPC560P34L3_)
#define _SPC560P34_
#define _SPC560PXX_SMALL_
#elif defined(_SPC560P40L1_) || defined(_SPC560P40L3_)
#define _SPC560P40_
#define _SPC560PXX_SMALL_
#elif defined(_SPC560P44L3_) || defined(_SPC560P44L5_)
#define _SPC560P44_
#define _SPC560PXX_MEDIUM_
#elif defined(_SPC560P50L3_) || defined(_SPC560P50L5_)
#define _SPC560P50_
#define _SPC560PXX_MEDIUM_
#elif defined(_SPC560P54L3_) || defined(_SPC560P54L5_) || defined(_SPC56AP54L3_) || defined(_SPC56AP54L5_)
#define _SPC560P54_
#define _SPC560PXX_LARGE_
#elif defined(_SPC560P60L3_) || defined(_SPC560P60L5_) || defined(_SPC56AP60L3_) || defined(_SPC56AP60L5_)
#define _SPC560P60_
#define _SPC560PXX_LARGE_
#else
#error "SPC56xPxx platform not defined"
#endif

/*===========================================================================*/
/* Platform capabilities.                                                    */
/*===========================================================================*/

/**
 * @name    SPC560Pxx capabilities
 * @{
 */
/* Clock attributes.*/
#if defined(_SPC560PXX_SMALL_)
#define SPC5_HAS_FMPLL1                     FALSE
#define SPC5_HAS_CLOCKOUT                   TRUE
#define SPC5_HAS_AC0                        FALSE
#define SPC5_HAS_AC1                        FALSE
#define SPC5_HAS_AC2                        FALSE
#define SPC5_HAS_AC3                        FALSE
#define SPC5_HAS_CMU0                       TRUE
#define SPC5_HAS_CMU1                       FALSE

#elif defined(_SPC560PXX_MEDIUM_)
#define SPC5_HAS_FMPLL1                     TRUE
#define SPC5_HAS_CLOCKOUT                   TRUE
#define SPC5_HAS_AC0                        TRUE
#define SPC5_HAS_AC1                        TRUE
#define SPC5_HAS_AC2                        TRUE
#define SPC5_HAS_AC3                        TRUE
#define SPC5_HAS_CMU0                       TRUE
#define SPC5_HAS_CMU1                       TRUE

#else /* defined(_SPC560PXX_LARGE_) */
#define SPC5_HAS_FMPLL1                     FALSE
#define SPC5_HAS_CLOCKOUT                   TRUE
#define SPC5_HAS_AC0                        FALSE
#define SPC5_HAS_AC1                        FALSE
#define SPC5_HAS_AC2                        FALSE
#define SPC5_HAS_AC3                        TRUE
#define SPC5_HAS_CMU0                       TRUE
#define SPC5_HAS_CMU1                       TRUE
#endif

/* DSPI attributes.*/
#define SPC5_HAS_DSPI0                      TRUE
#define SPC5_DSPI0_BASE                     0xFFF90000UL
#define SPC5_HAS_DSPI1                      TRUE
#define SPC5_DSPI1_BASE                     0xFFF94000UL
#if !defined(_SPC560P34_)
#define SPC5_HAS_DSPI2                      TRUE
#define SPC5_DSPI2_BASE                     0xFFF98000UL
#else
#define SPC5_HAS_DSPI2                      FALSE
#endif
#define SPC5_DSPI_FIFO_DEPTH                5U
#define SPC5_DSPI0_PCTL                     4
#define SPC5_DSPI1_PCTL                     5
#define SPC5_DSPI2_PCTL                     6
#define SPC5_DSPI0_TX1_DMA_DEV_ID           1
#define SPC5_DSPI0_TX2_DMA_DEV_ID           0
#define SPC5_DSPI0_RX_DMA_DEV_ID            2
#define SPC5_DSPI1_TX1_DMA_DEV_ID           3
#define SPC5_DSPI1_TX2_DMA_DEV_ID           0
#define SPC5_DSPI1_RX_DMA_DEV_ID            4
#define SPC5_DSPI2_TX1_DMA_DEV_ID           5
#define SPC5_DSPI2_TX2_DMA_DEV_ID           0
#define SPC5_DSPI2_RX_DMA_DEV_ID            6
#define SPC5_DSPI0_EOQF_HANDLER             vector75
#define SPC5_DSPI0_EOQF_NUMBER              75
#define SPC5_DSPI0_TFFF_HANDLER             vector76
#define SPC5_DSPI0_TFFF_NUMBER              76
#define SPC5_DSPI0_RFDF_HANDLER             vector78
#define SPC5_DSPI0_RFDF_NUMBER              78
#define SPC5_DSPI1_EOQF_HANDLER             vector95
#define SPC5_DSPI1_EOQF_NUMBER              95
#define SPC5_DSPI1_TFFF_HANDLER             vector96
#define SPC5_DSPI1_TFFF_NUMBER              96
#define SPC5_DSPI1_RFDF_HANDLER             vector98
#define SPC5_DSPI1_RFDF_NUMBER              98
#define SPC5_DSPI2_EOQF_HANDLER             vector115
#define SPC5_DSPI2_EOQF_NUMBER              115
#define SPC5_DSPI2_TFFF_HANDLER             vector116
#define SPC5_DSPI2_TFFF_NUMBER              116
#define SPC5_DSPI2_RFDF_HANDLER             vector118
#define SPC5_DSPI2_RFDF_NUMBER              118
#define SPC5_DSPI0_ENABLE_CLOCK()                                           \
  SPCSetPeripheralClockMode(SPC5_DSPI0_PCTL, SPC5_SPI_DSPI0_START_PCTL)
#define SPC5_DSPI0_DISABLE_CLOCK()                                          \
  SPCSetPeripheralClockMode(SPC5_DSPI0_PCTL, SPC5_SPI_DSPI0_STOP_PCTL)
#define SPC5_DSPI1_ENABLE_CLOCK()                                           \
  SPCSetPeripheralClockMode(SPC5_DSPI1_PCTL, SPC5_SPI_DSPI1_START_PCTL)
#define SPC5_DSPI1_DISABLE_CLOCK()                                          \
  SPCSetPeripheralClockMode(SPC5_DSPI1_PCTL, SPC5_SPI_DSPI1_STOP_PCTL)
#define SPC5_DSPI2_ENABLE_CLOCK()                                           \
  SPCSetPeripheralClockMode(SPC5_DSPI2_PCTL, SPC5_SPI_DSPI2_START_PCTL)
#define SPC5_DSPI2_DISABLE_CLOCK()                                          \
  SPCSetPeripheralClockMode(SPC5_DSPI2_PCTL, SPC5_SPI_DSPI2_STOP_PCTL)

#if defined(_SPC560PXX_MEDIUM_) || defined(_SPC560PXX_LARGE_)
#define SPC5_HAS_DSPI3                      TRUE
#define SPC5_DSPI3_BASE                     0xFFF9C000UL
#define SPC5_DSPI3_PCTL                     7
#define SPC5_DSPI3_TX1_DMA_DEV_ID           7
#define SPC5_DSPI3_TX2_DMA_DEV_ID           0
#define SPC5_DSPI3_RX_DMA_DEV_ID            8
#define SPC5_DSPI3_EOQF_HANDLER             vector218
#define SPC5_DSPI3_EOQF_NUMBER              218
#define SPC5_DSPI3_TFFF_HANDLER             vector219
#define SPC5_DSPI3_TFFF_NUMBER              219
#define SPC5_DSPI3_RFDF_HANDLER             vector221
#define SPC5_DSPI3_RFDF_NUMBER              221
#define SPC5_DSPI3_ENABLE_CLOCK()                                           \
  SPCSetPeripheralClockMode(SPC5_DSPI3_PCTL, SPC5_SPI_DSPI3_START_PCTL)
#define SPC5_DSPI3_DISABLE_CLOCK()                                          \
  SPCSetPeripheralClockMode(SPC5_DSPI3_PCTL, SPC5_SPI_DSPI3_STOP_PCTL)
#else
#define SPC5_HAS_DSPI3                      FALSE
#endif

#if defined(_SPC560PXX_LARGE_)
#define SPC5_HAS_DSPI4                      TRUE
#define SPC5_DSPI4_BASE                     0x8FFA0000UL
#define SPC5_DSPI4_PCTL                     8
#define SPC5_DSPI4_TX1_DMA_DEV_ID           15
#define SPC5_DSPI4_TX2_DMA_DEV_ID           0
#define SPC5_DSPI4_RX_DMA_DEV_ID            21
#define SPC5_DSPI4_EOQF_HANDLER             vector257
#define SPC5_DSPI4_EOQF_NUMBER              257
#define SPC5_DSPI4_TFFF_HANDLER             vector258
#define SPC5_DSPI4_TFFF_NUMBER              258
#define SPC5_DSPI4_RFDF_HANDLER             vector260
#define SPC5_DSPI4_RFDF_NUMBER              260
#define SPC5_DSPI4_ENABLE_CLOCK()                                           \
  SPCSetPeripheralClockMode(SPC5_DSPI4_PCTL, SPC5_SPI_DSPI4_START_PCTL)
#define SPC5_DSPI4_DISABLE_CLOCK()                                          \
  SPCSetPeripheralClockMode(SPC5_DSPI0_PCTL, SPC5_SPI_DSPI4_STOP_PCTL)
#else
#define SPC5_HAS_DSPI4                      FALSE
#endif

#define SPC5_HAS_DSPI5                      FALSE
#define SPC5_HAS_DSPI6                      FALSE
#define SPC5_HAS_DSPI7                      FALSE
#define SPC5_HAS_DSPI8                      FALSE
#define SPC5_HAS_DSPI9                      FALSE

/* eDMA attributes.*/
#define SPC5_HAS_EDMA                       TRUE
#define SPC5_EDMA_BASE                      0xFFF44000UL
#define SPC5_EDMA_NCHANNELS                 16U
#define SPC5_EDMA_ERR_FLAG_31_0_HANDLER     vector10
#define SPC5_EDMA_CH0_HANDLER               vector11
#define SPC5_EDMA_CH1_HANDLER               vector12
#define SPC5_EDMA_CH2_HANDLER               vector13
#define SPC5_EDMA_CH3_HANDLER               vector14
#define SPC5_EDMA_CH4_HANDLER               vector15
#define SPC5_EDMA_CH5_HANDLER               vector16
#define SPC5_EDMA_CH6_HANDLER               vector17
#define SPC5_EDMA_CH7_HANDLER               vector18
#define SPC5_EDMA_CH8_HANDLER               vector19
#define SPC5_EDMA_CH9_HANDLER               vector20
#define SPC5_EDMA_CH10_HANDLER              vector21
#define SPC5_EDMA_CH11_HANDLER              vector22
#define SPC5_EDMA_CH12_HANDLER              vector23
#define SPC5_EDMA_CH13_HANDLER              vector24
#define SPC5_EDMA_CH14_HANDLER              vector25
#define SPC5_EDMA_CH15_HANDLER              vector26
#define SPC5_EDMA_ERR_FLAG_31_0_NUMBER      10U
#define SPC5_EDMA_CH0_NUMBER                11U
#define SPC5_EDMA_HAS_MUX                   TRUE
#define SPC5_EDMA_DMAMUX_BASE               0xFFFDC000UL
#define SPC5_EDMA_NUM_OF_MUX                1U

/* LINFlex attributes.*/
#define SPC5_HAS_LINFLEX0                   TRUE
#define SPC5_LINFLEX0_BASE                  0xFFE40000UL
#define SPC5_LINFLEX0L_BASE                 0xFFE40000UL
#define SPC5_LINFLEX0H_BASE                 0xFFE4008CUL
#define SPC5_LINFLEX0_PCTL                  48
#define SPC5_LINFLEX0_RXI_HANDLER           vector79
#define SPC5_LINFLEX0_TXI_HANDLER           vector80
#define SPC5_LINFLEX0_ERR_HANDLER           vector81
#define SPC5_LINFLEX0_RXI_NUMBER            79
#define SPC5_LINFLEX0_TXI_NUMBER            80
#define SPC5_LINFLEX0_ERR_NUMBER            81
#define SPC5_LINFLEX0_DMA_SUPPORTED         FALSE
#define SPC5_LINFLEX0_CLK                   (SPCGetSystemClock() / 1U)

#define SPC5_HAS_LINFLEX1                   TRUE
#define SPC5_LINFLEX1_BASE                  0xFFE44000UL
#define SPC5_LINFLEX1L_BASE                 0xFFE44000UL
#define SPC5_LINFLEX1H_BASE                 0xFFE4408CUL
#define SPC5_LINFLEX1_PCTL                  49
#define SPC5_LINFLEX1_RXI_HANDLER           vector99
#define SPC5_LINFLEX1_TXI_HANDLER           vector100
#define SPC5_LINFLEX1_ERR_HANDLER           vector101
#define SPC5_LINFLEX1_RXI_NUMBER            99
#define SPC5_LINFLEX1_TXI_NUMBER            100
#define SPC5_LINFLEX1_ERR_NUMBER            101
#define SPC5_LINFLEX1_DMA_SUPPORTED         FALSE
#define SPC5_LINFLEX1_CLK                   (SPCGetSystemClock() / 1U)

#define SPC5_HAS_LINFLEX2                   FALSE
#define SPC5_HAS_LINFLEX3                   FALSE
#define SPC5_HAS_LINFLEX4                   FALSE
#define SPC5_HAS_LINFLEX5                   FALSE
#define SPC5_HAS_LINFLEX6                   FALSE
#define SPC5_HAS_LINFLEX7                   FALSE
#define SPC5_HAS_LINFLEX8                   FALSE
#define SPC5_HAS_LINFLEX9                   FALSE
#define SPC5_HAS_LINFLEX10                  FALSE
#define SPC5_HAS_LINFLEX11                  FALSE
#define SPC5_HAS_LINFLEX12                  FALSE
#define SPC5_HAS_LINFLEX13                  FALSE
#define SPC5_HAS_LINFLEX14                  FALSE
#define SPC5_HAS_LINFLEX15                  FALSE
#define SPC5_HAS_LINFLEX16                  FALSE
#define SPC5_HAS_LINFLEX17                  FALSE
#define SPC5_HAS_LINFLEX18                  FALSE
#define SPC5_HAS_LINFLEX19                  FALSE
#define SPC5_HAS_LINFLEX20                  FALSE
#define SPC5_HAS_LINFLEX21                  FALSE
#define SPC5_HAS_LINFLEX22                  FALSE
#define SPC5_HAS_LINFLEX23                  FALSE

/* SIUL attributes.*/
#define SPC5_HAS_SIUL                       TRUE
#define SPC5_HAS_SIUL_PARALLEL_PORT_REG     TRUE
#define SPC5_SIUL_NUM_PORTS                 8
#if defined(_SPC560PXX_SMALL_)
#define SPC5_SIUL_NUM_PCRS                  72U
#else
#define SPC5_SIUL_NUM_PCRS                  108U
#endif
#define SPC5_SIUL_NUM_PADSELS               36U

/* EIRQ */
#define SPC5_SIUL_EIRQ_HAS_0_7_HANDLER      TRUE
#define SPC5_SIUL_EIRQ_HAS_8_15_HANDLER     TRUE
#define SPC5_SIUL_EIRQ_HAS_16_23_HANDLER    TRUE
#define SPC5_SIUL_EIRQ_HAS_24_31_HANDLER    TRUE
#define SPC5_SIUL_EIRQ_0_7_HANDLER          vector41
#define SPC5_SIUL_EIRQ_8_15_HANDLER         vector42
#define SPC5_SIUL_EIRQ_16_23_HANDLER        vector43
#define SPC5_SIUL_EIRQ_24_31_HANDLER        vector44
#define SPC5_SIUL_EIRQ_0_7_INT_NUMBER       41
#define SPC5_SIUL_EIRQ_8_15_INT_NUMBER      42
#define SPC5_SIUL_EIRQ_16_23_INT_NUMBER     43
#define SPC5_SIUL_EIRQ_24_31_INT_NUMBER     44

/* FlexPWM attributes.*/
#if defined(_SPC560PXX_SMALL_) || defined(_SPC560PXX_MEDIUM_)
#define SPC5_HAS_FLEXPWM0                   TRUE
#define SPC5_FLEXPWM0_BASE                  0xFFE24000UL
#define SPC5_FLEXPWM0_PCTL                  41
#define SPC5_FLEXPWM0_RF0_HANDLER           vector179
#define SPC5_FLEXPWM0_COF0_HANDLER          vector180
#define SPC5_FLEXPWM0_CAF0_HANDLER          vector181
#define SPC5_FLEXPWM0_RF1_HANDLER           vector182
#define SPC5_FLEXPWM0_COF1_HANDLER          vector183
#define SPC5_FLEXPWM0_CAF1_HANDLER          vector184
#define SPC5_FLEXPWM0_RF2_HANDLER           vector185
#define SPC5_FLEXPWM0_COF2_HANDLER          vector186
#define SPC5_FLEXPWM0_CAF2_HANDLER          vector187
#define SPC5_FLEXPWM0_RF3_HANDLER           vector188
#define SPC5_FLEXPWM0_COF3_HANDLER          vector189
#define SPC5_FLEXPWM0_CAF3_HANDLER          vector190
#define SPC5_FLEXPWM0_FFLAG_HANDLER         vector191
#define SPC5_FLEXPWM0_REF_HANDLER           vector192
#define SPC5_FLEXPWM0_RF0_NUMBER            179
#define SPC5_FLEXPWM0_COF0_NUMBER           180
#define SPC5_FLEXPWM0_CAF0_NUMBER           181
#define SPC5_FLEXPWM0_RF1_NUMBER            182
#define SPC5_FLEXPWM0_COF1_NUMBER           183
#define SPC5_FLEXPWM0_CAF1_NUMBER           184
#define SPC5_FLEXPWM0_RF2_NUMBER            185
#define SPC5_FLEXPWM0_COF2_NUMBER           186
#define SPC5_FLEXPWM0_CAF2_NUMBER           187
#define SPC5_FLEXPWM0_RF3_NUMBER            188
#define SPC5_FLEXPWM0_COF3_NUMBER           189
#define SPC5_FLEXPWM0_CAF3_NUMBER           190
#define SPC5_FLEXPWM0_FFLAG_NUMBER          191
#define SPC5_FLEXPWM0_REF_NUMBER            192
#define SPC5_FLEXPWM0_CLK                   SPC5_MCONTROL_CLK
#else /* defined(_SPC560PXX_LARGE_) */
#define SPC5_HAS_FLEXPWM0                   FALSE
#endif /* defined(_SPC560PXX_LARGE_) */

#define SPC5_HAS_FLEXPWM1                   FALSE
#define SPC5_HAS_FLEXPWM2                   FALSE

/* eTimer attributes.*/
#define SPC5_HAS_ETIMER0                    TRUE
#define SPC5_ETIMER0_BASE                   0xFFE18000UL
#define SPC5_ETIMER0_PCTL                   38
#define SPC5_ETIMER0_TC0IR_HANDLER          vector157
#define SPC5_ETIMER0_TC1IR_HANDLER          vector158
#define SPC5_ETIMER0_TC2IR_HANDLER          vector159
#define SPC5_ETIMER0_TC3IR_HANDLER          vector160
#define SPC5_ETIMER0_TC4IR_HANDLER          vector161
#define SPC5_ETIMER0_TC5IR_HANDLER          vector162
#define SPC5_ETIMER0_WTIF_HANDLER           vector165
#define SPC5_ETIMER0_RCF_HANDLER            vector167
#define SPC5_ETIMER0_TC0IR_NUMBER           157
#define SPC5_ETIMER0_TC1IR_NUMBER           158
#define SPC5_ETIMER0_TC2IR_NUMBER           159
#define SPC5_ETIMER0_TC3IR_NUMBER           160
#define SPC5_ETIMER0_TC4IR_NUMBER           161
#define SPC5_ETIMER0_TC5IR_NUMBER           162
#define SPC5_ETIMER0_WTIF_NUMBER            165
#define SPC5_ETIMER0_RCF_NUMBER             167
#define SPC5_ETIMER0_CLK                    SPC5_MCONTROL_CLK

#if defined(_SPC560PXX_MEDIUM_) || defined(_SPC560PXX_LARGE_)
#define SPC5_HAS_ETIMER1                    TRUE
#define SPC5_ETIMER1_BASE                   0xFFE1C000UL
#define SPC5_ETIMER1_PCTL                   39
#define SPC5_ETIMER1_TC0IR_HANDLER          vector168
#define SPC5_ETIMER1_TC1IR_HANDLER          vector169
#define SPC5_ETIMER1_TC2IR_HANDLER          vector170
#define SPC5_ETIMER1_TC3IR_HANDLER          vector171
#define SPC5_ETIMER1_TC4IR_HANDLER          vector172
#define SPC5_ETIMER1_TC5IR_HANDLER          vector173
#define SPC5_ETIMER1_RCF_HANDLER            vector178
#define SPC5_ETIMER1_TC0IR_NUMBER           168
#define SPC5_ETIMER1_TC1IR_NUMBER           169
#define SPC5_ETIMER1_TC2IR_NUMBER           170
#define SPC5_ETIMER1_TC3IR_NUMBER           171
#define SPC5_ETIMER1_TC4IR_NUMBER           172
#define SPC5_ETIMER1_TC5IR_NUMBER           173
#define SPC5_ETIMER1_RCF_NUMBER             178
#define SPC5_ETIMER1_CLK                    SPC5_MCONTROL_CLK

#else /* !(defined(_SPC560PXX_MEDIUM_) || defined(_SPC560PXX_LARGE_)) */
#define SPC5_HAS_ETIMER1                    FALSE
#endif /* !(defined(_SPC560PXX_MEDIUM_) || defined(_SPC560PXX_LARGE_)) */

#define SPC5_HAS_ETIMER2                    FALSE
#define SPC5_HAS_ETIMER3                    FALSE

/* FlexCAN attributes.*/
#define SPC5_HAS_FLEXCAN0                   TRUE
#define SPC5_FLEXCAN0_BASE                  0xFFFC0000UL
#define SPC5_FLEXCAN0_PCTL                  16
#define SPC5_FLEXCAN0_MB                    32U
#define SPC5_FLEXCAN0_SHARED_IRQ            TRUE
#define SPC5_FLEXCAN0_ESR_ERR_INT_HANDLER   vector65
#define SPC5_FLEXCAN0_ESR_BOFF_HANDLER      vector66
#define SPC5_FLEXCAN0_ESR_WAK_HANDLER       vector67
#define SPC5_FLEXCAN0_BUF_00_03_HANDLER     vector68
#define SPC5_FLEXCAN0_BUF_04_07_HANDLER     vector69
#define SPC5_FLEXCAN0_BUF_08_11_HANDLER     vector70
#define SPC5_FLEXCAN0_BUF_12_15_HANDLER     vector71
#define SPC5_FLEXCAN0_BUF_16_31_HANDLER     vector72
#define SPC5_FLEXCAN0_ESR_ERR_INT_NUMBER    65
#define SPC5_FLEXCAN0_ESR_BOFF_NUMBER       66
#define SPC5_FLEXCAN0_ESR_WAK_NUMBER        67
#define SPC5_FLEXCAN0_BUF_00_03_NUMBER      68
#define SPC5_FLEXCAN0_BUF_04_07_NUMBER      69
#define SPC5_FLEXCAN0_BUF_08_11_NUMBER      70
#define SPC5_FLEXCAN0_BUF_12_15_NUMBER      71
#define SPC5_FLEXCAN0_BUF_16_31_NUMBER      72
#define SPC5_FLEXCAN0_ENABLE_CLOCK()                                        \
  SPCSetPeripheralClockMode(SPC5_FLEXCAN0_PCTL, SPC5_CAN_FLEXCAN0_START_PCTL)
#define SPC5_FLEXCAN0_DISABLE_CLOCK()                                       \
  SPCSetPeripheralClockMode(SPC5_FLEXCAN0_PCTL, SPC5_CAN_FLEXCAN0_STOP_PCTL)

#if (defined (_SPC560PXX_SMALL_) && !defined (_SPC560P34_)) || defined (_SPC560PXX_MEDIUM_)
#define SPC5_HAS_FLEXCAN1                   TRUE
#define SPC5_FLEXCAN1_BASE                  0xFFFE8000UL
#define SPC5_FLEXCAN1_PCTL                  26
#define SPC5_FLEXCAN1_MB                    32U
#define SPC5_FLEXCAN1_SHARED_IRQ            TRUE
#define SPC5_FLEXCAN1_ESR_ERR_INT_HANDLER   vector208
#define SPC5_FLEXCAN1_ESR_BOFF_HANDLER      vector209
#define SPC5_FLEXCAN1_ESR_WAK_HANDLER       vector210
#define SPC5_FLEXCAN1_BUF_00_03_HANDLER     vector211
#define SPC5_FLEXCAN1_BUF_04_07_HANDLER     vector212
#define SPC5_FLEXCAN1_BUF_08_11_HANDLER     vector213
#define SPC5_FLEXCAN1_BUF_12_15_HANDLER     vector214
#define SPC5_FLEXCAN1_BUF_16_31_HANDLER     vector215
#define SPC5_FLEXCAN1_ESR_ERR_INT_NUMBER    208
#define SPC5_FLEXCAN1_ESR_BOFF_NUMBER       209
#define SPC5_FLEXCAN1_ESR_WAK_NUMBER        210
#define SPC5_FLEXCAN1_BUF_00_03_NUMBER      211
#define SPC5_FLEXCAN1_BUF_04_07_NUMBER      212
#define SPC5_FLEXCAN1_BUF_08_11_NUMBER      213
#define SPC5_FLEXCAN1_BUF_12_15_NUMBER      214
#define SPC5_FLEXCAN1_BUF_16_31_NUMBER      215
#define SPC5_FLEXCAN1_ENABLE_CLOCK()                                        \
  SPCSetPeripheralClockMode(SPC5_FLEXCAN1_PCTL, SPC5_CAN_FLEXCAN1_START_PCTL)
#define SPC5_FLEXCAN1_DISABLE_CLOCK()                                       \
  SPCSetPeripheralClockMode(SPC5_FLEXCAN1_PCTL, SPC5_CAN_FLEXCAN1_STOP_PCTL)
#else
#define SPC5_HAS_FLEXCAN1                   FALSE
#endif
#define SPC5_HAS_FLEXCAN2                   FALSE
#define SPC5_HAS_FLEXCAN3                   FALSE
#define SPC5_HAS_FLEXCAN4                   FALSE
#define SPC5_HAS_FLEXCAN5                   FALSE

/* ADC attributes.*/
#define SPC5_ADC_HAS_TRC                    TRUE

#define SPC5_HAS_ADC0                       TRUE
#define SPC5_ADC_ADC0_BASE                  0xFFE00000UL
#define SPC5_ADC_ADC0_HAS_CTR0              TRUE
#define SPC5_ADC_ADC0_HAS_CTR1              FALSE
#define SPC5_ADC_ADC0_HAS_CTR2              FALSE
#define SPC5_ADC_ADC0_HAS_NCMR0             TRUE
#define SPC5_ADC_ADC0_HAS_NCMR1             FALSE
#define SPC5_ADC_ADC0_HAS_NCMR2             FALSE
#define SPC5_ADC_ADC0_HAS_THRHLR0           TRUE
#define SPC5_ADC_ADC0_HAS_THRHLR1           TRUE
#define SPC5_ADC_ADC0_HAS_THRHLR2           TRUE
#define SPC5_ADC_ADC0_HAS_THRHLR3           TRUE
#define SPC5_ADC_ADC0_HAS_CIMR0             FALSE
#define SPC5_ADC_ADC0_HAS_CIMR1             FALSE
#define SPC5_ADC_ADC0_HAS_CIMR2             FALSE
#define SPC5_ADC_ADC0_HAS_CEOCFR0           FALSE
#define SPC5_ADC_ADC0_HAS_CEOCFR1           FALSE
#define SPC5_ADC_ADC0_HAS_CEOCFR2           FALSE
#define SPC5_ADC0_PCTL                      32
#define SPC5_ADC0_DMA_DEV_ID                20
#define SPC5_ADC0_EOC_HANDLER               vector62
#define SPC5_ADC0_EOC_NUMBER                62
#define SPC5_ADC0_WD_HANDLER                vector64
#define SPC5_ADC0_WD_NUMBER                 64

#if defined(_SPC560PXX_MEDIUM_)
#define SPC5_HAS_ADC1                       TRUE
#define SPC5_ADC_ADC1_BASE                  0xFFE04000UL
#define SPC5_ADC_ADC1_HAS_CTR0              TRUE
#define SPC5_ADC_ADC1_HAS_CTR1              FALSE
#define SPC5_ADC_ADC1_HAS_CTR2              FALSE
#define SPC5_ADC_ADC1_HAS_NCMR0             TRUE
#define SPC5_ADC_ADC1_HAS_NCMR1             FALSE
#define SPC5_ADC_ADC1_HAS_NCMR2             FALSE
#define SPC5_ADC_ADC1_HAS_THRHLR0           TRUE
#define SPC5_ADC_ADC1_HAS_THRHLR1           TRUE
#define SPC5_ADC_ADC1_HAS_THRHLR2           TRUE
#define SPC5_ADC_ADC1_HAS_THRHLR3           TRUE
#define SPC5_ADC_ADC1_HAS_CIMR0             FALSE
#define SPC5_ADC_ADC1_HAS_CIMR1             FALSE
#define SPC5_ADC_ADC1_HAS_CIMR2             FALSE
#define SPC5_ADC_ADC1_HAS_CEOCFR0           FALSE
#define SPC5_ADC_ADC1_HAS_CEOCFR1           FALSE
#define SPC5_ADC_ADC1_HAS_CEOCFR2           FALSE
#define SPC5_ADC1_PCTL                      33
#define SPC5_ADC1_DMA_DEV_ID                21
#define SPC5_ADC1_EOC_HANDLER               vector82
#define SPC5_ADC1_EOC_NUMBER                82
#define SPC5_ADC1_WD_HANDLER                vector84
#define SPC5_ADC1_WD_NUMBER                 84
#else
#define SPC5_HAS_ADC1                       FALSE
#endif

/* CTU attributes.*/
#define SPC5_HAS_CTU0                       TRUE
#define SPC5_CTU0_BASE                      0xFFE0C000UL
#define SPC5_CTU0_PCTL                      35
#define SPC5_CT0_MRS_I_HANDLER              vector193
#define SPC5_CT0_T0_I_HANDLER               vector194
#define SPC5_CT0_T1_I_HANDLER               vector195
#define SPC5_CT0_T2_I_HANDLER               vector196
#define SPC5_CT0_T3_I_HANDLER               vector197
#define SPC5_CT0_T4_I_HANDLER               vector198
#define SPC5_CT0_T5_I_HANDLER               vector199
#define SPC5_CT0_T6_I_HANDLER               vector200
#define SPC5_CT0_T7_I_HANDLER               vector201
#define SPC5_CT0_FIFO1_I_HANDLER            vector202
#define SPC5_CT0_FIFO2_I_HANDLER            vector203
#define SPC5_CT0_FIFO3_I_HANDLER            vector204
#define SPC5_CT0_FIFO4_I_HANDLER            vector205
#define SPC5_CT0_ADC_I_HANDLER              vector206
#define SPC5_CT0_ERR_I_HANDLER              vector207
#define SPC5_CT0_MRS_I_NUMBER               193
#define SPC5_CT0_T0_I_NUMBER                194
#define SPC5_CT0_T1_I_NUMBER                195
#define SPC5_CT0_T2_I_NUMBER                196
#define SPC5_CT0_T3_I_NUMBER                197
#define SPC5_CT0_T4_I_NUMBER                198
#define SPC5_CT0_T5_I_NUMBER                199
#define SPC5_CT0_T6_I_NUMBER                200
#define SPC5_CT0_T7_I_NUMBER                201
#define SPC5_CT0_FIFO1_I_NUMBER             202
#define SPC5_CT0_FIFO2_I_NUMBER             203
#define SPC5_CT0_FIFO3_I_NUMBER             204
#define SPC5_CT0_FIFO4_I_NUMBER             205
#define SPC5_CT0_ADC_I_NUMBER               206
#define SPC5_CT0_ERR_I_NUMBER               207

#define SPC5_HAS_CTU1                       FALSE

/* PIT Attributes */
#define SPC5_HAS_PIT                        TRUE
#define SPC5_PIT_BASE                       0xC3FF0000UL
#define SPC5_PIT_CHANNELS                   4
#define SPC5_PIT_PCTL                       92
#define SPC5_PIT_ENABLE_CLOCK()             SPCSetPeripheralClockMode(SPC5_PIT_PCTL, SPC5_PIT_START_PCTL);
#define SPC5_PIT_DISABLE_CLOCK()            SPCSetPeripheralClockMode(SPC5_PIT_PCTL, SPC5_PIT_STOP_PCTL);
#define SPC5_HAS_PIT_CH0                    TRUE
#define SPC5_HAS_PIT_CH1                    TRUE
#define SPC5_HAS_PIT_CH2                    TRUE
#define SPC5_HAS_PIT_CH3                    TRUE
#define SPC5_HAS_PIT_CH4                    FALSE
#define SPC5_HAS_PIT_CH5                    FALSE
#define SPC5_HAS_PIT_CH6                    FALSE
#define SPC5_HAS_PIT_CH7                    FALSE
#define SPC_PIT_CH0_HANDLER                 vector59
#define SPC_PIT_CH1_HANDLER                 vector60
#define SPC_PIT_CH2_HANDLER                 vector61
#define SPC_PIT_CH3_HANDLER                 vector127
#define SPC_PIT_CH0_INT_NUMBER              59
#define SPC_PIT_CH1_INT_NUMBER              60
#define SPC_PIT_CH2_INT_NUMBER              61
#define SPC_PIT_CH3_INT_NUMBER              127

/* STM Attributes */
#define SPC5_HAS_STM0                       TRUE
#define SPC5_HAS_STM1                       FALSE
#define SPC5_HAS_STM2                       FALSE
#define SPC5_STM0_BASE                      0xFFF3C000UL
#define SPC5_STM0_CHANNELS                  4
#define SPC5_HAS_STM0_CH0                   TRUE
#define SPC5_HAS_STM0_CH1                   TRUE
#define SPC5_HAS_STM0_CH2                   TRUE
#define SPC5_HAS_STM0_CH3                   TRUE
#define SPC5_STM0_CH1_CH3_SHARED_INT        FALSE
#define SPC5_STM0_CH0_HANDLER               vector30
#define SPC5_STM0_CH1_HANDLER               vector31
#define SPC5_STM0_CH2_HANDLER               vector32
#define SPC5_STM0_CH3_HANDLER               vector33
#define SPC5_STM0_CH0_INT_NUMBER            30
#define SPC5_STM0_CH1_INT_NUMBER            31
#define SPC5_STM0_CH2_INT_NUMBER            32
#define SPC5_STM0_CH3_INT_NUMBER            33

/* SWT Attributes */
#define SPC5_HAS_SWT0                       TRUE
#define SPC5_SWT0_BASE                      0xFFF38000UL
#define SPC5_SWT0_HANDLER                   vector28
#define SPC5_SWT0_INT_NUMBER                28

#define SPC5_HAS_SWT1                       FALSE
#define SPC5_HAS_SWT2                       FALSE
#define SPC5_HAS_SWT3                       FALSE

/** @} */

#endif /* _SPC560P_REGISTRY_H_ */

/** @} */
