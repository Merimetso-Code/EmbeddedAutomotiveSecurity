/****************************************************************************
*
* Copyright © 2015-2019 STMicroelectronics - All Rights Reserved
*
* This software is licensed under SLA0098 terms that can be found in the
* DM00779817_1_0.pdf file in the licenses directory of this software product.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
*****************************************************************************/

#ifndef _BOARD_H_
#define _BOARD_H_

#include "pal.h"

/*
 * Setup for a generic SPC560Pxx board.
 */

/*
 * Board identifiers.
 */
#define BOARD_SPC56P_DISCOVERY
#define BOARD_NAME                  "STMicroelectronics SPC560P Discovery"

/*
 * PIN definitions.
 */
#define PA_LED11                    0U
#define PA_LED12                    1U
#define PG_LED13                    4U
#define PIN_LIN0TXD                 2U
#define PIN_LIN0RXD                 3U
#define PIN_LIN1TXD                 14U
#define PIN_LIN1RXD                 15U

/*
 * PORT definitions.
 */
#define PORT_PA_LED11               PORT_A
#define PORT_PA_LED12               PORT_A
#define PORT_PG_LED13               PORT_G
#define PORT_PIN_LIN0TXD            PORT_B
#define PORT_PIN_LIN0RXD            PORT_B
#define PORT_PIN_LIN1TXD            PORT_F
#define PORT_PIN_LIN1RXD            PORT_F

/*
 * Support macros.
 */
#define PCR_INDEX(port, pin)  (((port) * 16U) + (pin))

#if !defined(_FROM_ASM_)
#ifdef __cplusplus
extern "C" {
#endif
  void boardInit(void);
#ifdef __cplusplus
}
#endif
#endif /* _FROM_ASM_ */

#endif /* _BOARD_H_ */
