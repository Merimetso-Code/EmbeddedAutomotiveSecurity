/****************************************************************************
*
* Copyright © 2018-2019 STMicroelectronics - All Rights Reserved
*
* This software is licensed under SLA0098 terms that can be found in the
* DM00779817_1_0.pdf file in the licenses directory of this software product.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED,
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
*****************************************************************************/
/**
 * @file    lin_lld_cfg.c
 * @brief   LIN Driver configuration code.
 *
 * @addtogroup LIN
 * @{
 */

#include <lin_lld.h>

#if (LLD_USE_LIN == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/**
 * @brief   Structures defining the filters configuration for lin_filter_37_4_Transmit.
 */
static LinFilter Filter_37_4_Transmit_List = {
  37,
  4,
  LIN_DIRECTION_TRANSMIT,
  LIN_ENHANCED_CHECKSUM,
  LIN_LIST_MODE,
  0
};
/**
 * @brief   Structures defining the filters configuration for lin_filter_38_4_Receive.
 */
static LinFilter Filter_38_4_Receive_List = {
  38,
  4,
  LIN_DIRECTION_RECEIVE,
  LIN_ENHANCED_CHECKSUM,
  LIN_LIST_MODE,
  0
};
/**
 * @brief   Structures defining the filters configuration for lin_filter_45_8_Transmit.
 */
static LinFilter Filter_45_8_Transmit_List = {
  45,
  8,
  LIN_DIRECTION_TRANSMIT,
  LIN_ENHANCED_CHECKSUM,
  LIN_LIST_MODE,
  0
};
/**
 * @brief   Structures defining the filters configuration for lin_filter_46_8_Receive.
 */
static LinFilter Filter_46_8_Receive_List = {
  46,
  8,
  LIN_DIRECTION_RECEIVE,
  LIN_ENHANCED_CHECKSUM,
  LIN_LIST_MODE,
  0
};


/**
 * @brief   Structure defining the LIN configuration "lin_master".
 */
const LinConfig lin_config_lin_master = {
  20000,
  LIN_MODE_MASTER,
  SPC5_LIN_API_MODE_SYNCHRONOUS,
  master_tx_callback,
  master_rx_callback,
  NULL,
  0,
  FALSE,
  NULL
};

static LinFilter *lin_Filters_lin_slave[] = {
          &Filter_37_4_Transmit_List,
          &Filter_38_4_Receive_List,
          &Filter_45_8_Transmit_List,
          &Filter_46_8_Receive_List,
          NULL,
          NULL,
          NULL,
          NULL,
          NULL,
          NULL,
          NULL,
          NULL,
          NULL,
          NULL,
          NULL,
          NULL
};
/**
 * @brief   Structure defining the LIN configuration "lin_slave".
 */
const LinConfig lin_config_lin_slave = {
  20000,
  LIN_MODE_SLAVE,
  SPC5_LIN_API_MODE_SYNCHRONOUS,
  slave_tx_callback,
  slave_rx_callback,
  lin_Filters_lin_slave,
  0,
  FALSE,
  NULL
};

/*===========================================================================*/
/* Driver local types.                                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

#endif /* LLD_USE_LIN */

/** @} */
