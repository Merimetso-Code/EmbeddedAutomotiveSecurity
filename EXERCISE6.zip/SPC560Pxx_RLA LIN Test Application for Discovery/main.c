/****************************************************************************
*
* Copyright © 2017-2019 STMicroelectronics - All Rights Reserved
*
* This software is licensed under SLA0098 terms that can be found in the
* DM00779817_1_0.pdf file in the licenses directory of this software product.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
*****************************************************************************/

/* Inclusion of the main header files of all the imported components in the
   order specified in the application wizard. The file is generated
   automatically.*/
#include "components.h"

#define LIN_MASTER    LD2
#define LIN_SLAVE     LD1

/*
 * Used by master to read 4 bytes from slave.
 *
 * Filter is set in slave node, so for this message
 * direction is Transmit (from a slave point of view).
 */
#define LIN_MSG_1      37
#define LIN_MSG_1_SIZE  4

/*
 * Used by master to send 4 bytes to slave.
 *
 * Filter is set in slave node, so for this message
 * direction is Receive (from a slave point of view).
 */
#define LIN_MSG_2      38
#define LIN_MSG_2_SIZE  4

/*
 * Used by master to read 8 bytes from slave.
 *
 * Filter is set in slave node, so for this message
 * direction is Transmit (from a slave point of view).
 */
#define LIN_MSG_3      45
#define LIN_MSG_3_SIZE  8

/*
 * Used by master to send 8 bytes to slave.
 *
 * Filter is set in slave node, so for this message
 * direction is Receive (from a slave point of view).
 */
#define LIN_MSG_4      46
#define LIN_MSG_4_SIZE  8


#define TOGGLE_LED_TX()   pal_lld_togglepad(PORT_A, PA_LED11)
#define TOGGLE_LED_RX()   pal_lld_togglepad(PORT_A, PA_LED12)
#define TOGGLE_LED_ERR()  pal_lld_togglepad(PORT_G, PG_LED13)

uint32_t master_tx_callback(LinDriver *ldp, uint8_t idMessage, uint8_t *buffer, uint16_t len) {
  (void)ldp;
  (void)idMessage;
  (void)buffer;
  (void) len;

  TOGGLE_LED_TX();
  return 0;
}

uint32_t master_rx_callback(LinDriver *ldp, uint8_t idMessage, uint8_t *buffer, uint16_t len) {
  (void)ldp;
  uint8_t i = 0;
  uint32_t ret;

  /*
   * Check the master receives the correct data.
   */
  switch (idMessage) {
  case LIN_MSG_1:
    while ((buffer[i] == (uint8_t)'A' + i) && (i < len)) {
      i++;
    }
    ret = len;
    break;
  case LIN_MSG_3:
    while ((buffer[i] == (uint8_t)'M' + i) && (i < len)) {
      i++;
    }
    ret = len;
    break;
  default:
    ret = 0;
    break;
  }

  if (i == len) {
    TOGGLE_LED_RX();
  } else {
    TOGGLE_LED_ERR();
  }

  return ret;
}

uint32_t slave_tx_callback(LinDriver *ldp, uint8_t idMessage, uint8_t *buffer, uint16_t len) {
  (void)ldp;
  uint8_t i;
  uint32_t ret;

  /* Fill in data buffer */
  switch (idMessage) {
  case LIN_MSG_1:
    for (i = 0; i < len; i++) {
      buffer[i] = (uint8_t)'A' + i;
    }
    ret = len;
    break;
  case LIN_MSG_3:
    for (i = 0; i < len; i++) {
      buffer[i] = (uint8_t)'M' + i;
    }
    ret = len;
    break;
  default:
    ret = 0;
    break;
  }

  TOGGLE_LED_TX();

  return ret;
}

uint32_t slave_rx_callback(LinDriver *ldp, uint8_t idMessage, uint8_t *buffer, uint16_t len) {
  (void)ldp;
  uint8_t i = 0;
  uint32_t ret;

  /*
   * Check the slave receives the correct data.
   */
  switch (idMessage) {
  case LIN_MSG_2:
    while ((buffer[i] == (uint8_t)'0' + i) && (i < len)) {
      i++;
    }
    ret = len;
    break;
  case LIN_MSG_4:
    while ((buffer[i] == (uint8_t)'a' + i) && (i < len)) {
      i++;
    }
    ret = len;
    break;
  default:
    ret = 0;
    break;
  }

  if (i == len) {
    TOGGLE_LED_RX();
  } else {
    TOGGLE_LED_ERR();
  }

  return ret;
}


/*
 * Application entry point.
 */
int main(void) {
  uint8_t tx_buffer[LIN_DATA_LEN];
  uint8_t rx_buffer[LIN_DATA_LEN];

  uint8_t i;

  /* Initialization of all the imported components in the order specified in
     the application wizard. The function is generated automatically.*/
  componentsInit();

  /* Enable Interrupts */
  irqIsrEnable();

  /* Start Lin Driver Slave Device. */
  lin_lld_start(&LIN_SLAVE, &lin_config_lin_slave);

  /* Start Lin Driver Master Device. */
  lin_lld_start(&LIN_MASTER, &lin_config_lin_master);

  /* Application main loop.*/
  for ( ; ; ) {

    /* Master asks for data associated to MSG #1 */
    (void)lin_lld_receive(&LIN_MASTER, LIN_MSG_1, rx_buffer, LIN_MSG_1_SIZE);

    osalThreadDelayMilliseconds(250);

    for (i = 0; i < LIN_DATA_LEN; i++) {
      tx_buffer[i] = (uint8_t)'0' + i;
    }

    /* Master sends data associated to MSG #2 */
    lin_lld_transmit(&LIN_MASTER, LIN_MSG_2, tx_buffer, LIN_MSG_2_SIZE);

    osalThreadDelayMilliseconds(250);

    /* Master asks for data associated to MSG #3 */
    (void)lin_lld_receive(&LIN_MASTER, LIN_MSG_3, rx_buffer, LIN_MSG_3_SIZE);

    osalThreadDelayMilliseconds(250);

    for (i = 0; i < LIN_DATA_LEN; i++) {
      tx_buffer[i] = (uint8_t)'a' + i;
    }

    /* Master sends data associated to MSG #4 */
    lin_lld_transmit(&LIN_MASTER, LIN_MSG_4, tx_buffer, LIN_MSG_4_SIZE);

    osalThreadDelayMilliseconds(250);

  }
}
