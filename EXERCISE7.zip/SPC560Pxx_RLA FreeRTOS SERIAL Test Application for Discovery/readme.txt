This application shows an example of a FreeRTOS application. There are two 
tasks toggling leds and sending a string to UART.

In order to receive from serial, please set the baud rate of the COM port on 
your PC to 38400.