/****************************************************************************
*
* Copyright © 2015-2019 STMicroelectronics - All Rights Reserved
*
* This software is licensed under SLA0098 terms that can be found in the
* DM00779817_1_0.pdf file in the licenses directory of this software product.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
*****************************************************************************/

#ifndef _BOARD_H_
#define _BOARD_H_

#include "pal.h"

/*
 * Setup for a generic SPC560Pxx board.
 */

/*
 * Board identifiers.
 */
#define BOARD_SPC56P_DISCOVERY
#define BOARD_NAME                  "STMicroelectronics SPC560P Discovery"

/*
 * PIN definitions.
 */
#define Led_D11                     0U
#define Led_D13                     4U
#define PIN_LIN0TXD                 2U
#define PIN_LIN0RXD                 3U

/*
 * PORT definitions.
 */
#define PORT_Led_D11                PORT_A
#define PORT_Led_D13                PORT_G
#define PORT_PIN_LIN0TXD            PORT_B
#define PORT_PIN_LIN0RXD            PORT_B

/*
 * Support macros.
 */
#define PCR_INDEX(port, pin)  (((port) * 16U) + (pin))

#if !defined(_FROM_ASM_)
#ifdef __cplusplus
extern "C" {
#endif
  void boardInit(void);
#ifdef __cplusplus
}
#endif
#endif /* _FROM_ASM_ */

#endif /* _BOARD_H_ */
