/****************************************************************************
*
* Copyright © 2015-2019 STMicroelectronics - All Rights Reserved
*
* This software is licensed under SLA0098 terms that can be found in the
* DM00779817_1_0.pdf file in the licenses directory of this software product.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED,
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
*****************************************************************************/
/**
 * @file    adc_lld_cfg.h
 * @brief   ADC Driver configuration macros and structures.
 *
 * @addtogroup ADC
 * @{
 */

#ifndef _ADC_LLD_CFG_H_
#define _ADC_LLD_CFG_H_

#include "spc5_lld.h"
#include "adc_lld.h"

#if (LLD_USE_ADC == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/**
 * @name    Conversion groups constants
 * @{
 */
#define ADC0_GROUP_GROUP_NAME_NUM_CHANNELS 1
#define ADC0_GROUP_GROUP_NAME_BUF_DEPTH    1
#define ADC1_GROUP_GROUP_NAME_NUM_CHANNELS 1
#define ADC1_GROUP_GROUP_NAME_BUF_DEPTH    1
/** @} */

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

/* List of the ADC0 ADCConversionGroup structures defined in adc_lld_cfg.c.*/
extern ADCConversionGroup adc0_group_group_name;

/* List of the ADC1 ADCConversionGroup structures defined in adc_lld_cfg.c.*/
extern ADCConversionGroup adc1_group_group_name;

#ifdef __cplusplus
extern "C" {
#endif
  /* List of the callback functions referenced from the ADC0 ADCConversionGroup
     structures in adc_lld_cfg.c.*/

  /* List of the callback functions referenced from the ADC1 ADCConversionGroup
     structures in adc_lld_cfg.c.*/
#ifdef __cplusplus
}
#endif

#endif /* LLD_USE_ADC */

#endif /* _ADC_LLD_CFG_H_ */

/** @} */
