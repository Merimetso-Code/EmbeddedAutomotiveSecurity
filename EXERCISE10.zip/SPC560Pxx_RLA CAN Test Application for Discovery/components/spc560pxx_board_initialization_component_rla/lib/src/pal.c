/****************************************************************************
*
* Copyright © 2015-2019 STMicroelectronics - All Rights Reserved
*
* This software is licensed under SLA0098 terms that can be found in the
* DM00779817_1_0.pdf file in the licenses directory of this software product.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
*****************************************************************************/
/**
 * @file    pal.c
 * @brief   SPC5xx SIUL low level driver code.
 *
 * @addtogroup PAL
 * @{
 */

#include "pal.h"

#if defined(SPC5_SIUL_SYSTEM_PINS)
static const unsigned system_pins[] = {SPC5_SIUL_SYSTEM_PINS};
#endif

/**
 * @brief   SPC5xx I/O ports configuration.
 *
 * @param[in] config    the SPC5xx ports configuration
 *
 * @notapi
 */
void pal_init(const PALConfig *config) {
  uint16_t i;

#if defined(SPC5_SIUL_PCTL)
  /* SIUL clock gating if present.*/
  SPCSetPeripheralClockMode(SPC5_SIUL_PCTL,
                            SPC5_ME_PCTL_RUN(2) | SPC5_ME_PCTL_LP(2));
#endif

  /* Initialize PCR registers for undefined pads.*/
  for (i = 0; i < SPC5_SIUL_NUM_PCRS; i++) {
#if defined(SPC5_SIUL_SYSTEM_PINS)
    /* Handling the case where some SIU pins are not meant to be reprogrammed,
       for example JTAG pins.*/
    uint16_t j;
    uint16_t pin_check = 0U;
    for (j = 0; j < (sizeof(system_pins)/sizeof(system_pins[0])); j++) {
      if (i == system_pins[j]){
        pin_check = 1U;
        break;
      }
    }
    if (pin_check == 0U) {
      SIU.PCR[i].R = config->default_mode;
    }
#else
    SIU.PCR[i].R = config->default_mode;
#endif
  }

  /* Initialize PADSEL registers.*/
  for (i = 0; i < SPC5_SIUL_NUM_PADSELS; i++){
    SIU.PSMI[i].R = config->padsels[i];
  }

  /* Initialize PCR registers for defined pads.*/
  i = 0;
  while (config->inits[i].pcr_index != -1) {
    SIU.GPDO[config->inits[i].pcr_index].R = config->inits[i].gpdo_value;
    SIU.PCR[config->inits[i].pcr_index].R  = config->inits[i].pcr_value;
    i++;
  }
}

/**
 * @brief   Pads mode setup.
 * @details This function programs a pads group belonging to the same port
 *          with the specified mode.
 *
 * @param[in] port      the port identifier
 * @param[in] mask      the group mask. A '0' in the position i means that the
 *                      mode of pad i will be not changed, a '1' means that the
 *                      mode of pad i will be updated.
 * @param[in] mode      the mode
 *
 * @notapi
 */
void _pal_setgroupmode(ioportid_t port, ioportmask_t mask, iomode_t mode) {
  uint32_t pcr_index = (uint32_t)(port * PAL_IOPORTS_WIDTH);
  ioportmask_t m1 = 0x8000U;
  while (m1 != 0U) {
    if ((mask & m1) != 0U) {
      SIU.PCR[pcr_index].R = mode;
    }
    m1 >>= 1;
    ++pcr_index;
  }
}

/** @} */
