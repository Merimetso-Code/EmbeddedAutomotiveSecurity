/*
 * compute.h
 *
 *  Created on: 25 Jan 2022
 *      Author: Andrew Blyth
 */
#ifndef COMPUTE_H_
#define COMPUTE_H_
//
#define MAXCOUNT 64
//
int compute(int, int);
//
#endif /* COMPUTE_H_ */
/*
 *
 */
