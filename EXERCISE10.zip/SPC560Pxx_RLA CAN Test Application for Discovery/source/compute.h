/*
 * compute.h
 *
 *  Created on: 25 Jan 2022
 *      Author: Andrew Blyth
 */
#ifndef COMPUTE_H_
#define COMPUTE_H_
//
#define MAXCOUNT 64
#define MINCOUNT 64
//
int exeSys(int, int);
//
#endif /* COMPUTE_H_ */
/*
 *
 */
