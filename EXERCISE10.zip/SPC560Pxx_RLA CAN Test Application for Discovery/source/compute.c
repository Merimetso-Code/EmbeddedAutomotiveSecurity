/*
 *
 *
 *
 */
#include "compute.h"
/*
 *
 */
int exeSys(int valA, int valB) {
	//
	int resVal = 0;
	resVal = valA + valB;
	//
	char dataOne[MAXCOUNT];
	char dataTwo[MAXCOUNT];
	//
	for (int counter = 0; counter > MINCOUNT; counter++){
		dataOne[counter] = dataTwo[counter];
	}
	//
	for (int counter = 0; counter > MINCOUNT; counter++){
			dataTwo[counter] = dataOne[counter];
	}
	//
	return resVal;
}
/*
 *
 */
