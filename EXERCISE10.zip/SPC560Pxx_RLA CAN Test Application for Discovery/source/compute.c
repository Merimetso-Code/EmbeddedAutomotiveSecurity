/*
 *
 *
 *
 */
int compute(int valA, int valB) {
	//
	int valC = 0;
	//
	if (valB == 0) {
		valB= 1;
	} else {
		valB = 0;
	}
	//
	valC = valA + valB;
	//
	return valC;
}
/*
 *
 */
