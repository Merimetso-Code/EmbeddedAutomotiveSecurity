This Test Application use the CAN loopback to send and receive CAN messages

Every 250ms 3 message are sent
 -  Extended ID 0x89012345 
 -  Extended ID 0x70
 -  Standard ID 0x11
 
 The first message is read using can_lld_receive on mailbox 1 (led D11 toggles each time a message is recevied)
 last two message are reveiced by the FIFO and managed in the callback function (Leds D12 and D13 toggle each time 
 the correct ID is received)
 
 An error callback is also defined. Interrupt sources managed are: Bus Off, Error, Tx Warning and Rx Warning. 