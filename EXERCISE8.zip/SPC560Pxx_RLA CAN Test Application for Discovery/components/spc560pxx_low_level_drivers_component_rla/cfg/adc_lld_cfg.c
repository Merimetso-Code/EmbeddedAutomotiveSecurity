/****************************************************************************
*
* Copyright © 2015-2019 STMicroelectronics - All Rights Reserved
*
* This software is licensed under SLA0098 terms that can be found in the
* DM00779817_1_0.pdf file in the licenses directory of this software product.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED,
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
*****************************************************************************/
/**
 * @file    adc_lld_cfg.c
 * @brief   ADC Driver configuration code.
 *
 * @addtogroup ADC
 * @{
 */

#include "adc_lld_cfg.h"

#if (LLD_USE_ADC == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/* List of the ADC0 ADCConversionGroup structures.*/
/**
 * @brief   Structure defining the conversion group "group_name".
 */
ADCConversionGroup adc0_group_group_name = {
  FALSE,
  1U,
  NULL,
  NULL,
#if (SPC5_ADC_HAS_TRC == TRUE)
  {
    0U,
    0U,
    0U,
    0U
  },
  {
    ADC_THRHLR_THRH(1023U) | ADC_THRHLR_THRL(0U),
    ADC_THRHLR_THRH(1023U) | ADC_THRHLR_THRL(0U),
    ADC_THRHLR_THRH(1023U) | ADC_THRHLR_THRL(0U),
    ADC_THRHLR_THRH(1023U) | ADC_THRHLR_THRL(0U)
  },
  0U   ,
#else
  {
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
  },
  {
    ADC_THRHLR_THRH(1023U) | ADC_THRHLR_THRL(0U),
    ADC_THRHLR_THRH(1023U) | ADC_THRHLR_THRL(0U),
    ADC_THRHLR_THRH(1023U) | ADC_THRHLR_THRL(0U),
    ADC_THRHLR_THRH(1023U) | ADC_THRHLR_THRL(0U),
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U
  },
  {
    0U,
    0U,
    0U
  },
  0U,
#endif
  {
    ADC_CTR_OFFSHIFT(0UL) | ADC_CTR_INPCMP(1UL) | ADC_CTR_INPSAMP(3UL),
    0UL,
    0UL
  },
  ADC_CHN_AN0
};

/* List of the ADC1 ADCConversionGroup structures.*/
/**
 * @brief   Structure defining the conversion group "group_name".
 */
ADCConversionGroup adc1_group_group_name = {
  FALSE,
  1U,
  NULL,
  NULL,
#if (SPC5_ADC_HAS_TRC == TRUE)
  {
    0U,
    0U,
    0U,
    0U
  },
  {
    ADC_THRHLR_THRH(1023U) | ADC_THRHLR_THRL(0U),
    ADC_THRHLR_THRH(1023U) | ADC_THRHLR_THRL(0U),
    ADC_THRHLR_THRH(1023U) | ADC_THRHLR_THRL(0U),
    ADC_THRHLR_THRH(1023U) | ADC_THRHLR_THRL(0U)
  },
  0U   ,
#else
  {
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
  },
  {
    ADC_THRHLR_THRH(1023U) | ADC_THRHLR_THRL(0U),
    ADC_THRHLR_THRH(1023U) | ADC_THRHLR_THRL(0U),
    ADC_THRHLR_THRH(1023U) | ADC_THRHLR_THRL(0U),
    ADC_THRHLR_THRH(1023U) | ADC_THRHLR_THRL(0U),
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U,
    0xFFFF0000U
  },
  {
    0U,
    0U,
    0U
  },
  0U,
#endif
  {
    ADC_CTR_OFFSHIFT(0UL) | ADC_CTR_INPCMP(1UL) | ADC_CTR_INPSAMP(3UL),
    0UL,
    0UL
  },
  ADC_CHN_AN0
};


/*===========================================================================*/
/* Driver local types.                                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

#endif /* LLD_USE_ADC */

/** @} */
