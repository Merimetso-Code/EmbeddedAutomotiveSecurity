This application shows how to the use the PAL and SERIAL driver. It writes
"hello world!" on serial port and lights 3 LEDs with different timings.

In order to receive from serial, please set the baud rate of the COM port on 
your PC to 38400.