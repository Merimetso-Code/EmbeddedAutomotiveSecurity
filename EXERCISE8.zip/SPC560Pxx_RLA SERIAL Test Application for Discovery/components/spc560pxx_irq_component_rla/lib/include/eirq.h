/****************************************************************************
*
* Copyright © 2015-2019 STMicroelectronics - All Rights Reserved
*
* This software is licensed under SLA0098 terms that can be found in the
* DM00779817_1_0.pdf file in the licenses directory of this software product.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
*****************************************************************************/
/**
 * @file    eirq.h
 * @brief   SPC5xx EIRQ header.
 *
 * @addtogroup EIRQ
 * @{
 */

#ifndef _EIRQ_H_
#define _EIRQ_H_

#include <stddef.h>
#include "vectors.h"
#include "irq.h"
#include "platform.h"


/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/** @} */

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/


//valori di default per macro non definite 


/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/**
 * @brief   EIRQ notification callback type.
 *
 */
typedef void (*eirqcallback_t)(void);

/**
 * @brief   Structure representing a PIT Channel configuration
 */
typedef struct {
  /**
   * @brief   eirq number.
   */  
  int8_t eirqNumber;
  /**
   * @brief   rising edge trigger event
   */
  uint8_t risingEdge;
  /**
   * @brief    falling edge trigger event
   */
  uint8_t fallingEdge;
  /**
   * @brief    Antiglitch filter enable on PIN
   */
  uint8_t filterEnable;
   /**
   * @brief   callback function.
   */
  eirqcallback_t callback;
}eirq_config;

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/
/*===========================================================================*/
/* IRQ Handlers                                                              */
/*===========================================================================*/
#if (SPC5_SIUL_EIRQ_HAS_0_7_HANDLER == TRUE)
IRQ_HANDLER(SPC5_SIUL_EIRQ_0_7_HANDLER);
#endif
#if (SPC5_SIUL_EIRQ_HAS_8_15_HANDLER == TRUE)
IRQ_HANDLER(SPC5_SIUL_EIRQ_8_15_HANDLER);
#endif
#if (SPC5_SIUL_EIRQ_HAS_16_23_HANDLER == TRUE)
IRQ_HANDLER(SPC5_SIUL_EIRQ_16_23_HANDLER);
#endif
#if (SPC5_SIUL_EIRQ_HAS_24_31_HANDLER == TRUE)
IRQ_HANDLER(SPC5_SIUL_EIRQ_24_31_HANDLER);
#endif
/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#ifdef __cplusplus
extern "C" {
#endif
void eirqInit(void);
#ifdef __cplusplus
}
#endif

#endif
/** @} */
